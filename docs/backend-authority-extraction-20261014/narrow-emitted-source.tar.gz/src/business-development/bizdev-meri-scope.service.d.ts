import { ConflictException } from '@nestjs/common';
import type { TenantContext } from '@capiro/shared';
import { PrismaService } from '../prisma/prisma.service.js';
/**
 * Business Development Phase 4 — Meri prospect-conversation scope resolution.
 *
 * Phase 4's server-only slice: when a Meri conversation is created against a
 * BD prospect, the server — never the client — resolves a BOUNDED prospect
 * scope (ids, display name, and an opaque scopeVersion digest). No provider
 * payloads, notes, or dossier data are embedded in the conversation metadata;
 * future dispatch must re-resolve authorization through `assertCurrent`.
 *
 * Fail-closed on every path, mirroring the Phase 1/2/4 guards: every failure
 * mode (missing tenant context, missing tenant row, either flag off, missing
 * or cross-tenant prospect, thrown DB error) yields the SAME bare
 * NotFoundException — indistinguishable from a route that doesn't exist.
 */
/** The one bounded metadata key Meri prospect conversations persist scope under. */
export declare const MERI_PROSPECT_SCOPE_METADATA_KEY: "bizdevProspectScope";
/** Semantic (typed) shape of the persisted scope. */
export interface MeriProspectScope {
    prospectId: string;
    prospectName: string;
    canonicalOrganizationId: string | null;
    linkedClientId: string | null;
    scopeVersion: string;
}
/** Typed failure for a persisted scope that no longer matches server reality. */
export declare class MeriProspectScopeConflictError extends ConflictException {
    constructor(reason: 'changed' | 'not_found');
}
/**
 * Deterministic SHA-256 over the stable, authorized selection fields only.
 * Pure so it unit-tests; two resolutions of the same prospect state produce
 * the same digest, and any change to id / canonical id / linked client /
 * linked client changes it. Ordinary prospect edits do not silently switch or
 * invalidate the conversation's selected prospect.
 */
export declare function computeMeriProspectScopeVersion(input: {
    prospectId: string;
    canonicalOrganizationId: string | null;
    linkedClientId: string | null;
}): string;
/**
 * Fail-closed parser for a scope persisted in conversation metadata.
 * Returns null for anything absent/malformed — callers must treat null as
 * "no usable scope" and reject prospect-dependent dispatch.
 */
export declare function parsePersistedMeriProspectScope(metadata: unknown): MeriProspectScope | null;
export declare class BizDevMeriScopeService {
    private readonly prisma;
    private readonly logger;
    constructor(prisma: PrismaService);
    /**
     * Resolve the bounded prospect scope for a Meri conversation. Both the
     * Phase 1 `businessDevelopment.enabled` and the Phase 4
     * `businessDevelopment.meriProspectTools.enabled` tenant flags must be true,
     * and the prospect must exist on the caller's tenant. Every failure mode
     * throws the same bare safe NotFoundException.
     */
    resolve(ctx: TenantContext, prospectId: string): Promise<MeriProspectScope>;
    /**
     * Guard for future prospect-dependent dispatch: re-resolve the scope under
     * current authorization and reject a changed or missing persisted scope
     * with the typed conflict / safe 404. Never repairs or silently accepts a
     * stale scope.
     */
    assertCurrent(ctx: TenantContext, persistedScope: unknown): Promise<MeriProspectScope>;
}
//# sourceMappingURL=bizdev-meri-scope.service.d.ts.map