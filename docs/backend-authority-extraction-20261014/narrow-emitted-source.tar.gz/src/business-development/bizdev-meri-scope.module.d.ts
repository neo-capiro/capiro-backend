/** Existing prospect authority shared without dossier/model/ingestion owners. */
export declare class BizDevMeriScopeModule {
}
//# sourceMappingURL=bizdev-meri-scope.module.d.ts.map