"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.BizDevMeriScopeModule = void 0;
const common_1 = require("@nestjs/common");
const prisma_module_js_1 = require("../prisma/prisma.module.js");
const bizdev_meri_scope_service_js_1 = require("./bizdev-meri-scope.service.js");
/** Existing prospect authority shared without dossier/model/ingestion owners. */
let BizDevMeriScopeModule = class BizDevMeriScopeModule {
};
exports.BizDevMeriScopeModule = BizDevMeriScopeModule;
exports.BizDevMeriScopeModule = BizDevMeriScopeModule = __decorate([
    (0, common_1.Module)({
        imports: [prisma_module_js_1.PrismaModule],
        providers: [bizdev_meri_scope_service_js_1.BizDevMeriScopeService],
        exports: [bizdev_meri_scope_service_js_1.BizDevMeriScopeService],
    })
], BizDevMeriScopeModule);
//# sourceMappingURL=bizdev-meri-scope.module.js.map