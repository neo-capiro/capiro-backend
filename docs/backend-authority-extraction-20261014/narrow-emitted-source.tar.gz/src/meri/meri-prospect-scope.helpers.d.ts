/**
 * Business Development Phase 4 — shared prospect-scope dispatch helpers.
 *
 * One place builds (a) the authorization re-check every prospect-scoped
 * dispatch must pass BEFORE any user-message write or model/runtime call, and
 * (b) the compact server-authored directive + public turn-scope receipt, so
 * the legacy loop, the MeriV2 full-chat proxy and MeriV3 cannot drift apart.
 *
 * Import direction is the existing one-way MeriModule → BusinessDevelopmentModule
 * edge: this file (in meri/) imports the BD scope service; BD never imports meri.
 * No provider payloads, notes, dossiers or arbitrary metadata ever enter a
 * prompt — only the bounded scope fields below.
 */
import type { TenantContext } from '@capiro/shared';
import { type BizDevMeriScopeService, type MeriProspectScope } from '../business-development/bizdev-meri-scope.service.js';
import type { MeriTurnScope } from './meri-turn-scope.js';
/**
 * Authorization re-check for prospect-scoped conversations. Returns null for
 * ordinary unscoped conversations (caller proceeds unchanged). For a
 * conversation whose metadata carries a prospect scope, re-resolves it through
 * `BizDevMeriScopeService.assertCurrent` and fails closed — typed conflict /
 * safe 404 — on missing/malformed/stale scope or an unavailable scope service,
 * BEFORE the caller persists a user message or dispatches a model/runtime.
 */
export declare function authorizeMeriProspectScope(bizdevScope: BizDevMeriScopeService | undefined, ctx: TenantContext, conversationMetadata: unknown): Promise<MeriProspectScope | null>;
/**
 * The compact server-authored directive binding the selected prospect into
 * model/runtime context. Bounded fields only: display name + prospect id.
 * States explicitly that a free-form prompt naming another company does NOT
 * retarget the conversation, and that an explicit switch or a new
 * prospect-scoped conversation is required.
 */
export declare function prospectScopeDirective(scope: MeriProspectScope): string;
/**
 * Public turn-scope receipt for a prospect-scoped turn. Captured ONLY from the
 * immutable server conversation snapshot / current re-resolution — never from
 * retrieval-plan guesses or model output.
 */
export declare function prospectTurnScopeReceipt(scope: MeriProspectScope): MeriTurnScope;
//# sourceMappingURL=meri-prospect-scope.helpers.d.ts.map