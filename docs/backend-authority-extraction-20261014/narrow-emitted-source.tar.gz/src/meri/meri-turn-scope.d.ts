/** Public scope receipt for one completed turn. Stored in existing message metadata. */
export interface MeriTurnScope {
    kind: 'client' | 'portfolio' | 'research_portfolio' | 'external_entity' | 'general' | 'prospect' | 'unknown';
    clientId: string | null;
    clientName: string | null;
    targetHint: string | null;
    prospectId?: string;
    prospectName?: string;
    canonicalOrganizationId?: string | null;
    linkedClientId?: string | null;
    scopeVersion?: string;
    researchPortfolioId?: string;
    researchPortfolioName?: string;
    researchPortfolioRevision?: number;
}
/** The conversation is the server snapshot captured before dispatch, never re-read at completion. */
export declare function captureMeriTurnScope(conversation: {
    clientId: string | null;
    client?: {
        id: string;
        name: string;
    } | null;
}, retrieval?: {
    plan?: {
        subjectScope?: string;
        targetHint?: string | null;
    };
} | null, packet?: {
    clientId?: string | null;
} | null): MeriTurnScope;
//# sourceMappingURL=meri-turn-scope.d.ts.map