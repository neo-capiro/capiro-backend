"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.authorizeMeriProspectScope = authorizeMeriProspectScope;
exports.prospectScopeDirective = prospectScopeDirective;
exports.prospectTurnScopeReceipt = prospectTurnScopeReceipt;
const bizdev_meri_scope_service_js_1 = require("../business-development/bizdev-meri-scope.service.js");
/**
 * Authorization re-check for prospect-scoped conversations. Returns null for
 * ordinary unscoped conversations (caller proceeds unchanged). For a
 * conversation whose metadata carries a prospect scope, re-resolves it through
 * `BizDevMeriScopeService.assertCurrent` and fails closed — typed conflict /
 * safe 404 — on missing/malformed/stale scope or an unavailable scope service,
 * BEFORE the caller persists a user message or dispatches a model/runtime.
 */
async function authorizeMeriProspectScope(bizdevScope, ctx, conversationMetadata) {
    const metadata = conversationMetadata &&
        typeof conversationMetadata === 'object' &&
        !Array.isArray(conversationMetadata)
        ? conversationMetadata
        : null;
    const hasPersistedScope = Boolean(metadata && Object.prototype.hasOwnProperty.call(metadata, 'bizdevProspectScope'));
    const persisted = (0, bizdev_meri_scope_service_js_1.parsePersistedMeriProspectScope)(conversationMetadata);
    if (!hasPersistedScope)
        return null;
    if (!persisted)
        throw new bizdev_meri_scope_service_js_1.MeriProspectScopeConflictError('not_found');
    if (!bizdevScope)
        throw new bizdev_meri_scope_service_js_1.MeriProspectScopeConflictError('not_found');
    return bizdevScope.assertCurrent(ctx, conversationMetadata);
}
/**
 * The compact server-authored directive binding the selected prospect into
 * model/runtime context. Bounded fields only: display name + prospect id.
 * States explicitly that a free-form prompt naming another company does NOT
 * retarget the conversation, and that an explicit switch or a new
 * prospect-scoped conversation is required.
 */
function prospectScopeDirective(scope) {
    const label = `"${scope.prospectName}"`;
    return [
        `Active prospect scope (HARD CONSTRAINT): this conversation is scoped to the business-development prospect ${label} (id: ${scope.prospectId}).`,
        `Every prospect-specific answer, draft and recommendation in this session must be about ${label}, the active prospect.`,
        `The active prospect does NOT change mid-conversation: a prompt that names, asks about, or compares another company does not retarget this chat. Treat other companies as out of scope for prospect-specific work.`,
        `If the user wants to work on a different prospect, say plainly that this chat is scoped to ${label} and ask them to switch prospects explicitly or start a new prospect chat. Do not silently switch.`,
    ].join(' ');
}
/**
 * Public turn-scope receipt for a prospect-scoped turn. Captured ONLY from the
 * immutable server conversation snapshot / current re-resolution — never from
 * retrieval-plan guesses or model output.
 */
function prospectTurnScopeReceipt(scope) {
    return {
        kind: 'prospect',
        clientId: null,
        clientName: null,
        targetHint: null,
        prospectId: scope.prospectId,
        prospectName: scope.prospectName,
        canonicalOrganizationId: scope.canonicalOrganizationId,
        linkedClientId: scope.linkedClientId,
        scopeVersion: scope.scopeVersion,
    };
}
//# sourceMappingURL=meri-prospect-scope.helpers.js.map