"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.captureMeriTurnScope = captureMeriTurnScope;
/** The conversation is the server snapshot captured before dispatch, never re-read at completion. */
function captureMeriTurnScope(conversation, retrieval, packet) {
    const empty = { kind: 'unknown', clientId: null, clientName: null, targetHint: null };
    const kind = retrieval?.plan?.subjectScope;
    if (kind === 'portfolio' || kind === 'general')
        return { ...empty, kind };
    if (kind === 'external_entity') {
        return { ...empty, kind, targetHint: retrieval?.plan?.targetHint?.trim() || null };
    }
    if (kind !== 'client')
        return empty;
    // A compiled packet is authoritative when present, including an explicit
    // null client. Do not substitute the picker if compilation disagreed.
    const clientId = packet && Object.hasOwn(packet, 'clientId')
        ? packet.clientId || null
        : conversation.clientId;
    if (!clientId)
        return empty;
    return {
        ...empty,
        kind,
        clientId,
        clientName: conversation.client?.id === clientId ? conversation.client.name : null,
    };
}
//# sourceMappingURL=meri-turn-scope.js.map