import type { CapiroServiceName, EngagementBackgroundOwner, EngagementExternalActionMode, EngagementProcessMode } from './engagement-runtime.types.js';
export interface EngagementRuntimeEnvironment {
    serviceName: CapiroServiceName;
    processMode: EngagementProcessMode;
    backgroundOwner: EngagementBackgroundOwner;
    externalActions: EngagementExternalActionMode;
    callbacksEnabled: boolean;
    recallWebhookEnabled: boolean;
}
export declare function parseExactBooleanEnvironment(name: string, raw: unknown, fallback: boolean): boolean;
/**
 * The literal, unguessable value `ENGAGEMENT_API_PROMOTION_TOKEN` must equal
 * before an `engagement-api` process is allowed to leave shadow posture.
 *
 * This is deliberately NOT a boolean flag. A single `ENGAGEMENT_PROCESS_MODE=
 * active` typo or copy-paste from another service's task definition must not
 * be enough to arm external actions, background workers, callbacks and Recall
 * webhooks on a process that, until this promotion, could not send a single
 * external message. Requiring this exact string is a second, independent
 * signature of intent alongside the five posture fields themselves — a
 * config-file mistake that gets every posture field right by accident still
 * cannot arm the service, because it also has to reproduce this exact string.
 */
export declare const ENGAGEMENT_API_PROMOTION_ACKNOWLEDGEMENT = "i-understand-this-arms-engagement-api-for-external-actions";
/**
 * Boot-time, fail-closed validation for the Engagement runtime controls.
 *
 * The Zod schema still owns the application-wide config object. This preflight
 * exists because a permissive string transform can otherwise turn a typo such
 * as `flase` into false. Both bootstraps call this before Nest constructs any
 * provider, opens a database connection, or starts a worker.
 *
 * Two valid postures for `engagement-api`, never a partial mix of the two:
 *
 *   SHADOW (default): every one of processMode/backgroundOwner/
 *   externalActions/callbacksEnabled/recallWebhookEnabled is at its inert
 *   value. This is the only posture that requires no acknowledgement token —
 *   it is what a freshly-registered task definition gets if nobody sets
 *   anything.
 *
 *   ACTIVE (promoted): processMode=active, backgroundOwner=engagement-api,
 *   externalActions=enabled, callbacksEnabled=true, recallWebhookEnabled=true
 *   — ALL FIVE together, plus ENGAGEMENT_API_PROMOTION_TOKEN matching the
 *   acknowledgement string above. There is no state where some fields are
 *   armed and others are not; resolveEngagementRuntimeEnvironment rejects any
 *   partial combination just as it always rejected an armed field under the
 *   old shadow-only contract.
 */
export declare function resolveEngagementRuntimeEnvironment(raw: Record<string, unknown>): EngagementRuntimeEnvironment;
export declare function assertEngagementRuntimeEnvironment(raw: Record<string, unknown>): EngagementRuntimeEnvironment;
//# sourceMappingURL=engagement-runtime-env.d.ts.map