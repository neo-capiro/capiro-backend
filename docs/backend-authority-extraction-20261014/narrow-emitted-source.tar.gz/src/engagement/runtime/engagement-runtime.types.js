"use strict";
/**
 * Engagement Runtime Policy — shared types.
 *
 * These types govern the fail-closed shadow-mode behavior of the
 * engagement-api process. The policy service reads validated config
 * and provides a single source of truth for whether background workers,
 * external actions, callbacks, and Recall webhooks are allowed.
 */
Object.defineProperty(exports, "__esModule", { value: true });
//# sourceMappingURL=engagement-runtime.types.js.map