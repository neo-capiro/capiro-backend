/**
 * Injects the current TenantContext into a controller method.
 * The middleware sets `req.tenantContext`; this decorator reads it.
 * Throws if the route did not pass through TenantContextMiddleware.
 */
export declare const CurrentTenant: (...dataOrPipes: unknown[]) => ParameterDecorator;
//# sourceMappingURL=current-tenant.decorator.d.ts.map