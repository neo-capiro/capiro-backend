"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.CurrentTenant = void 0;
const common_1 = require("@nestjs/common");
/**
 * Injects the current TenantContext into a controller method.
 * The middleware sets `req.tenantContext`; this decorator reads it.
 * Throws if the route did not pass through TenantContextMiddleware.
 */
exports.CurrentTenant = (0, common_1.createParamDecorator)((_data, ctx) => {
    const req = ctx.switchToHttp().getRequest();
    if (!req.tenantContext) {
        throw new Error('TenantContext missing, route is not covered by TenantContextMiddleware');
    }
    return req.tenantContext;
});
//# sourceMappingURL=current-tenant.decorator.js.map