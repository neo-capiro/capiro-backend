import { NestMiddleware } from '@nestjs/common';
import type { NextFunction, Request, Response } from 'express';
import { type TenantContext } from '@capiro/shared';
import { ClerkService } from '../auth/clerk.service.js';
import { PrismaService } from '../prisma/prisma.service.js';
import { TenantContextStore } from './tenant-context.store.js';
import { type ApplicationAuthorityIdentityProof } from '../auth/application-authority.js';
/**
 * Resolves the tenant context for an authenticated request.
 *
 * Order of operations:
 *   1. Verify the Clerk session JWT (Authorization: Bearer ...).
 *   2. Resolve the requested tenant. Preference order:
 *        a. `capiro_tenant_id` from the Clerk JWT template (fast path, no
 *            membership scan needed; the org_id claim is cross-checked
 *            against tenants.clerk_org_id).
 *        b. X-Capiro-Tenant header.
 *        c. Subdomain match, `{slug}.app.capiro.ai`.
 *        d. Sole-membership fallback, if the user has exactly one active
 *            membership and none of the above produced a hint, use it.
 *   3. Look up the membership using RLS bypass (the lookup itself is not
 *      tenant-scoped because we are still resolving which tenant to use).
 *   4. Cross-check: if the JWT carries `org_id`, the resolved tenant's
 *      `clerk_org_id` MUST match. Mismatch → 403.
 *   5. Propagate the context via AsyncLocalStorage + req.tenantContext.
 *
 * This is the JWT/host integrity check called out in arch §2.2 and §8.2.
 */
export declare class TenantContextMiddleware implements NestMiddleware {
    private readonly clerk;
    private readonly prisma;
    private readonly store;
    private readonly logger;
    constructor(clerk: ClerkService, prisma: PrismaService, store: TenantContextStore);
    use(req: Request, res: Response, next: NextFunction): Promise<void>;
    /** A fresh online session read followed by read-only current local checks.
     * The original authentication pipeline can provision/update/audit; this
     * method cannot repair missing authority or choose a different membership. */
    readApplicationAuthority(req: Request, ctx: TenantContext): Promise<ApplicationAuthorityIdentityProof>;
    private readCurrentApplicationAuthority;
    /**
     * Emit the SOC 2 evidence for a rejected request: a structured `auth.denied`
     * line (counted by the Capiro/Security metric filter) and, when a tenant was
     * actually resolved, an append-only audit_logs row its own admins can see.
     *
     * audit_logs.tenant_id is NOT NULL, so the two pre-resolution reasons
     * (no_active_membership, no_matching_tenant) get the log line only — there is
     * no tenant to attribute them to yet.
     *
     * The claimed-vs-resolved pair is encoded in `action` + `entityId` rather than
     * before/after, because the customer-facing audit projection redacts those.
     *
     * Entirely best-effort: this is telemetry on a path that is ALREADY failing,
     * and it must never convert a clean 403 into a 500.
     */
    private recordDenial;
    /**
     * Provision a local tenant_membership from a verified Clerk JWT when the
     * webhook-populated mirror is missing it. Returns the membership (with its
     * tenant) to use, or null if it cannot / must not be provisioned.
     *
     * Safety rules (this is an authorization path — fail closed):
     *   - The tenant is resolved by `clerk_org_id === org_id`, and org_id is a
     *     verified JWT claim, so we only ever provision a tenant the JWT already
     *     proves the user is a Clerk member of.
     *   - If the JWT also carries capiro_tenant_id / capiro_tenant_slug, they
     *     MUST agree with the resolved tenant (the same integrity checks the
     *     caller applies post-resolution), otherwise we bail.
     *   - The tenant must be active.
     *   - A pre-existing non-active membership (removed/suspended) is NOT
     *     resurrected: offboarding stays sticky and must be redone via the normal
     *     invite flow.
     */
    private selfHealMembership;
    private resolveRequestedTenantSlug;
}
//# sourceMappingURL=tenant-context.middleware.d.ts.map