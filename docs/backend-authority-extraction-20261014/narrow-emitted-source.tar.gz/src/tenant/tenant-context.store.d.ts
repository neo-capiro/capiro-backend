import type { TenantContext } from '@capiro/shared';
/**
 * Per-request tenant context propagated via AsyncLocalStorage. Filled in by
 * TenantContextMiddleware after Clerk verification + membership lookup.
 *
 * Read with `store.get()` from any service. Returns undefined for unauth
 * routes (health, webhooks).
 */
export declare class TenantContextStore {
    private readonly als;
    run<T>(ctx: TenantContext, fn: () => T): T;
    get(): TenantContext | undefined;
    require(): TenantContext;
}
//# sourceMappingURL=tenant-context.store.d.ts.map