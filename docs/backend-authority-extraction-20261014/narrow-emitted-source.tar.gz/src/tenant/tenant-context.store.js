"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.TenantContextStore = void 0;
const common_1 = require("@nestjs/common");
const node_async_hooks_1 = require("node:async_hooks");
/**
 * Per-request tenant context propagated via AsyncLocalStorage. Filled in by
 * TenantContextMiddleware after Clerk verification + membership lookup.
 *
 * Read with `store.get()` from any service. Returns undefined for unauth
 * routes (health, webhooks).
 */
let TenantContextStore = class TenantContextStore {
    constructor() {
        this.als = new node_async_hooks_1.AsyncLocalStorage();
    }
    run(ctx, fn) {
        return this.als.run(ctx, fn);
    }
    get() {
        return this.als.getStore();
    }
    require() {
        const ctx = this.get();
        if (!ctx) {
            throw new Error('Tenant context not set, route is missing TenantContextMiddleware');
        }
        return ctx;
    }
};
exports.TenantContextStore = TenantContextStore;
exports.TenantContextStore = TenantContextStore = __decorate([
    (0, common_1.Injectable)()
], TenantContextStore);
//# sourceMappingURL=tenant-context.store.js.map