"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var TenantContextMiddleware_1;
Object.defineProperty(exports, "__esModule", { value: true });
exports.TenantContextMiddleware = void 0;
// ============================================================================
// ⛔ CHANGE-CONTROL: AUTHENTICATION / EMAIL INTEGRATION — APPROVAL REQUIRED
// ----------------------------------------------------------------------------
// Do NOT modify this file (or anything touching Clerk auth, the tenant-context
// middleware, JWT/session handling, Microsoft Graph OAuth, the Clerk webhook,
// or integration connection/token persistence) without EXPLICIT prior approval
// from Neo. These paths gate every authenticated request and the email/Outlook
// integration; a subtle change here has repeatedly caused tenant-wide 403/500
// outages (see git history 2026-06-07 + skill: capiro-tenant-onboarding-flow).
// Investigate read-only and PROPOSE first; wait for go-ahead before editing,
// merging, or deploying.
// ============================================================================
const common_1 = require("@nestjs/common");
const shared_1 = require("@capiro/shared");
const clerk_service_js_1 = require("../auth/clerk.service.js");
const prisma_service_js_1 = require("../prisma/prisma.service.js");
const clerk_role_util_js_1 = require("../auth/clerk-role.util.js");
const tenant_context_store_js_1 = require("./tenant-context.store.js");
const application_authority_js_1 = require("../auth/application-authority.js");
// Nest's middleware wrapper and injected provider can be separate instances.
// The existing owner shares only private, ephemeral provenance keyed by the
// actual request object; there is no reusable/durable authorization receipt.
const applicationAuthorityRequests = new WeakMap();
/**
 * Resolves the tenant context for an authenticated request.
 *
 * Order of operations:
 *   1. Verify the Clerk session JWT (Authorization: Bearer ...).
 *   2. Resolve the requested tenant. Preference order:
 *        a. `capiro_tenant_id` from the Clerk JWT template (fast path, no
 *            membership scan needed; the org_id claim is cross-checked
 *            against tenants.clerk_org_id).
 *        b. X-Capiro-Tenant header.
 *        c. Subdomain match, `{slug}.app.capiro.ai`.
 *        d. Sole-membership fallback, if the user has exactly one active
 *            membership and none of the above produced a hint, use it.
 *   3. Look up the membership using RLS bypass (the lookup itself is not
 *      tenant-scoped because we are still resolving which tenant to use).
 *   4. Cross-check: if the JWT carries `org_id`, the resolved tenant's
 *      `clerk_org_id` MUST match. Mismatch → 403.
 *   5. Propagate the context via AsyncLocalStorage + req.tenantContext.
 *
 * This is the JWT/host integrity check called out in arch §2.2 and §8.2.
 */
let TenantContextMiddleware = TenantContextMiddleware_1 = class TenantContextMiddleware {
    constructor(clerk, prisma, store) {
        this.clerk = clerk;
        this.prisma = prisma;
        this.store = store;
        this.logger = new common_1.Logger(TenantContextMiddleware_1.name);
    }
    async use(req, res, next) {
        // Also cover authentication/authorization denials before the controller.
        const authorityPaths = [
            '/api/clio/application-authority/identity', '/api/clio/application-authority/context',
            '/clio/application-authority/identity', '/clio/application-authority/context',
        ];
        if ([req.path, (req.originalUrl ?? req.url ?? '').split('?')[0]].some((path) => path !== undefined && authorityPaths.includes(path)))
            res.setHeader('Cache-Control', 'no-store');
        // Belt-and-suspenders bypass for paths that authenticate via a different
        // channel than the Clerk session. The OAuth callback is reached via a
        // top-level browser redirect from Microsoft and authenticates via the
        // HMAC-signed `state` parameter. Public marketing lead capture has no
        // tenant context by design. The middleware-level `.exclude()` in
        // app.module.ts is the primary mechanism; this is the fallback in case the
        // exclude path matcher misses for any reason (e.g. global prefix
        // interaction).
        const path = req.path;
        const originalUrl = req.originalUrl ?? req.url ?? '';
        const baseUrl = req.baseUrl ?? '';
        const bypassPaths = [
            '/webhooks/clerk',
            '/api/v1/demo-requests',
            '/api/engagement/integrations/microsoft/callback',
            '/api/engagement/integrations/microsoft/notifications',
            // Google OAuth callback: same pattern as the Microsoft callback above — a
            // top-level browser redirect from Google with ?code&state and no Clerk
            // session; authenticates via the HMAC-signed `state`
            // (GoogleOAuthService.verifyState). (Google push notifications endpoint is
            // added here in Phase 3 when users.watch/Pub/Sub lands.)
            '/api/engagement/integrations/google/callback',
            '/api/clio/runtime',
            '/api/clio/mcp-oauth/callback',
            '/api/insights',
            // Recipient capabilities authorize these routes; no private newsletter
            // authoring endpoint is covered by this distinct public prefix.
            '/api/engagement/newsletter-public',
            // BYOK3 service-to-service endpoints: intel-api resolves a tenant AI
            // credential for live-hearing extraction. These authenticate via
            // InternalServiceGuard (shared INTERNAL_SERVICE_SECRET header), NOT a
            // Clerk session, so they carry no bearer token and must bypass tenant
            // resolution here (the guard reads tenantId from the body). The
            // app.module.ts `.exclude()` misses because setGlobalPrefix('api')
            // shifts the matcher — this internal list is the mechanism that works.
            '/api/internal',
        ];
        if (bypassPaths.some((bypassPath) => isBypassPath(bypassPath, path, originalUrl, baseUrl))) {
            if (!originalUrl.includes('/newsletter-public/'))
                this.logger.log(`Bypassing tenant context for public/external route (path=${path}, originalUrl=${originalUrl}, baseUrl=${baseUrl})`);
            next();
            return;
        }
        // Step 1, verify Clerk JWT.
        const auth = req.headers.authorization;
        if (!auth || !auth.toLowerCase().startsWith('bearer ')) {
            throw new common_1.UnauthorizedException('Missing bearer token');
        }
        const token = auth.slice('bearer '.length).trim();
        let claims;
        try {
            claims = await this.clerk.verifySessionToken(token);
        }
        catch {
            throw new common_1.UnauthorizedException('Invalid session token');
        }
        // Step 2, gather every hint we have about which tenant is being requested.
        // Empty strings from the JWT template (when the user has no active org)
        // are normalized to undefined so the downstream logic only sees real
        // signals.
        const requestedSlug = this.resolveRequestedTenantSlug(req);
        const claimedTenantId = nonEmpty(claims.capiro_tenant_id);
        const claimedTenantSlug = nonEmpty(claims.capiro_tenant_slug);
        const claimedOrgId = nonEmpty(claims.org_id);
        // Denial capture. Set immediately before each 403 throw and consumed AFTER
        // the transaction has unwound — see the catch below for why it cannot be
        // recorded inline.
        let denial = null;
        let selectedAuthorityMembership;
        let selectedAuthorityImpersonation = null;
        // Step 3, resolve membership using RLS bypass. The lookup is not
        // tenant-scoped (we are still resolving the tenant), so it MUST run
        // through the system path.
        const resolveContext = () => this.prisma.withSystem(async (tx) => {
            let user = await tx.user.findUnique({ where: { clerkUserId: claims.sub } });
            if (!user) {
                // First-time authenticated request from this Clerk user. The webhook is
                // the canonical source of users, but a slow (or, as in the 2026-05
                // webhook-routing outage, undelivered) webhook must not block a user
                // whose verified Clerk JWT already proves their identity.
                //
                // A row may already exist for this email — e.g. created by an earlier
                // flow with a different/placeholder clerkUserId, or by an out-of-order
                // webhook. Adopt it and bind it to this verified Clerk identity rather
                // than INSERTing a duplicate, which would violate the unique email
                // constraint and 500 every request. Verified-JWT email is authoritative.
                const email = claims.email ?? `${claims.sub}@unknown.invalid`;
                const existingByEmail = await tx.user.findUnique({ where: { email } });
                if (existingByEmail) {
                    // IDENTITY REBIND. An existing local row is being re-pointed at a
                    // different Clerk identity on the strength of an email match alone.
                    // That is usually right (an old placeholder row, an out-of-order
                    // webhook) but it is not PROOF the two Clerk identities are the same
                    // person: a stale row whose user.deleted webhook never landed would
                    // hand its memberships to whoever next signs up with that address.
                    //
                    // Recorded, not blocked. Gating this would break the self-heal path
                    // whose whole purpose is preventing lockouts when the webhook is slow
                    // or undelivered, and there is no telemetry yet on how often it
                    // legitimately fires. Populate the ledger, review it, then decide.
                    // Emit a structured security event ONLY — deliberately no database
                    // write on this path.
                    //
                    // This runs inside the caller's interactive transaction, and a failed
                    // INSERT (e.g. the ledger migration not yet applied) would put
                    // Postgres into an aborted-transaction state that a JS try/catch
                    // cannot recover: the tx.user.update below would then fail too and
                    // 500 the login. The webhook and provisioning paths write the
                    // UserIdentityConflict row; this one is covered by the log +
                    // CloudWatch metric filter, which is the evidence that matters.
                    const membershipCount = await tx.tenantMembership.count({
                        where: { userId: existingByEmail.id },
                    });
                    this.logger.warn(JSON.stringify({
                        security_event: 'identity.rebind',
                        source: 'middleware_self_heal',
                        email,
                        incoming_clerk_user_id: claims.sub,
                        previous_clerk_user_id: existingByEmail.clerkUserId,
                        membership_count: membershipCount,
                        count: 1,
                    }));
                    user = await tx.user.update({
                        where: { id: existingByEmail.id },
                        data: { clerkUserId: claims.sub },
                    });
                }
                else {
                    user = await tx.user.create({
                        data: {
                            clerkUserId: claims.sub,
                            email,
                        },
                    });
                }
            }
            let memberships = await tx.tenantMembership.findMany({
                where: { userId: user.id, status: 'active' },
                include: { tenant: true },
            });
            // Match by every hint we have, in preference order. The JWT-claim
            // matches are the fast path: if the Clerk JWT template populated
            // capiro_tenant_id, we trust it (after the org_id cross-check below).
            let chosen = memberships.find((m) => claimedTenantId && m.tenantId === claimedTenantId) ??
                memberships.find((m) => claimedOrgId && m.tenant.clerkOrgId === claimedOrgId) ??
                memberships.find((m) => claimedTenantSlug && m.tenant.slug === claimedTenantSlug.toLowerCase()) ??
                memberships.find((m) => requestedSlug && m.tenant.slug === requestedSlug) ??
                // Sole-membership fallback only when no signal at all was supplied.
                (memberships.length === 1 &&
                    !claimedTenantId &&
                    !claimedOrgId &&
                    !claimedTenantSlug &&
                    !requestedSlug
                    ? memberships[0]
                    : undefined);
            // Self-heal. The local tenant_memberships table is a MIRROR of Clerk org
            // memberships, populated asynchronously by the Clerk webhook. If that
            // mirror is missing the row but the cryptographically-verified Clerk JWT
            // asserts an active org membership (org_id claim), provision the row from
            // the trusted claims instead of locking the user out. This is the same
            // trust model the webhook uses (Clerk is the source of truth for org
            // membership); selfHealMembership() never grants access to a tenant the
            // JWT does not already prove membership in, and it refuses to resurrect a
            // membership that was explicitly removed/suspended.
            if (!chosen && claimedOrgId) {
                const healed = await this.selfHealMembership(tx, user.id, {
                    claimedOrgId,
                    claimedTenantId,
                    claimedTenantSlug,
                    orgRole: nonEmpty(claims.org_role) ?? nonEmpty(claims.capiro_org_role),
                });
                if (healed) {
                    memberships = [...memberships, healed];
                    chosen = healed;
                    this.logger.warn(`Self-healed missing local membership for user ${user.id} in tenant ` +
                        `${healed.tenantId} (role ${healed.role}) from a verified Clerk JWT; ` +
                        `the webhook-populated mirror was stale.`);
                }
            }
            if (memberships.length === 0) {
                denial = { reason: 'no_active_membership' };
                throw new common_1.ForbiddenException('User has no active tenant memberships');
            }
            if (!chosen) {
                denial = { reason: 'no_matching_tenant', claimedTenantId };
                throw new common_1.ForbiddenException('No matching tenant for the supplied identifier, re-auth required');
            }
            // Step 4, integrity cross-checks. If the JWT and the resolved tenant
            // disagree on any identifier, force re-auth. Each branch covers a
            // different way an attacker could try to pivot tenants.
            if (claimedTenantId && chosen.tenantId !== claimedTenantId) {
                denial = {
                    reason: 'tenant_claim_mismatch',
                    tenantId: chosen.tenantId,
                    claimedTenantId,
                };
                throw new common_1.ForbiddenException('Tenant claim mismatch, re-auth required');
            }
            if (claimedOrgId && chosen.tenant.clerkOrgId !== claimedOrgId) {
                denial = { reason: 'org_claim_mismatch', tenantId: chosen.tenantId, claimedTenantId };
                throw new common_1.ForbiddenException('Org claim mismatch, re-auth required');
            }
            if (claimedTenantSlug &&
                chosen.tenant.slug.toLowerCase() !== claimedTenantSlug.toLowerCase()) {
                denial = { reason: 'slug_claim_mismatch', tenantId: chosen.tenantId, claimedTenantId };
                throw new common_1.ForbiddenException('Tenant slug claim mismatch, re-auth required');
            }
            if (requestedSlug && chosen.tenant.slug !== requestedSlug) {
                denial = { reason: 'host_mismatch', tenantId: chosen.tenantId, claimedTenantId };
                throw new common_1.ForbiddenException('Subdomain/header tenant mismatch, re-auth required');
            }
            selectedAuthorityMembership = { id: chosen.id, tenantId: chosen.tenantId };
            // Best-effort last_seen_at update, do not fail the request on error.
            await tx.user
                .update({ where: { id: user.id }, data: { lastSeenAt: new Date() } })
                .catch(() => undefined);
            // Impersonation override (capiro_admin only). If the caller is a
            // capiro_admin AND has an active session AND the request carries the
            // x-capiro-impersonate-tenant header, swap the tenant context to the
            // impersonated tenant. Every request executed under impersonation is
            // attributed to the actor (audit_logs.actor_user_id) so reads/writes
            // are traceable.
            const wantsImpersonate = req.header('x-capiro-impersonate-tenant')?.trim().toLowerCase();
            if (wantsImpersonate && chosen.role === 'capiro_admin') {
                const session = await tx.impersonationSession.findFirst({
                    where: { actorUserId: user.id, endedAt: null, expiresAt: { gt: new Date() } },
                    include: { tenant: true },
                });
                if (!session) {
                    throw new common_1.ForbiddenException('No active impersonation session, start one via /capiro-admin/impersonate');
                }
                if (session.tenant.slug.toLowerCase() !== wantsImpersonate) {
                    throw new common_1.ForbiddenException(`Impersonation session is for tenant ${session.tenant.slug}, header asks for ${wantsImpersonate}`);
                }
                selectedAuthorityImpersonation = session.id;
                const context = {
                    tenantId: session.tenantId,
                    tenantSlug: session.tenant.slug,
                    userId: user.id,
                    clerkUserId: user.clerkUserId,
                    role: 'capiro_admin', // role stays, capiro_admin acting as
                };
                return context;
            }
            const context = {
                tenantId: chosen.tenantId,
                tenantSlug: chosen.tenant.slug,
                userId: user.id,
                clerkUserId: user.clerkUserId,
                role: chosen.role,
            };
            return context;
        });
        let ctx;
        try {
            ctx = await resolveContext();
        }
        catch (err) {
            // Record the denial AFTER the transaction has unwound.
            //
            // It cannot be written inline: the throw rolls the transaction back, so
            // an audit row inserted before it would vanish with everything else —
            // exactly the defect that made failed Clerk webhooks leave no trace. The
            // recorder therefore opens its own transaction.
            if (denial)
                await this.recordDenial(denial, claims.sub);
            throw err;
        }
        // Step 4, propagate via AsyncLocalStorage AND req object. ALS lets
        // services pull the context without prop drilling; req.tenantContext is
        // for the @CurrentTenant() decorator and direct controller access.
        req.tenantContext = ctx;
        if (selectedAuthorityMembership) {
            applicationAuthorityRequests.set(req, {
                context: ctx,
                claims: { ...claims },
                membershipId: selectedAuthorityMembership.id,
                membershipTenantId: selectedAuthorityMembership.tenantId,
                requestedSlug,
                impersonationId: selectedAuthorityImpersonation,
            });
        }
        this.store.run(ctx, () => next());
    }
    /** A fresh online session read followed by read-only current local checks.
     * The original authentication pipeline can provision/update/audit; this
     * method cannot repair missing authority or choose a different membership. */
    async readApplicationAuthority(req, ctx) {
        const denied = () => new common_1.ForbiddenException('Application authority unavailable');
        const provenance = applicationAuthorityRequests.get(req);
        if (!provenance || provenance.context !== ctx || ctx.clerkUserId !== provenance.claims.sub)
            throw denied();
        const session = await this.clerk.assertActiveApplicationAuthoritySession(provenance.claims);
        const evidence = await this.readCurrentApplicationAuthority(provenance, ctx, session);
        return { ...evidence, recheckCurrent: () => this.readCurrentApplicationAuthority(provenance, ctx, session) };
    }
    async readCurrentApplicationAuthority(provenance, ctx, session) {
        const denied = () => new common_1.ForbiddenException('Application authority unavailable');
        if (provenance.context !== ctx || ctx.clerkUserId !== provenance.claims.sub)
            throw denied();
        try {
            return await this.prisma.withSystem(async (tx) => {
                const user = await tx.user.findFirst({
                    where: { id: ctx.userId, clerkUserId: provenance.claims.sub }, select: { id: true, clerkUserId: true },
                });
                const membership = await tx.tenantMembership.findFirst({
                    where: { id: provenance.membershipId, tenantId: provenance.membershipTenantId, userId: ctx.userId, status: 'active' },
                    include: { tenant: true },
                });
                if (!user || user.id !== ctx.userId || user.clerkUserId !== provenance.claims.sub ||
                    !membership || membership.id !== provenance.membershipId || membership.userId !== ctx.userId ||
                    membership.tenantId !== provenance.membershipTenantId || membership.status !== 'active' ||
                    membership.role !== ctx.role || membership.tenant.id !== membership.tenantId ||
                    membership.tenant.status !== 'active')
                    throw denied();
                const claims = provenance.claims;
                if ((nonEmpty(claims.capiro_tenant_id) && membership.tenantId !== nonEmpty(claims.capiro_tenant_id)) ||
                    (nonEmpty(claims.org_id) && membership.tenant.clerkOrgId !== nonEmpty(claims.org_id)) ||
                    (nonEmpty(claims.capiro_tenant_slug) && membership.tenant.slug.toLowerCase() !== nonEmpty(claims.capiro_tenant_slug)?.toLowerCase()) ||
                    (provenance.requestedSlug && membership.tenant.slug !== provenance.requestedSlug))
                    throw denied();
                let impersonationFacts = null;
                let expiresAtMs = session.expiresAtMs;
                if (provenance.impersonationId !== null) {
                    if (membership.role !== 'capiro_admin')
                        throw denied();
                    const impersonation = await tx.impersonationSession.findFirst({
                        where: { id: provenance.impersonationId, actorUserId: ctx.userId, tenantId: ctx.tenantId, endedAt: null, expiresAt: { gt: new Date() } },
                        include: { tenant: true },
                    });
                    if (!impersonation || impersonation.id !== provenance.impersonationId ||
                        impersonation.actorUserId !== ctx.userId || impersonation.tenantId !== ctx.tenantId ||
                        impersonation.endedAt !== null || impersonation.tenant.id !== ctx.tenantId ||
                        impersonation.tenant.status !== 'active' || impersonation.tenant.slug !== ctx.tenantSlug)
                        throw denied();
                    expiresAtMs = Math.min(expiresAtMs, impersonation.expiresAt.getTime());
                    impersonationFacts = [impersonation.id, impersonation.actorUserId, impersonation.tenantId,
                        impersonation.startedAt.getTime(), impersonation.expiresAt.getTime(), impersonation.endedAt,
                        impersonation.tenant.status, impersonation.tenant.clerkOrgId];
                }
                else if (ctx.tenantId !== membership.tenantId || ctx.tenantSlug !== membership.tenant.slug)
                    throw denied();
                if (!Number.isSafeInteger(expiresAtMs) || expiresAtMs <= Date.now())
                    throw denied();
                return {
                    principal: { tenantId: ctx.tenantId, actorId: user.id },
                    identityRevision: (0, application_authority_js_1.applicationAuthorityRevision)('identity', [
                        [session.id, session.userId, session.status, session.createdAt, session.expireAt, session.abandonAt, session.actor],
                        [user.id, user.clerkUserId],
                        [membership.id, membership.tenantId, membership.userId, membership.role, membership.status, membership.updatedAt.getTime()],
                        [membership.tenant.id, membership.tenant.status, membership.tenant.clerkOrgId],
                        impersonationFacts,
                    ]),
                    expiresAtMs,
                };
            });
        }
        catch {
            throw denied();
        }
    }
    /**
     * Emit the SOC 2 evidence for a rejected request: a structured `auth.denied`
     * line (counted by the Capiro/Security metric filter) and, when a tenant was
     * actually resolved, an append-only audit_logs row its own admins can see.
     *
     * audit_logs.tenant_id is NOT NULL, so the two pre-resolution reasons
     * (no_active_membership, no_matching_tenant) get the log line only — there is
     * no tenant to attribute them to yet.
     *
     * The claimed-vs-resolved pair is encoded in `action` + `entityId` rather than
     * before/after, because the customer-facing audit projection redacts those.
     *
     * Entirely best-effort: this is telemetry on a path that is ALREADY failing,
     * and it must never convert a clean 403 into a 500.
     */
    async recordDenial(denial, clerkUserId) {
        this.logger.warn((0, shared_1.authDeniedEvent)({
            reason: denial.reason,
            surface: 'http',
            tenantId: denial.tenantId,
            claimedTenantId: denial.claimedTenantId,
            clerkUserId,
        }));
        if (!denial.tenantId)
            return;
        try {
            await this.prisma.withSystem((tx) => tx.auditLog.create({
                data: {
                    tenantId: denial.tenantId,
                    actorUserId: null,
                    actorRole: null,
                    action: `auth.denied.${denial.reason}`,
                    entityType: 'tenant',
                    // The CLAIMED id, never the resolved one — that is the fact under
                    // review.
                    entityId: denial.claimedTenantId ?? null,
                },
            }));
        }
        catch (auditErr) {
            this.logger.error(`auth-denial audit write failed: ${auditErr.message}`);
        }
    }
    /**
     * Provision a local tenant_membership from a verified Clerk JWT when the
     * webhook-populated mirror is missing it. Returns the membership (with its
     * tenant) to use, or null if it cannot / must not be provisioned.
     *
     * Safety rules (this is an authorization path — fail closed):
     *   - The tenant is resolved by `clerk_org_id === org_id`, and org_id is a
     *     verified JWT claim, so we only ever provision a tenant the JWT already
     *     proves the user is a Clerk member of.
     *   - If the JWT also carries capiro_tenant_id / capiro_tenant_slug, they
     *     MUST agree with the resolved tenant (the same integrity checks the
     *     caller applies post-resolution), otherwise we bail.
     *   - The tenant must be active.
     *   - A pre-existing non-active membership (removed/suspended) is NOT
     *     resurrected: offboarding stays sticky and must be redone via the normal
     *     invite flow.
     */
    async selfHealMembership(tx, userId, hints) {
        const tenant = await tx.tenant.findUnique({ where: { clerkOrgId: hints.claimedOrgId } });
        if (!tenant || tenant.status !== 'active') {
            return null;
        }
        if (hints.claimedTenantId && tenant.id !== hints.claimedTenantId) {
            return null;
        }
        if (hints.claimedTenantSlug &&
            tenant.slug.toLowerCase() !== hints.claimedTenantSlug.toLowerCase()) {
            return null;
        }
        const existing = await tx.tenantMembership.findUnique({
            where: { tenantId_userId: { tenantId: tenant.id, userId } },
            include: { tenant: true },
        });
        if (existing) {
            // A row exists but was not in the active set (removed/suspended). Do not
            // silently re-grant access; require an explicit re-invite.
            return existing.status === 'active' ? existing : null;
        }
        // Mirror the webhook's role derivation exactly, keyed on the DB tenant slug
        // (authoritative) rather than the JWT's org_slug claim.
        const role = (0, clerk_role_util_js_1.mapClerkRoleToCapiro)(tenant.slug, hints.orgRole ?? 'org:member');
        return tx.tenantMembership.create({
            data: {
                tenantId: tenant.id,
                userId,
                role,
                status: 'active',
                joinedAt: new Date(),
            },
            include: { tenant: true },
        });
    }
    resolveRequestedTenantSlug(req) {
        const headerVal = req.header(shared_1.TENANT_HEADER);
        if (headerVal)
            return headerVal.trim().toLowerCase();
        const host = req.hostname; // e.g. acmelobby.app.capiro.ai
        const parts = host.split('.');
        // {slug}.app.capiro.ai, only treat as a tenant slug when the shape AND
        // TLD match. Strict matching prevents a malicious host header from
        // injecting an arbitrary slug via a lookalike domain.
        if (parts.length === 4 && parts[1] === 'app' && parts[2] === 'capiro' && parts[3] === 'ai') {
            return parts[0]?.toLowerCase();
        }
        return undefined;
    }
};
exports.TenantContextMiddleware = TenantContextMiddleware;
exports.TenantContextMiddleware = TenantContextMiddleware = TenantContextMiddleware_1 = __decorate([
    (0, common_1.Injectable)(),
    __metadata("design:paramtypes", [clerk_service_js_1.ClerkService,
        prisma_service_js_1.PrismaService,
        tenant_context_store_js_1.TenantContextStore])
], TenantContextMiddleware);
// Clerk's JWT template emits empty strings for `{{org.*}}` placeholders when
// the user has no active org. We treat empty as "no signal" rather than
// matching a tenant whose slug is literally "".
function nonEmpty(value) {
    if (value === undefined || value === null)
        return undefined;
    const trimmed = value.trim();
    return trimmed === '' ? undefined : trimmed;
}
function isBypassPath(bypassPath, path, originalUrl, baseUrl) {
    return (path === bypassPath ||
        originalUrl === bypassPath ||
        path.startsWith(`${bypassPath}/`) ||
        originalUrl.startsWith(`${bypassPath}/`) ||
        originalUrl.startsWith(`${bypassPath}?`) ||
        `${baseUrl}${path}` === bypassPath);
}
//# sourceMappingURL=tenant-context.middleware.js.map