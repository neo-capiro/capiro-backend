"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.configSchema = void 0;
exports.validateConfig = validateConfig;
const ai_model_policy_1 = require("@capiro/shared/ai-model-policy");
const shared_1 = require("@capiro/shared");
const zod_1 = require("zod");
const engagement_runtime_env_js_1 = require("../engagement/runtime/engagement-runtime-env.js");
/**
 * Meri rollout mode switches (docs/meri/grounding/stage-0/FEATURE-FLAG.md): a
 * blank or whitespace-only value means "unset" and fails closed to `off` in the
 * meriv2-core resolver, so it must not crash API boot here either — this schema
 * is the Nest bootstrap gate, and the runbook's rollback step hand-edits ECS task
 * definitions to `""`. Non-blank unknown values stay rejected: a typo must never
 * silently read as `off`.
 */
const blankToUndefined = (value) => typeof value === 'string' && value.trim() === '' ? undefined : value;
const normalizeOptionalSwitch = (value) => typeof value === 'string' ? blankToUndefined(value.trim().toLowerCase()) : value;
const rolloutModeSwitch = () => zod_1.z.preprocess(normalizeOptionalSwitch, zod_1.z.enum(['off', 'shadow', 'enforce']).optional());
const DEFAULT_RESEARCH_TOTAL_TOKENS = 120_000;
const DEFAULT_RESEARCH_MAX_COST_USD = (DEFAULT_RESEARCH_TOTAL_TOKENS / 1_000_000) *
    Math.max(...Object.values(shared_1.AI_PRICING).map((price) => price.outputPerM));
exports.configSchema = zod_1.z.object({
    NODE_ENV: zod_1.z.enum(['development', 'staging', 'production', 'test']).default('development'),
    LOG_LEVEL: zod_1.z.enum(['debug', 'info', 'warn', 'error']).default('info'),
    API_PORT: zod_1.z.coerce.number().int().positive().default(4000),
    API_BIND_HOST: zod_1.z.string().default('0.0.0.0'),
    DATABASE_URL: zod_1.z.string().url(),
    CLERK_SECRET_KEY: zod_1.z.string().min(1, 'CLERK_SECRET_KEY is required'),
    CLERK_WEBHOOK_SIGNING_SECRET: zod_1.z.string().min(1, 'CLERK_WEBHOOK_SIGNING_SECRET is required'),
    CLERK_JWT_ISSUER: zod_1.z.string().url().optional(),
    WEB_ORIGIN: zod_1.z.string().optional(),
    // Tenant assets bucket (logos, future documents).
    ASSETS_BUCKET: zod_1.z.string().optional(),
    DIRECTORY_S3_BUCKET: zod_1.z.string().optional(),
    DIRECTORY_S3_PREFIX: zod_1.z.string().optional(),
    DIRECTORY_S3_LATEST_KEY: zod_1.z.string().default('UPDATED DIRECTORY/LATEST.json'),
    // LegiStorm is used only by the scheduled directory-refresh CLI. Keep the key
    // optional at API-server boot; the CLI itself fails closed when it is absent.
    LEGISTORM_API_KEY: zod_1.z.string().min(1).optional(),
    LEGISTORM_BASE_URL: zod_1.z
        .string()
        .url()
        .refine((value) => new URL(value).protocol === 'https:', 'LEGISTORM_BASE_URL must use HTTPS')
        .default('https://api.legistorm.com/v2.019.10/congress'),
    // LegiStorm caps `limit` at 100 per request; larger values return HTTP 422.
    LEGISTORM_PAGE_SIZE: zod_1.z.coerce.number().int().positive().max(100).default(100),
    LEGISTORM_MAX_PAGES: zod_1.z.coerce.number().int().positive().default(10_000),
    LEGISTORM_REQUEST_DELAY_MS: zod_1.z.coerce.number().int().nonnegative().default(400),
    LEGISTORM_REQUEST_TIMEOUT_MS: zod_1.z.coerce.number().int().positive().default(30_000),
    LEGISTORM_MAX_RETRY_DELAY_MS: zod_1.z.coerce.number().int().positive().default(30_000),
    LEGISTORM_OVERLAP_DAYS: zod_1.z.coerce.number().int().nonnegative().default(2),
    // Legislative Districts API (WS-B, LegiStorm gaps/enrichment plan) — a
    // DIFFERENT base URL than LEGISTORM_BASE_URL above (that one is the
    // Congressional API, v2.019.10/congress). Used only by the scheduled
    // districts-refresh CLI (sync-legistorm-districts), which ALSO hardcodes
    // this same value as its own fallback — so an incomplete env-wiring never
    // silently sends a districts request to the congress endpoint.
    LEGISTORM_DISTRICTS_BASE_URL: zod_1.z
        .string()
        .url()
        .refine((value) => new URL(value).protocol === 'https:', 'LEGISTORM_DISTRICTS_BASE_URL must use HTTPS')
        .default('https://api.legistorm.com/v2.023.07/legislative_districts'),
    AWS_REGION_DEFAULT: zod_1.z.string().default('us-east-1'),
    // Census ACS 5-year demographics sync (District Nexus). Secret already
    // provisioned out-of-band as capiro/<env>/census_api_key. Used only by the
    // scheduled sync-census CLI; optional at API-server boot so the long-lived
    // serve/migrate tasks don't require it (mirrors LEGISTORM_API_KEY above).
    CENSUS_API_KEY: zod_1.z.string().min(1).optional(),
    // PE Watch defense-budget ingestion (Step: LlamaParse + immutable S3 archive).
    // LLAMA_CLOUD_API_KEY is optional at API-server boot; only the ingestion CLI
    // (ingest-defense-budget-pdf) hard-requires it and fails closed when absent.
    LLAMA_CLOUD_API_KEY: zod_1.z.string().min(1).optional(),
    LLAMA_CLOUD_BASE_URL: zod_1.z
        .string()
        .url()
        .refine((v) => new URL(v).protocol === 'https:', 'LLAMA_CLOUD_BASE_URL must use HTTPS')
        .default('https://api.cloud.llamaindex.ai'),
    // Immutable raw-archive bucket (Object Lock GOVERNANCE, dedicated KMS CMK).
    // A SourceDocument row is NOT proof of archival; the ingestion pipeline writes
    // original bytes here BEFORE parsing and records the returned VersionId.
    DEFENSE_BUDGET_RAW_BUCKET: zod_1.z.string().optional(),
    DEFENSE_BUDGET_AUDIT_BUCKET: zod_1.z.string().optional(),
    DEFENSE_BUDGET_RAW_KMS_KEY_ARN: zod_1.z.string().optional(),
    DEFENSE_BUDGET_RETENTION_YEARS: zod_1.z.coerce.number().int().positive().default(7),
    // ── Phase 7 Workstream M — canonical read cutover (all inert by default) ───
    // Which source a Program Elements read is served from. 'legacy' = today's
    // mutable program_element* tables, exactly as now; 'shadow' = serve legacy but
    // compute the snapshot response and compare digests; 'snapshot_canary' = serve
    // the snapshot to PE_SNAPSHOT_CANARY_TENANTS only, still comparing for
    // everyone; 'snapshot' = serve the snapshot to all. Defaults to 'legacy', so
    // the whole workstream lands inert — same shape as KG_TRAVERSAL_SOURCE below.
    //
    // No active snapshot forces 'legacy' regardless of this setting: a snapshot
    // read with no activation pointer is a product outage, not an empty result.
    PE_SNAPSHOT_READ_MODE: zod_1.z
        .enum(['legacy', 'shadow', 'snapshot_canary', 'snapshot'])
        .default('legacy'),
    // Comma-separated tenant ids promoted to snapshot reads while the mode is
    // 'snapshot_canary'. Ignored in every other mode.
    PE_SNAPSHOT_CANARY_TENANTS: zod_1.z.string().optional(),
    // Phase 7 Gap 5 decision C — the canary rollback switch. Defaults to
    // 'off', same shape as PE_LEGACY_BUDGET_WRITES below. 'on' forces every read
    // to legacy regardless of PE_SNAPSHOT_READ_MODE — a single, unambiguous
    // lever an operator can flip without redeploying the mode itself.
    // See canary-controls-v1.ts's resolveCanaryRollbackV1.
    PE_SNAPSHOT_CANARY_ROLLBACK: zod_1.z.enum(['off', 'on']).default('off'),
    // The Workstream M kill switch. 'off' (default) refuses --commit on the twelve
    // dispatcher verbs that write canonical budget rows directly; canonical data
    // enters through the promotion workflow instead. 'allow' is the deliberate
    // operator override, and it is itself overridden by a snapshot or canary read
    // mode — a legacy write underneath snapshot reads produces a divergence
    // indistinguishable from a promotion defect.
    PE_LEGACY_BUDGET_WRITES: zod_1.z.enum(['off', 'allow']).default('off'),
    // Optional AI providers. Meeting prep endpoints fail closed with 503 until
    // one provider key is configured; they never return canned prep.
    AI_PROVIDER: zod_1.z.enum(['openai', 'anthropic']).optional(),
    OPENAI_API_KEY: zod_1.z.string().optional(),
    OPENAI_MODEL: zod_1.z.string().default('gpt-6-astra').transform(ai_model_policy_1.upgradeTextModel),
    ANTHROPIC_API_KEY: zod_1.z.string().optional(),
    ANTHROPIC_MODEL: zod_1.z.string().default('claude-sonnet-5').transform(ai_model_policy_1.upgradeTextModel),
    // Meeting-debrief model overrides (scoped to generateMeetingDebrief ONLY — the
    // notetaker summary + the manual "Generate Debrief" flow — so bumping the debrief
    // model never changes prep / talking-points / outreach / campaign, which keep
    // reading OPENAI_MODEL / ANTHROPIC_MODEL). Unlike OUTREACH_DRAFT_MODEL these
    // default to a concrete better-than-mini/haiku model rather than '' because the
    // upgrade is the intended behavior: debriefs must not run on gpt-4.1-mini or
    // claude-haiku. Both ids are already in AI_PRICING so COGS stays correct. A
    // tenant's explicit BYOK modelOverride still wins over these (see
    // generateMeetingDebrief). Set to '' to fall back to the global model.
    DEBRIEF_OPENAI_MODEL: zod_1.z.string().default('gpt-6-astra').transform(ai_model_policy_1.upgradeTextModel),
    DEBRIEF_ANTHROPIC_MODEL: zod_1.z.string().default('claude-sonnet-5').transform(ai_model_policy_1.upgradeTextModel),
    // Comprehensive meeting-prep model overrides (scoped to the durable briefing
    // job ONLY; the interactive prep, talking points and outreach keep reading
    // OPENAI_MODEL / ANTHROPIC_MODEL). Extracting, synthesizing and reviewing
    // hundreds of quoted facts needs a reasoning-capable model — gpt-4.1-mini and
    // haiku exhaust the bounded repair loop and fail the job. A tenant's explicit
    // BYOK modelOverride still wins. Set to '' to fall back to the global model.
    MEETING_PREP_OPENAI_MODEL: zod_1.z.string().default('gpt-6-astra').transform(ai_model_policy_1.upgradeTextModel),
    MEETING_PREP_ANTHROPIC_MODEL: zod_1.z.string().default('claude-sonnet-5').transform(ai_model_policy_1.upgradeTextModel),
    // Phase 1 SSOT-consolidation recall source (docs/plans/…phase-1-ssot-cutover-plan.md).
    // Governs where Meri's learned-fact recall (loadRelevantMemories) reads from:
    //   'clio'       — clio_memory.embedding (OpenAI), today's behavior. DEFAULT.
    //   'union'      — clio-recall ∪ projection-recall (memory_items→context_embeddings,
    //                  Titan), deduped. A SUPERSET: projection failures are caught and
    //                  degrade to clio-only, so recall can never drop below 'clio'.
    //   'projection' — projection only (the collapse). Flip ONLY after 'union' is
    //                  observed stable and diag-memory-recall-parity reads
    //                  wouldDropOnCollapse=0 for every tenant.
    // Out-of-band flag flip, never on by a code deploy alone. Landed inert at 'clio'.
    MEMORY_RECALL_SOURCE: zod_1.z.enum(['clio', 'union', 'projection']).default('clio'),
    // Relevance floor for the PROJECTION recall path (memory_items →
    // context_embeddings, Titan v2 cosine similarity). The clio path has always
    // floored at score > 0.3 (OpenAI space — semanticMemorySearch); the
    // projection path shipped with none, so when nothing relevant exists the
    // LIMIT still fills with weak tail matches. Titan and OpenAI similarity
    // scales are NOT comparable; measured on dev memory-item embeddings
    // (2026-07-19, n=7503): random-pair (unrelated) p50 0.091 / p99 0.383;
    // nearest-neighbor (related) p10 0.509 / p50 0.869. Default 0.4 sits between
    // the noise p99 and the related p10. Re-tune against real query traffic
    // during the 'union' canary; 0 disables the floor.
    MEMORY_PROJECTION_MIN_SCORE: zod_1.z.coerce.number().min(0).max(1).default(0.4),
    // (Phase 4's MEMORY_CONFIDENCE_WEIGHT was superseded by the unified Phase 5
    // reranker — confidence is now one weight in MEMORY_RECALL_W_CONFIDENCE under
    // the MERI_RECALL_RERANK switch below.)
    // Phase 4 — write-path confidence floor for MODEL-extracted memories
    // (auto-learn). Default 0.7 reproduces the previously-hardcoded gate exactly
    // (meri.service.ts maybeLearnFromConversation). A model extraction below this
    // is not auto-committed; explicit human saves are unscored and unaffected.
    MEMORY_MIN_WRITE_CONFIDENCE: zod_1.z.coerce.number().min(0).max(1).default(0.7),
    // ── Phase 5 — retrieval quality (memory-scoring.helpers.ts) ────────────────
    // Master switch for unified similarity+recency+confidence recall fusion.
    // 'off' (default) = pure-cosine order, byte-identical to pre-Phase-5. Flip
    // to 'on' out-of-band, canaried per tenant via
    // settings_jsonb.clioFeatureFlags.meriRecallRerank, after the union canary.
    MERI_RECALL_RERANK: zod_1.z.enum(['off', 'on']).default('off'),
    // Recency half-life (days): a memory that hasn't been confirmed/updated in
    // this many days contributes half its recency factor. Long by default so a
    // durable fact ("HQ is DC") is barely penalized; tune during canary.
    MEMORY_RECALL_HALFLIFE_DAYS: zod_1.z.coerce.number().min(1).default(180),
    // Fusion weights (normalized to sum 1 at use). Defaults keep similarity
    // dominant so rerank only reorders near-ties by recency/confidence.
    MEMORY_RECALL_W_SIM: zod_1.z.coerce.number().min(0).default(0.6),
    MEMORY_RECALL_W_RECENCY: zod_1.z.coerce.number().min(0).default(0.25),
    MEMORY_RECALL_W_CONFIDENCE: zod_1.z.coerce.number().min(0).default(0.15),
    // Over-fetch multiplier when rerank is on: fetch K×N (capped 30) candidates so
    // a fresh/confident row the raw top-K would have dropped can be promoted.
    MEMORY_RECALL_OVERFETCH: zod_1.z.coerce.number().int().min(1).max(10).default(3),
    // Neutral confidence prior for rows with no confidence (unscored/human/legacy).
    MEMORY_RECALL_NEUTRAL_CONFIDENCE: zod_1.z.coerce.number().min(0).max(1).default(0.75),
    // Clio (OpenAI-space) recall floor — was hardcoded 0.3 in semanticMemorySearch;
    // now configurable, default 0.3 = exact parity.
    MEMORY_CLIO_MIN_SCORE: zod_1.z.coerce.number().min(0).max(1).default(0.3),
    // Context assembly budget unit. 'chars' (default) = today's behavior exactly;
    // 'tokens' switches truncation to the shared token estimator (provably ~inert
    // at the calibrated ratio). Flip out-of-band once token parity is confirmed.
    MERI_CONTEXT_BUDGET_UNIT: zod_1.z.enum(['chars', 'tokens']).default('chars'),
    // ── Phase 6 — governed ingestion + retention (all default OFF/inert) ───────
    // IMPORTANT: these use the house string-allowlist transform, NOT
    // z.coerce.boolean() — the latter coerces via Boolean(str), so ANY non-empty
    // value (incl. 'false'/'0'/'off') would evaluate TRUE and ARM a destructive
    // route. Here ONLY 'true'/'1'/'yes'/'on' enable; anything else (incl. unset,
    // 'false') stays off. Never rely on writing '=false' to disable — leave unset.
    //
    // MEMORY_PURGE_ENABLED — master switch for the retention purge routes + script
    // execute path. Off ⇒ POST /memory/purge/* returns 503 and the script refuses
    // --execute. (The other three are RESERVED — see note below.)
    MEMORY_PURGE_ENABLED: zod_1.z
        .string()
        .default('false')
        .transform((v) => ['true', '1', 'yes', 'on'].includes(v.trim().toLowerCase())),
    // Governed conversation learning. False (default) means post-turn processing
    // performs no persistent memory write. True permits source-anchored USER-text
    // extraction into memory_candidate only; it never auto-promotes active memory.
    MEMORY_AUTOLEARN_GOVERNED: zod_1.z
        .string()
        .default('false')
        .transform((v) => ['true', '1', 'yes', 'on'].includes(v.trim().toLowerCase())),
    // RESERVED (NO-OP today): GET /memory/learned surface is not yet implemented.
    MEMORY_LEARNED_SURFACE_ENABLED: zod_1.z
        .string()
        .default('false')
        .transform((v) => ['true', '1', 'yes', 'on'].includes(v.trim().toLowerCase())),
    // RESERVED (NO-OP today): the nightly retention-policy purge pass is not yet
    // implemented in refresh-memory-graph.
    MEMORY_RETENTION_SWEEP: zod_1.z
        .string()
        .default('false')
        .transform((v) => ['true', '1', 'yes', 'on'].includes(v.trim().toLowerCase())),
    // Phase 7A — recall-miss observability. Emit CloudWatch EMF metrics at the
    // memory-recall boundary (hit / empty / error). Default 'on' (side-effect-only,
    // never changes recall behavior); flip to 'off' as a kill-switch if noisy.
    MERI_CONTEXT_METRICS: zod_1.z.enum(['on', 'off']).default('on'),
    // ── Track B — knowledge-graph revival (all dark by default) ────────────────
    // Master traversal source. 'legacy' = today's per-request System A build;
    // 'cache' = the materialized kg_edge_cache + bounded scoped traversal (needs
    // migrations 20260722010000/020000 clone-rehearsed first). Landed inert.
    KG_TRAVERSAL_SOURCE: zod_1.z.enum(['legacy', 'cache']).default('legacy'),
    // The intel per-client KG endpoint (getKnowledgeGraph → unscoped kg_walk).
    // 'off' (default) ⇒ 404/503: closes the orphaned, RLS-exempt, unscoped live
    // surface until the scoped bounded traversal replaces it. 'scoped' re-enables
    // it on the wall/tenant-scoped path only.
    KG_INTEL_GRAPH: zod_1.z.enum(['off', 'scoped']).default('off'),
    // GraphRAG fusion into Meri recall. Default off; per-tenant canary via
    // settings_jsonb.clioFeatureFlags.meriRecallGraph. Fail-safe (graph failure
    // never blanks recall). Inert until the cache substrate + fusion land.
    MERI_RECALL_GRAPH: zod_1.z
        .string()
        .default('false')
        .transform((v) => ['true', '1', 'yes', 'on'].includes(v.trim().toLowerCase())),
    // Outreach prompt-assembly version (plan W2). 'v1' = the legacy single-string
    // prompt + JSON context dump; 'v2' = PromptSpec v2 (real system prompt, context
    // precedence ladder, spotlighted untrusted content, no raw JSON dump). Defaults
    // to 'v1' so the flip is an explicit, out-of-band config change validated by the
    // outreach evals A/B (W2.7) — never on by a code deploy alone.
    OUTREACH_PROMPT_SPEC: zod_1.z.enum(['v1', 'v2']).default('v1'),
    // Outreach task-tier model config (plan W3.2 / D2). OPT-IN, exactly like the
    // prompt-spec + async flags: defaults preserve current behavior (global
    // provider order + the resolved cred model, i.e. today's gpt-4.1-mini/haiku),
    // so a code deploy NEVER silently changes the drafting model or COGS. The D2
    // flip — prefer Anthropic + draft on claude-sonnet-4-6 — is an explicit
    // out-of-band env set (OUTREACH_PROVIDER=anthropic, OUTREACH_DRAFT_MODEL=
    // claude-sonnet-4-6) applied per the task-def recipe AFTER eval validation +
    // Ninja's COGS sign-off. Empty OUTREACH_DRAFT_MODEL = no override. FAST_MODEL
    // is reserved for cheaper sub-tasks as they migrate onto the tiered client.
    OUTREACH_PROVIDER: zod_1.z.enum(['openai', 'anthropic']).optional(),
    OUTREACH_DRAFT_MODEL: zod_1.z.string().default('').transform(ai_model_policy_1.upgradeTextModel),
    OUTREACH_FAST_MODEL: zod_1.z.string().default('').transform(ai_model_policy_1.upgradeTextModel),
    // Reasoning depth for governed Outreach V3 generation (planning + drafting).
    //
    // Defaults to the top of the ladder because a governed campaign draft is the
    // highest-stakes, lowest-volume generation in the product: three review samples
    // and then one draft per recipient, each of which a human approves before it
    // can be sent. This is NOT a silent behaviour change for existing models —
    // reasoning-effort.ts sends a reasoning parameter only to models that accept
    // one, and both live models (OPENAI_MODEL/OUTREACH_V3_REASONING_MODEL =
    // gpt-4.1-mini) accept none, so the effort applies the moment a reasoning model
    // is configured and is inert until then.
    OUTREACH_V3_GENERATION_EFFORT: zod_1.z.enum(['low', 'medium', 'high', 'xhigh', 'max']).default('max'),
    // Model override for V3 generation only. Empty (the default) keeps the resolved
    // credential's model, so a deploy never changes the drafting model or COGS on
    // its own — the same discipline OUTREACH_DRAFT_MODEL follows. Set this to a
    // reasoning model for OUTREACH_V3_GENERATION_EFFORT to have any effect.
    OUTREACH_V3_GENERATION_MODEL: zod_1.z.string().default('').transform(ai_model_policy_1.upgradeTextModel),
    // How many recipients the full-generation worker drafts CONCURRENTLY within a
    // claimed batch.
    //
    // This used to be effectively 1: the worker claimed `batchSize` items then
    // awaited them one at a time in a `for` loop. Measured live 2026-08-24 on
    // gpt-5 at effort=max, a single draft takes 94-683s (mean ~395s), so a
    // 51-recipient campaign projected to ~5.6 HOURS of wall clock while issuing
    // one provider call at a time.
    //
    // Each unit of concurrency is one additional in-flight provider request per
    // worker process, so this is a direct COGS/rate-limit dial, not free speed.
    // Default 4 is deliberately modest: ~4x faster with headroom under provider
    // rate limits, and it keeps a single stuck draft from stalling the batch.
    // Set 1 to restore the old strictly-serial behaviour.
    OUTREACH_V3_GENERATION_CONCURRENCY: zod_1.z.coerce.number().int().min(1).max(16).default(4),
    // Ships DARK: default false, so nothing about the existing draft-generation
    // path changes until this is explicitly flipped on.
    //
    // When true, the draft call (only the draft — the Message Plan call stays
    // non-streaming; its output is internal structured JSON with no UI value in
    // showing partial fragments) uses completeStreaming() instead of complete().
    // The FINAL result is byte-identical either way — same parse, same schema
    // validation, same verifiers — this only adds a live preview of the body
    // text as it's written, surfaced to the Drafts step so the multi-minute
    // wait isn't a silent blank spinner.
    //
    // Streaming is implemented for OpenAI only today (the pinned outreach
    // provider); LlmCompletionService.completeStreaming() silently falls back
    // to the non-streaming path for Anthropic regardless of this flag.
    //
    // The live preview is held in an in-memory, per-process store
    // (OutreachV3LivePreviewService) — correct only when engagement-api runs as
    // a single instance, as it does today (capiro-dev-engagement-api is
    // desiredCount=1). Flip this on only after a live smoke test with real
    // credentials confirms the SSE event shapes this was written against
    // (response.output_text.delta / response.completed) match what the
    // Responses API actually sends — unverifiable from a dev sandbox with no
    // live model credentials, same reason WEB_SURFACE and
    // ENGAGEMENT_API_FULL_OWNERSHIP both shipped dark before their own rollout.
    // Uses the house string-allowlist transform (NOT z.coerce.boolean() — see
    // the Phase 6 note above), so only 'true'/'1'/'yes'/'on' enable and anything
    // else (incl. unset) stays off.
    OUTREACH_V3_GENERATION_STREAMING_ENABLED: zod_1.z
        .string()
        .default('false')
        .transform((v) => ['true', '1', 'yes', 'on'].includes(v.trim().toLowerCase())),
    // Per-tenant daily outreach token ceiling (plan W3.4 / A7): total (input +
    // output) AI tokens across outreach generation workflows in the current UTC
    // day. Soft-warn at 80% (generation proceeds, wizard shows a banner), hard-stop
    // at 100% (typed 429 the wizard renders). Default is generous (6M ≈ 5M in / 1M
    // out); set 0 to disable the ceiling entirely.
    OUTREACH_DAILY_TOKEN_BUDGET: zod_1.z.coerce.number().int().nonnegative().default(6_000_000),
    // Async outreach pipeline flags (plan W4). When ON, generate/send run as
    // Postgres jobs off the request path (past the ALB idle ceiling); OFF keeps the
    // synchronous endpoints. Rolled out independently and default OFF so the async
    // path is opt-in per environment until canary-verified.
    OUTREACH_ASYNC_GEN: zod_1.z
        .string()
        .default('false')
        .transform((v) => ['true', '1', 'yes', 'on'].includes(v.trim().toLowerCase())),
    OUTREACH_ASYNC_SEND: zod_1.z
        .string()
        .default('false')
        .transform((v) => ['true', '1', 'yes', 'on'].includes(v.trim().toLowerCase())),
    // Worker cadence + how long a claimed item may sit before it is considered
    // abandoned (crash) and reclaimed. Generation reclaim is safe (at-least-once);
    // send items stuck in 'sending' are NOT auto-reclaimed (at-most-once).
    OUTREACH_JOB_SWEEP_MS: zod_1.z.coerce.number().int().positive().default(5_000),
    OUTREACH_JOB_STALE_MS: zod_1.z.coerce.number().int().positive().default(120_000),
    // Engagement Phase 0 — trust boundary + external-send integrity.
    //
    // ENGAGEMENT_VERSIONED_OUTREACH: when ON, every externally sendable draft is
    // an immutable, audited outreach_draft_versions row, real sending goes through
    // durable send intents (version ids only), and the legacy raw-body
    // POST /outreach/send-batch route is refused for real sends. OFF keeps the
    // pre-Phase-0 synchronous path byte-for-byte, so the migration + new API can
    // deploy inert and be enabled per environment afterwards.
    //
    // ENGAGEMENT_EXTERNAL_SEND_V2_REQUIRED: when ON, a REAL (non-test) send is
    // refused unless the draft version was produced under PromptSpec v2 or later.
    // Independent of the flag above so a canary can turn versioning on first and
    // gate prompt quality separately.
    //
    // Both default OFF in repository code: enabling either is an explicit
    // out-of-band environment change, never a consequence of a code deploy.
    ENGAGEMENT_VERSIONED_OUTREACH: zod_1.z
        .string()
        .default('false')
        .transform((v) => ['true', '1', 'yes', 'on'].includes(v.trim().toLowerCase())),
    ENGAGEMENT_EXTERNAL_SEND_V2_REQUIRED: zod_1.z
        .string()
        .default('false')
        .transform((v) => ['true', '1', 'yes', 'on'].includes(v.trim().toLowerCase())),
    // Engagement Phase 1 — governed generation gateway + evidence packets.
    //
    // ENGAGEMENT_GENERATION_GATEWAY: Engagement generation runs through
    // GenerationGatewayService — server-rehydrated evidence, authenticated
    // directives separated from untrusted text, a synchronously persisted Evidence
    // Packet (fail-CLOSED), a validated Message Plan before any prose, and the
    // deterministic claim verifier.
    //
    // Knowledge Plane Phase 26 changed this flag's meaning. It used to default
    // false, and the OFF branch compiled an ungoverned ContextPacket straight
    // through the shared compiler while outreach.generate was already registered
    // packet_required — an ungoverned live path behind a "safe default". Phase 26
    // deleted every OFF branch, so:
    //   - the default is now TRUE, and
    //   - setting it false no longer selects a legacy path. `enabled` is retained
    //     for the gateway's own diagnostics but is not read as a fork, so an
    //     environment override neither restores the old behaviour nor disables
    //     governance.
    // Rollback for Outreach generation is therefore code-revert only, NOT an
    // environment flip. Do not treat this variable as a kill switch.
    //
    // ENGAGEMENT_EMAIL_CONTEXT_SCOPE: how broadly relevant-email evidence may be
    // drawn. 'mine' (default) = the current user's own connected mailbox only.
    // 'firm_shared' additionally allows explicitly client-linked threads owned by
    // colleagues — and requires BOTH this value AND the per-tenant setting
    // settings.clioFeatureFlags.engagementFirmMailContext, AND an ethical-wall
    // pass. The browser can never escalate scope by sending a string.
    //
    // ENGAGEMENT_ATTACHMENT_SCAN_REQUIRED: when ON, a quarantined/threat/failed/
    // unsupported/access-denied attachment cannot be extracted, selected as
    // context, downloaded, or sent. Ships FALSE because no production malware
    // scanner is provisioned yet (Phase 1 §6.1 — a Neo decision); while false the
    // UI must state that a file was not scanned rather than imply it was clean.
    //
    // ENGAGEMENT_EMAIL_CONTEXT_SCOPE and ENGAGEMENT_ATTACHMENT_SCAN_REQUIRED still
    // default to the SAFE value in repository code: changing either is an explicit
    // out-of-band environment change, never a code-deploy effect.
    // ENGAGEMENT_GENERATION_GATEWAY is the exception — see above.
    ENGAGEMENT_GENERATION_GATEWAY: zod_1.z
        .string()
        .default('true')
        .transform((v) => ['true', '1', 'yes', 'on'].includes(v.trim().toLowerCase())),
    ENGAGEMENT_EMAIL_CONTEXT_SCOPE: zod_1.z.enum(['mine', 'firm_shared']).default('mine'),
    ENGAGEMENT_ATTACHMENT_SCAN_REQUIRED: zod_1.z
        .string()
        .default('false')
        .transform((v) => ['true', '1', 'yes', 'on'].includes(v.trim().toLowerCase())),
    // Engagement Phase 2 — per-artifact approval + sharing (plan §d).
    //
    // ENGAGEMENT_ARTIFACT_SHARING_V2: when ON, sharing moves from whole-meeting
    // (shareMeeting/unshareMeeting flipping Meeting.visibility as one unit) to
    // per-artifact (POST .../meetings/:id/artifacts/share|unshare, gated on each
    // target artifact being individually approved first). While ON,
    // shareMeeting() is refused outright — callers must use the artifacts/share
    // endpoint — and unshareMeeting() becomes an authorization-gated "unshare
    // everything on this meeting" bulk action instead of an unconditional flip.
    // Meeting.visibility becomes a DERIVED summary of "does any artifact on this
    // meeting currently have sharedAt set", rather than an independently-set
    // field. OFF (default) keeps the pre-Phase-2 whole-meeting share/unshare
    // byte-for-byte, so the migration + new endpoints land inert and are
    // enabled per environment afterwards.
    ENGAGEMENT_ARTIFACT_SHARING_V2: zod_1.z
        .string()
        .default('false')
        .transform((v) => ['true', '1', 'yes', 'on'].includes(v.trim().toLowerCase())),
    // Engagement auto-sync scheduler: periodic reconciliation syncs for connected
    // M365/Google mailboxes. Webhooks are a latency optimization, NOT a
    // reliability mechanism — Graph subscriptions expire after 6 days and were
    // only renewed during syncs, so webhook-only connections went permanently
    // silent (observed: mailboxes stale for weeks while showing "connected").
    // The scheduler guarantees eventual freshness, renews subscriptions, and
    // pulls quiet mailboxes through backfills. Kill-switch: set false/0/no/off.
    ENGAGEMENT_AUTO_SYNC: zod_1.z
        .string()
        .default('true')
        .transform((v) => ['true', '1', 'yes', 'on'].includes(v.trim().toLowerCase())),
    // Per-connection sync cadence. Delta syncs are cheap (changes-only); 20 min
    // keeps Gmail historyId cursors alive and folder coverage fresh.
    ENGAGEMENT_SYNC_INTERVAL_MINUTES: zod_1.z.coerce.number().int().min(5).max(1440).default(20),
    // SAM.gov Contract Opportunities API key (api.data.gov). Stored in Secrets
    // Manager and injected as an env var; optional so non-prod boots without it.
    SAM_GOV_API_KEY: zod_1.z.string().optional(),
    // Kill-switch for SAM Entity-Management gov-id enrichment (UEI/CAGE/NAICS on
    // client create/import). Defaults ON; set false/0/no/off to pause enrichment
    // (e.g. if SAM is degraded or quota is exhausted) WITHOUT a code deploy.
    SAM_ENRICHMENT_ENABLED: zod_1.z
        .string()
        .default('true')
        .transform((v) => !['false', '0', 'no', 'off'].includes(v.trim().toLowerCase())),
    // Meri chat brain (single Anthropic-native model + budgets). Env-driven so
    // the model and token ceiling are not hard-coded in service code.
    CLIO_MODEL: zod_1.z.string().default('claude-sonnet-5').transform(ai_model_policy_1.upgradeTextModel),
    CLIO_MAX_TOKENS: zod_1.z.coerce.number().int().positive().default(4000),
    CLIO_INTENT_MODEL: zod_1.z.string().default('claude-sonnet-5').transform(ai_model_policy_1.upgradeTextModel),
    CLIO_REQUEST_TIMEOUT_MS: zod_1.z.coerce.number().int().positive().default(120_000),
    // Max characters of prior conversation history sent to the model. Older turns
    // beyond this budget are dropped (oldest-first) to avoid silent context-limit
    // 400s on long sessions. ~80k chars ≈ 20k tokens — comfortably within the
    // Sonnet 200k window while leaving room for system blocks, tools, and the
    // current turn. Raised from 24k (which silently evicted context in long /
    // data-heavy threads — users reported Meri "losing context").
    CLIO_HISTORY_CHAR_BUDGET: zod_1.z.coerce.number().int().positive().default(80_000),
    // Max agentic tool-use rounds per message before forcing a final answer (P2-3).
    CLIO_MAX_TOOL_ROUNDS: zod_1.z.coerce.number().int().positive().default(8),
    // Wall-clock budget for a whole turn across all rounds (P2-3). When exceeded the
    // loop stops and wraps up gracefully. <= 0 disables. Keep <= the request timeout.
    CLIO_TURN_BUDGET_MS: zod_1.z.coerce.number().int().min(0).default(90_000),
    // Anthropic prompt caching (P0-1). When enabled, cache breakpoints are placed
    // on the static system base and the tool-schema block, so repeated turns within
    // the ~5-minute cache TTL reuse that prefix (response usage reports
    // cache_read_input_tokens > 0). Only the static prefix is cached; per-turn
    // context and messages are never cached. Set false/0/no/off to disable.
    CLIO_PROMPT_CACHE_ENABLED: zod_1.z
        .string()
        .default('true')
        .transform((v) => !['false', '0', 'no', 'off'].includes(v.trim().toLowerCase())),
    // Per-tool execution timeout (P0-2). Within an agentic round, read-only tools
    // run concurrently and side-effecting tools serially; each tool call is bounded
    // by this timeout. On timeout the model receives an error tool_result and the
    // turn proceeds (the tool is not hard-aborted).
    CLIO_TOOL_TIMEOUT_MS: zod_1.z.coerce.number().int().positive().default(20_000),
    // Max retries for idempotent (read-only) Meri tools; side-effecting tools never
    // retry. After repeated failures a per-(tenant, tool) circuit breaker pauses the
    // tool so the turn proceeds without it instead of retrying a dead dependency (P2-2).
    CLIO_TOOL_RETRIES: zod_1.z.coerce.number().int().min(0).default(1),
    // Inline citations (P0-3). When enabled, numbered sources are injected into
    // tool results and the model cites them as [N]; hallucinated markers are
    // stripped post-hoc and the used citations are emitted (SSE) + persisted to
    // clio_message.metadata.citations. Set false/0/no/off to disable.
    CLIO_CITATIONS_ENABLED: zod_1.z
        .string()
        .default('true')
        .transform((v) => !['false', '0', 'no', 'off'].includes(v.trim().toLowerCase())),
    // Skill registry (P0-5). When enabled, migrated intents resolve their guidance
    // + output template from meri/skills/*; un-migrated intents fall back to the
    // legacy inline maps. Migrated skills are byte-identical to the legacy entries,
    // so toggling this never changes output. Set false/0/no/off to force the
    // legacy path.
    CLIO_SKILLS_ENABLED: zod_1.z
        .string()
        .default('true')
        .transform((v) => !['false', '0', 'no', 'off'].includes(v.trim().toLowerCase())),
    // Grounding/verifier gate (P0-6). When enabled, deliverables (briefings/memos)
    // get a cheap second pass (CLIO_INTENT_MODEL) that flags claims unsupported by
    // retrieved sources; >20% unsupported marks the output low-confidence. Never
    // gates raw chat. Fail-open. Set false/0/no/off to disable.
    CLIO_VERIFIER_ENABLED: zod_1.z
        .string()
        .default('true')
        .transform((v) => !['false', '0', 'no', 'off'].includes(v.trim().toLowerCase())),
    // Suggested next actions (P2-4): after an answer, a cheap intent-model pass
    // proposes 2-3 follow-up prompts rendered as clickable chips. Fail-open.
    CLIO_SUGGESTIONS_ENABLED: zod_1.z
        .string()
        .default('true')
        .transform((v) => !['false', '0', 'no', 'off'].includes(v.trim().toLowerCase())),
    // Extended thinking on the deep tier (assistant-parity F3). When enabled,
    // deep-tier chat turns and deep-research gather/synthesize calls request
    // model reasoning, streamed to the UI timeline as it happens. 'adaptive'
    // mode (default, recommended on the Claude 4.6-family models Meri runs on,
    // where fixed thinking budgets are deprecated) lets the model decide when
    // and how much to think; 'budget' mode sends a fixed budget_tokens for
    // pinned older models. Thinking text is ephemeral UI: never persisted to
    // messages/artifacts, never fed to the confidence checker. Kill-switch: set
    // false/0/no/off to restore exact baseline requests with no deploy.
    CLIO_EXTENDED_THINKING: zod_1.z
        .string()
        .default('true')
        .transform((v) => !['false', '0', 'no', 'off'].includes(v.trim().toLowerCase())),
    CLIO_THINKING_MODE: zod_1.z.enum(['adaptive', 'budget']).default('adaptive'),
    // Budget mode: the fixed thinking budget. Adaptive mode: extra max_tokens
    // headroom granted so thinking never crowds out the visible answer.
    CLIO_THINKING_BUDGET_TOKENS: zod_1.z.coerce.number().int().positive().default(8000),
    CLIO_RESEARCH_THINKING_BUDGET_TOKENS: zod_1.z.coerce.number().int().positive().default(16_000),
    // Long-conversation compaction (assistant-parity F2). An after-turn async
    // job folds turns older than the verbatim tail into a rolling per-
    // conversation summary (small intent-tier model) once the un-summarized
    // text reaches the trigger budget; turn assembly then sends
    // [summary block] + last-N verbatim turns instead of replaying everything.
    // Kill-switch: set CLIO_COMPACTION_ENABLED=false to stop compacting (the
    // stored summary keeps being injected for already-compacted threads).
    CLIO_COMPACTION_ENABLED: zod_1.z
        .string()
        .default('true')
        .transform((v) => !['false', '0', 'no', 'off'].includes(v.trim().toLowerCase())),
    CLIO_COMPACTION_TRIGGER_TOKENS: zod_1.z.coerce.number().int().positive().default(5000),
    CLIO_COMPACTION_TAIL_MESSAGES: zod_1.z.coerce.number().int().positive().default(12),
    // Conversation-history search index (F2): embeds chat messages into
    // context_embeddings (sourceType 'clio_message') after each turn. Search
    // degrades to keyword ILIKE when embeddings are unavailable or disabled.
    CLIO_MESSAGE_INDEX_ENABLED: zod_1.z
        .string()
        .default('true')
        .transform((v) => !['false', '0', 'no', 'off'].includes(v.trim().toLowerCase())),
    // Client knowledge base (assistant-parity F5): indexes client profile,
    // people, facilities, and uploaded documents into context_embeddings for
    // the search_client_knowledge tool + the always-on client-chat snapshot.
    // Kill-switch: set false/0/no/off to stop indexing and snapshot injection
    // (the retrieval tool degrades to empty results).
    CLIO_CLIENT_KB_ENABLED: zod_1.z
        .string()
        .default('true')
        .transform((v) => !['false', '0', 'no', 'off'].includes(v.trim().toLowerCase())),
    // Tenant-configured MCP servers (assistant-parity F6a). Kill-switch: set
    // false/0/no/off and no bridged tools register or execute, instantly.
    CLIO_MCP_ENABLED: zod_1.z
        .string()
        .default('true')
        .transform((v) => !['false', '0', 'no', 'off'].includes(v.trim().toLowerCase())),
    // stdio MCP servers spawn a child process ON THE API HOST, so the exact
    // command must be allowlisted here by the platform operator (comma-
    // separated). Empty (default) = stdio servers refuse to start; tenant
    // admins can only configure streamable-HTTP servers on their own.
    CLIO_MCP_STDIO_ALLOWED_COMMANDS: zod_1.z.string().optional(),
    // Connector library (connector-library v1). Absolute callback URL registered
    // as the OAuth redirect_uri for connectors that use OAuth 2.1 (dynamic client
    // registration). Must point at GET /api/clio/mcp-oauth/callback on the app
    // origin, e.g. https://app.capiro.ai/api/clio/mcp-oauth/callback. Unset =
    // OAuth connectors can't be connected (token/none connectors still work).
    // Capiro-owned managed app configuration. Never accepted from browser requests.
    MERI_MCP_HUBSPOT_ENABLED: zod_1.z.string().optional(),
    MERI_MCP_AIRTABLE_ENABLED: zod_1.z.string().optional(),
    MERI_MCP_MONDAY_ENABLED: zod_1.z.string().optional(),
    MERI_MCP_GOOGLE_DRIVE_ENABLED: zod_1.z.string().optional(),
    MERI_MCP_HUBSPOT_CLIENT_ID: zod_1.z.string().optional(),
    MERI_MCP_HUBSPOT_CLIENT_SECRET: zod_1.z.string().optional(),
    MERI_MCP_GOOGLE_DRIVE_CLIENT_ID: zod_1.z.string().optional(),
    MERI_MCP_GOOGLE_DRIVE_CLIENT_SECRET: zod_1.z.string().optional(),
    CLIO_MCP_OAUTH_REDIRECT_URI: zod_1.z.string().url().optional(),
    // Where the OAuth callback bounces the browser back to after connecting.
    CLIO_MCP_OAUTH_SUCCESS_REDIRECT: zod_1.z.string().default('/settings/integrations'),
    // SSRF guard: connector endpoints must be https and must NOT target a
    // private/loopback/link-local address. Set true ONLY for local development to
    // permit http://localhost / 127.0.0.1 MCP servers. Never enable in prod.
    CLIO_MCP_ALLOW_INSECURE_LOCAL: zod_1.z
        .string()
        .default('false')
        .transform((v) => ['true', '1', 'yes', 'on'].includes(v.trim().toLowerCase())),
    // Firm-authored skills (assistant-parity F6b). Kill-switch: set
    // false/0/no/off and tenant skills stop loading at turn time (rows are
    // retained; CRUD still works).
    CLIO_FIRM_SKILLS_ENABLED: zod_1.z
        .string()
        .default('true')
        .transform((v) => !['false', '0', 'no', 'off'].includes(v.trim().toLowerCase())),
    // Analysis sandbox (assistant-parity F4). The run_analysis tool registers
    // only for tenants that opted in (settings_jsonb.clioFeatureFlags
    // .runAnalysis = true — pilot default OFF) AND while this env kill-switch
    // is on; flipping it off removes the tool from the registry instantly.
    // The runner is a separate no-egress Fargate service (apps/clio-sandbox,
    // ADR 0001); URL + bearer token configure the VPC-internal hop.
    CLIO_ANALYSIS_SANDBOX_ENABLED: zod_1.z
        .string()
        .default('true')
        .transform((v) => !['false', '0', 'no', 'off'].includes(v.trim().toLowerCase())),
    CLIO_SANDBOX_URL: zod_1.z.string().url().optional(),
    CLIO_SANDBOX_TOKEN: zod_1.z.string().optional(),
    // Meri public web search (search_public_web). 'duckduckgo' (default) keeps the
    // existing scraped DDG behavior with zero new dependencies; 'tavily'/'serper'
    // call the respective search API when its key is configured, with automatic
    // DDG fallback on provider error or a missing key — so setting only the
    // provider (without a key) never breaks the tool.
    CLIO_WEB_SEARCH_PROVIDER: zod_1.z.enum(['duckduckgo', 'tavily', 'serper']).default('duckduckgo'),
    TAVILY_API_KEY: zod_1.z.string().optional(),
    SERPER_API_KEY: zod_1.z.string().optional(),
    // Meri Deep Research (a heavier, multi-round agentic research run that produces
    // a long, cited report artifact). Separate budgets from the chat drawer because
    // research runs longer and writes a much larger output.
    CLIO_RESEARCH_MODEL: zod_1.z.string().default('claude-sonnet-5').transform(ai_model_policy_1.upgradeTextModel),
    CLIO_RESEARCH_PLAN_MODEL: zod_1.z.string().default('claude-sonnet-5').transform(ai_model_policy_1.upgradeTextModel),
    CLIO_RESEARCH_MAX_TOKENS: zod_1.z.coerce.number().int().positive().default(16_000),
    CLIO_RESEARCH_MAX_TOOL_ROUNDS: zod_1.z.coerce.number().int().positive().default(20),
    // Durable aggregate provider accounting. Enabled explicitly by default for
    // research only; ordinary chat retains its request-local controller.
    CLIO_RESEARCH_PROVIDER_BUDGET_ENABLED: zod_1.z
        .string()
        .default('true')
        .transform((value) => ['true', '1', 'yes', 'on'].includes(value.trim().toLowerCase())),
    CLIO_RESEARCH_MAX_PROVIDER_ATTEMPTS: zod_1.z.coerce.number().int().positive().max(64).default(23),
    CLIO_RESEARCH_MAX_TOTAL_TOKENS: zod_1.z.coerce
        .number()
        .int()
        .positive()
        .default(DEFAULT_RESEARCH_TOTAL_TOKENS),
    // Derived from the existing shared price schedule's highest output rate,
    // rather than a second pricing table or an unpriced zero-cost fallback.
    CLIO_RESEARCH_MAX_COST_USD: zod_1.z.coerce.number().positive().default(DEFAULT_RESEARCH_MAX_COST_USD),
    // Per-request timeout for the deep-research model calls. A single research
    // turn legitimately runs many minutes (gathering across many tools, then
    // streaming a long report), so the 120s interactive chat timeout
    // (CLIO_REQUEST_TIMEOUT_MS) is far too short — it was aborting research runs
    // before the report was written, leaving only the "Sources consulted" list.
    // Live 2026-08-18 NC Submarine / funding reports still hit the prior 10-min
    // per-call / 7-min total ceilings and shipped thin partial synthesis.
    CLIO_RESEARCH_TIMEOUT_MS: zod_1.z.coerce.number().int().positive().default(900_000),
    // HARD wall-clock ceiling for one research run, across ALL gather rounds plus
    // synthesis. Defaults to 30 minutes so long federal-funding reports can finish
    // a full gather + write cycle. The gather loop stops taking new rounds once
    // the budget minus the synthesis reserve is spent, and every round's own
    // timeout is clamped to whatever budget is left. ALB idle timeout is 4000s,
    // and research SSE progress heartbeats keep the stream alive.
    CLIO_RESEARCH_TOTAL_BUDGET_MS: zod_1.z.coerce.number().int().positive().default(1_800_000),
    // Slice of the total budget held back so the forced-synthesis pass always has
    // time to actually write the report. Gathering that eats the whole budget is
    // the failure this prevents: evidence collected, no report. Kept as a floor
    // too — if the budget is already blown when synthesis starts, synthesis still
    // gets this long rather than an instantly-aborted 0ms window. 8 minutes is
    // enough for a long, cited report body under extended thinking.
    CLIO_RESEARCH_SYNTHESIS_RESERVE_MS: zod_1.z.coerce.number().int().positive().default(480_000),
    // Cadence of the `progress` SSE heartbeat during a research run. Under
    // MERI_AUDITOR_MODE=enforce the report body is withheld until the post-hoc
    // audit clears it, so this heartbeat is the ONLY thing telling the reader the
    // run is alive; it also lets the client distinguish "slow" from "dead".
    CLIO_RESEARCH_PROGRESS_INTERVAL_MS: zod_1.z.coerce.number().int().positive().default(5_000),
    // 32-byte base64 or hex key used for AES-256-GCM encrypted meeting notes.
    NOTES_ENCRYPTION_KEY: zod_1.z.string().optional(),
    NOTES_ENCRYPTION_KEY_VERSION: zod_1.z.string().default('v1'),
    // 32-byte base64 or hex key for AES-256-GCM at-rest encryption of OAuth
    // access/refresh tokens stored in engagement_connection_tokens. Distinct
    // from NOTES_ENCRYPTION_KEY so a key compromise on either side is contained.
    OAUTH_TOKEN_ENCRYPTION_KEY: zod_1.z.string().optional(),
    OAUTH_TOKEN_ENCRYPTION_KEY_VERSION: zod_1.z.string().default('v1'),
    // 32-byte base64 or hex key for AES-256-GCM at-rest encryption of
    // per-tenant AI provider keys (tenant_ai_credentials). Dedicated key —
    // do not reuse the notes/OAuth keys, so a compromise stays contained.
    // Unset = bring-your-own-key feature inactive (global env keys only).
    AI_CREDENTIAL_ENCRYPTION_KEY: zod_1.z.string().optional(),
    AI_CREDENTIAL_ENCRYPTION_KEY_VERSION: zod_1.z.string().default('v1'),
    // Shared secret for trusted backend-service callers (currently: intel-api's
    // live-hearing tenant-AI-credential resolve, BYOK3). Checked by
    // InternalServiceGuard against the `x-internal-service-secret` header — NOT
    // a user-facing auth path, so it never returns a raw provider key to a
    // browser-held Clerk JWT. Unset = the guarded route is fully disabled
    // (fail-closed), not fail-open.
    INTERNAL_SERVICE_SECRET: zod_1.z.string().optional(),
    // Gate-bypass hardening for POST /api/clio/tools/:name and internal proposal
    // creation. Staging/production ALWAYS enforce the shared secret; this switch
    // controls explicit observe-only behavior in development/test only.
    MERI_TOOLS_REQUIRE_SERVICE_SECRET: zod_1.z
        .string()
        .default('false')
        .transform((v) => ['true', '1', 'yes', 'on'].includes(v.trim().toLowerCase())),
    // Dark rollout gate for the new API/orchestrator/web proposal contract. The
    // insecure legacy browser routes are disabled regardless of this value.
    MERIV2_ACTION_PROPOSALS_ENABLED: zod_1.z
        .string()
        .default('false')
        .transform((v) => ['true', '1', 'yes', 'on'].includes(v.trim().toLowerCase())),
    MERIV2_ACTION_PROPOSAL_TTL_MINUTES: zod_1.z.coerce.number().int().min(1).max(1440).default(15),
    // Which action-policy source may bind real writes. Off/shadow retain the
    // reviewed static baseline; enforce requires a verified tenant-published pack
    // and fails closed when it cannot be loaded. A code deploy never arms it.
    MERI_POLICY_PACK_SOURCE: zod_1.z.enum(['off', 'shadow', 'enforce']).default('off'),
    // Stage 0 evidence-accuracy rollout. Effective mode additionally requires
    // canonical tenant and assurance-surface enrollment.
    MERI_EVIDENCE_ACCURACY_MODE: rolloutModeSwitch(),
    MERI_EVIDENCE_ACCURACY_TENANTS: zod_1.z.string().optional(),
    MERI_EVIDENCE_ACCURACY_SURFACES: zod_1.z.string().optional(),
    // Stage 2a coverage-driven follow-up retrieval. Dark unless independently enrolled.
    MERI_COVERAGE_RETRIEVAL_MODE: rolloutModeSwitch(),
    MERI_COVERAGE_RETRIEVAL_TENANTS: zod_1.z.string().optional(),
    MERI_COVERAGE_RETRIEVAL_SURFACES: zod_1.z.string().optional(),
    // Stage 1 claim inventory. Enforce remains shadow-only until a later stage.
    MERI_CLAIM_ASSESSMENT_MODE: rolloutModeSwitch(),
    MERI_CLAIM_ASSESSMENT_TENANTS: zod_1.z.string().optional(),
    MERI_CLAIM_ASSESSMENT_SURFACES: zod_1.z.string().optional(),
    // Stage 2c bounded live correction. Category promotion remains human-controlled and dark.
    MERI_AUTO_CORRECTION_MODE: rolloutModeSwitch(),
    MERI_AUTO_CORRECTION_TENANTS: zod_1.z.string().optional(),
    MERI_AUTO_CORRECTION_SURFACES: zod_1.z.string().optional(),
    MERI_AUTO_CORRECTION_CATEGORIES: zod_1.z.string().optional(),
    // Stage 2b Jev passage selection. Effective mode also requires Jev enrollment/task availability.
    MERI_PASSAGE_SELECTION_MODE: rolloutModeSwitch(),
    MERI_PASSAGE_SELECTION_TENANTS: zod_1.z.string().optional(),
    MERI_PASSAGE_SELECTION_SURFACES: zod_1.z.string().optional(),
    // Stage 3d explicit evidence classification. Dark unless independently enrolled.
    MERI_EVIDENCE_PROFILES_MODE: rolloutModeSwitch(),
    MERI_EVIDENCE_PROFILES_TENANTS: zod_1.z.string().optional(),
    MERI_EVIDENCE_PROFILES_SURFACES: zod_1.z.string().optional(),
    // Stage 4a deterministic opportunity-match labels. Dark unless independently enrolled.
    MERI_MATCH_LABEL_MODE: rolloutModeSwitch(),
    MERI_MATCH_LABEL_TENANTS: zod_1.z.string().optional(),
    MERI_MATCH_LABEL_SURFACES: zod_1.z.string().optional(),
    // Stage 4b exact certification-status provenance. Dark unless independently enrolled.
    MERI_STATUS_PROVENANCE_MODE: rolloutModeSwitch(),
    MERI_STATUS_PROVENANCE_TENANTS: zod_1.z.string().optional(),
    MERI_STATUS_PROVENANCE_SURFACES: zod_1.z.string().optional(),
    // Stage 3c Jev decision cache (live-repair claim-support only). Dark unless independently enrolled.
    MERI_JEV_CACHE_MODE: rolloutModeSwitch(),
    MERI_JEV_CACHE_TENANTS: zod_1.z.string().optional(),
    MERI_JEV_CACHE_SURFACES: zod_1.z.string().optional(),
    // Stage 0e Jev provider foundation. Validation-only until an app-side factory exists.
    TYPESAFE_API_KEY: zod_1.z.preprocess(blankToUndefined, zod_1.z.string().min(1).optional()),
    MERI_JEV_MODEL: zod_1.z.string().optional(),
    MERI_JEV_TIMEOUT_MS: zod_1.z.string().optional(),
    MERI_JEV_MAX_ATTEMPTS: zod_1.z.string().optional(),
    MERI_JEV_PROVIDER_MODE: rolloutModeSwitch(),
    MERI_JEV_PROVIDER_TENANTS: zod_1.z.string().optional(),
    MERI_JEV_PROVIDER_SURFACES: zod_1.z.string().optional(),
    MERI_CHAT_EVIDENCE_JUDGE: zod_1.z.preprocess(normalizeOptionalSwitch, zod_1.z.enum(['llm', 'jev', 'paired', 'cascade']).optional()),
    MERI_JEV_TASKS: zod_1.z.string().optional(),
    // Business Development Phase 3 — BD Jev task-mode controls. All dark by
    // default: the global kill switch must be explicitly truthy AND a per-task
    // mode must be explicitly configured AND the tenant must be enrolled (see
    // tenant-flags.ts) before any BD Jev evaluation runs. `internal_canary` is
    // additionally refused while the shared meriv2-core registry caps the task
    // at shadow or its evaluation set is not approved — see
    // business-development/bizdev-jev-mode.ts.
    BIZDEV_JEV_ENABLED: zod_1.z.preprocess(blankToUndefined, zod_1.z.string().default('false')),
    BIZDEV_JEV_TASK_BD_ENTITY_MODE: zod_1.z.preprocess(normalizeOptionalSwitch, zod_1.z.enum(['off', 'shadow', 'internal_canary']).default('off')),
    BIZDEV_JEV_TASK_BD_SIGNAL_MODE: zod_1.z.preprocess(normalizeOptionalSwitch, zod_1.z.enum(['off', 'shadow', 'internal_canary']).default('off')),
    // ── Business Development Phase 5 — DB-only watch evaluator ───────────────
    // Global kill-switch for the Phase 5 watch/alert surface. Default OFF; only
    // 'true'/'1'/'yes'/'on' enable (house string-allowlist transform, NOT
    // z.coerce.boolean()). The per-tenant businessDevelopment.watch.enabled flag
    // is ANDed on top (tenant-flags.ts); GET /me surfaces the AND.
    BIZDEV_WATCH_ENABLED: zod_1.z
        .string()
        .default('false')
        .transform((v) => ['true', '1', 'yes', 'on'].includes(v.trim().toLowerCase())),
    // Comma-separated source-family allowlist the evaluator may scan. Defaults
    // to the SAFE ACTIVE FIVE (acquisition_revision is DEFERRED and must never
    // be activated by default); every entry must be a known family (validated
    // at read time — unknown families fail closed, never silently skipped).
    // No provider credentials anywhere in this block.
    BIZDEV_WATCH_SOURCE_FAMILIES: zod_1.z
        .string()
        .default('federal_award,federal_assistance_award,sam_opportunity,tango_resource,lda_filing'),
    // Max watches processed per evaluator run (bounded work).
    BIZDEV_WATCH_MAX_PER_RUN: zod_1.z.coerce.number().int().min(1).max(500).default(50),
    // Max source records read per watch per family per pass (complete bound: a
    // read that would exceed it is marked partial and does NOT advance the
    // successful-complete baseline/watermark).
    BIZDEV_WATCH_MAX_RECORDS_PER_SOURCE: zod_1.z.coerce.number().int().min(1).max(500).default(50),
    // WatchSourceState lease duration in seconds (multi-worker safety).
    BIZDEV_WATCH_LEASE_SECONDS: zod_1.z.coerce.number().int().min(30).max(3600).default(300),
    // Recall.ai meeting-notetaker bot (docs/plans/meeting-notetaker-bot-plan.md).
    // RECALL_API_KEY authenticates outbound bot dispatch/poll calls (sent as the
    // `Authorization: Token <key>` scheme, NOT Bearer). RECALL_WEBHOOK_SECRET
    // (whsec_…) verifies inbound Svix-signed Recall webhooks. RECALL_API_BASE_URL
    // selects the region host — Recall regions are isolated deployments with their
    // own keys/data-residency, so this must match the region the API key belongs
    // to. Capiro's Recall workspace is us-west-2 (US West / Oregon). The two secrets
    // are optional: unset = the notetaker feature is inert (no bot can be
    // dispatched), matching the fail-closed posture of the other provider keys.
    RECALL_API_KEY: zod_1.z.string().optional(),
    RECALL_WEBHOOK_SECRET: zod_1.z.string().optional(),
    RECALL_API_BASE_URL: zod_1.z.string().url().default('https://us-west-2.recall.ai'),
    // Global kill-switch for the meeting-notetaker feature. Read directly from
    // process.env by tenant-flags.notetakerEnabled(); declared here for validation
    // and visibility. Only the literal 'true' enables; ANDed with the per-tenant
    // `notetaker.enabled` flag so the feature stays dormant until BOTH are on.
    NOTETAKER_ENABLED: zod_1.z.string().optional(),
    // Retention window (days) for notetaker call TRANSCRIPTS. The notetaker reconcile
    // sweep deletes source='notetaker' EngagementAttachments (S3 object + row + KB
    // chunks) older than this — the derived meeting NOTES and DEBRIEFS are separate
    // tables with no cascade and are kept forever. 0 (or negative) disables the sweep
    // leg entirely (kill-switch / tuning lever without a redeploy). Default 30 days.
    NOTETAKER_TRANSCRIPT_RETENTION_DAYS: zod_1.z.coerce.number().int().default(30),
    // 32+ byte secret used to HMAC-sign the `state` parameter in OAuth flows so
    // a callback can be tied back to the connection that started it.
    OAUTH_STATE_SECRET: zod_1.z.string().optional(),
    // Microsoft 365 Graph OAuth (capiro-outlook app registration). Cert auth is
    // used because the capiro.ai tenant blocks client secrets. The private key
    // is a PEM string; if it doesn't start with "-----BEGIN" the loader treats
    // it as base64-encoded PEM (handy for env-var transport).
    MICROSOFT_CLIENT_ID: zod_1.z.string().optional(),
    // MICROSOFT_TENANT_ID is retained for reference/diagnostics only. It must NOT
    // drive the OAuth authority: customers connect their own Outlook mailboxes
    // from ANY Azure AD org, so the authority is multi-tenant (MICROSOFT_AUTHORITY
    // below). Pinning the authority to this single tenant GUID (= the capiro.ai
    // tenant) was what rejected every external customer with AADSTS50020.
    MICROSOFT_TENANT_ID: zod_1.z.string().optional(),
    // OAuth authority for the Microsoft 365 integration. Defaults to the shared
    // multi-tenant `/organizations` endpoint so work/school accounts from any
    // customer Azure AD tenant can connect. The capiro-outlook app registration
    // is already multi-tenant (AzureADMultipleOrgs), so no Azure change is needed.
    // Override only for a deliberately single-tenant deployment.
    MICROSOFT_AUTHORITY: zod_1.z.string().url().default('https://login.microsoftonline.com/organizations'),
    MICROSOFT_CERT_THUMBPRINT: zod_1.z.string().optional(),
    MICROSOFT_CERT_PRIVATE_KEY: zod_1.z.string().optional(),
    // APP_SIGN_IN_URL is injected by CDK per env (compute-stack apiSharedEnv).
    // The prod default here keeps prod working if ever run without CDK injection.
    APP_SIGN_IN_URL: zod_1.z.string().url().default('https://app.capiro.ai/sign-in'),
    // Optional override for Clerk invitation redirect URLs. When unset, the
    // tenant-admin invitation flow derives the URL from the first entry of
    // WEB_ORIGIN (which is a comma-separated CORS allowlist). Set this
    // explicitly when the primary host differs from the first allowed
    // origin or when invitation links should land on a non-standard route.
    INVITATION_REDIRECT_URL: zod_1.z.string().url().optional(),
    MICROSOFT_REDIRECT_URI: zod_1.z
        .string()
        .url()
        .default('https://app.capiro.ai/api/engagement/integrations/microsoft/callback'),
    MICROSOFT_OAUTH_SUCCESS_REDIRECT: zod_1.z.string().default('/settings/integrations'),
    MICROSOFT_GRAPH_NOTIFICATION_URL: zod_1.z
        .string()
        .url()
        .default('https://app.capiro.ai/api/engagement/integrations/microsoft/notifications'),
    // Google Workspace OAuth (capiro-gmail-integration GCP project). Unlike the
    // Microsoft app registration (which uses certificate auth because the
    // capiro.ai Azure tenant blocks client secrets), Google's Web-application
    // OAuth client uses a standard client secret — there is no cert-based
    // confidential-client option for this delegated, multi-tenant flow. The
    // secret lives in AWS Secrets Manager (capiro/dev/GOOGLE_CLIENT_SECRET),
    // never in plaintext. All keys are optional so the feature stays inert
    // (capabilities() reports configured:false, routes 503) until wired —
    // matching the fail-closed posture of MICROSOFT_* and RECALL_*.
    GOOGLE_CLIENT_ID: zod_1.z.string().optional(),
    GOOGLE_CLIENT_SECRET: zod_1.z.string().optional(),
    GOOGLE_REDIRECT_URI: zod_1.z
        .string()
        .url()
        .default('https://app.capiro.ai/api/engagement/integrations/google/callback'),
    GOOGLE_OAUTH_SUCCESS_REDIRECT: zod_1.z.string().default('/settings/integrations'),
    // Public landing page demo requests are stored in Postgres and emailed via
    // Amazon SES. The source address must be a verified SES identity.
    DEMO_REQUEST_EMAIL_FROM: zod_1.z.string().email().default('sales@capiro.ai'),
    DEMO_REQUEST_EMAIL_TO: zod_1.z.string().email().default('sales@capiro.ai'),
    // MakeGov/Tango (Funding Opportunities P16). Key is optional at every task's
    // boot — TangoModule (apps/api/src/external/tango) registers unconditionally
    // and every gateway call fails closed with a typed "not configured" error
    // when it is absent, so no serve/web/workspace/migrate/Meri task requires it.
    // It is injected ONLY into the ephemeral sync-job task definition, and only
    // once infra/cdk/lib/config.ts's externalSecretArns.tangoApiKey is set — see
    // compute-stack.ts. Do not read this key outside apps/api/src/external/tango;
    // that module is the only reviewed boundary to the provider.
    TANGO_API_KEY: zod_1.z.string().min(1).optional(),
    // HTTPS-only, enforced the same way as every other provider base URL in this
    // schema (LEGISTORM_BASE_URL, LLAMA_CLOUD_BASE_URL). Defaults to the SDK's
    // own DEFAULT_BASE_URL (@makegov/tango-node config.ts) so an unset value
    // reaches the real public endpoint rather than nothing.
    TANGO_API_BASE_URL: zod_1.z
        .string()
        .url()
        .refine((v) => new URL(v).protocol === 'https:', 'TANGO_API_BASE_URL must use HTTPS')
        .default('https://tango.makegov.com'),
    // Per-request timeout. Matches the adapter's own fallback
    // (tango.client.ts's `timeoutMs ?? 30_000`) so setting this explicitly and
    // leaving it unset produce identical behavior.
    TANGO_TIMEOUT_MS: zod_1.z.coerce.number().int().positive().default(30_000),
    // Provider page size for list calls. CAPPED AT 100 — not a Capiro choice: the
    // SDK's own list helpers hard-clamp to `Math.min(limit, 100)`, and asking for
    // more here would silently be truncated to 100 by the SDK while every
    // caller's own accounting assumed the larger number it configured.
    TANGO_PAGE_SIZE: zod_1.z.coerce.number().int().positive().max(100).default(100),
    // P18's per-run request ceiling. Read only by P18's rate-limit/health
    // controls; declared here now so the value exists and is validated before
    // any code depends on it. A run that reaches this many calls stops rather
    // than continuing to spend the account's quota unsupervised.
    TANGO_REQUEST_CEILING_PER_RUN: zod_1.z.coerce.number().int().positive().default(5_000),
    // P18's circuit breaker. Consecutive transient/rate-limit failures before the
    // breaker opens, and how long it stays open before allowing a probe request.
    TANGO_CIRCUIT_BREAKER_THRESHOLD: zod_1.z.coerce.number().int().positive().default(5),
    TANGO_CIRCUIT_BREAKER_COOLDOWN_MS: zod_1.z.coerce.number().int().positive().default(60_000),
    // P46's webhook signing secret. A SEPARATE credential from TANGO_API_KEY, per
    // the plan's §5 ("a separate Tango webhook signing secret is introduced only
    // in P46") — the API key is an outbound credential injected into the ephemeral
    // sync task, this is an inbound one injected only into API serve. Neither task
    // ever holds both.
    //
    // OPTIONAL, and unset today. Absent means the receiver is DARK: it rejects
    // every delivery unverified rather than accepting anything. That is the whole
    // mechanism behind P46's "deploy receiver dark" — there is no development
    // bypass and no implicit fallback, matching this program's rule that nothing
    // has an internal-tenant escape hatch.
    TANGO_WEBHOOK_SIGNING_SECRET: zod_1.z.string().min(1).optional(),
    // Replay window for the provider's send timestamp, applied in BOTH directions
    // so a provider clock running fast does not reject every delivery. Defence in
    // depth only — the real replay guarantee is the unique index on delivery_id,
    // which holds regardless of clock skew and regardless of this value.
    TANGO_WEBHOOK_REPLAY_WINDOW_SECONDS: zod_1.z.coerce.number().int().positive().default(300),
    // P29's attachment archive. BOTH optional and BOTH unset today: the
    // discovery half of the sync needs neither, and the archiving half refuses
    // to start without a bucket rather than fetching megabytes with nowhere to
    // put them. Wiring the bucket into the ephemeral sync task is a deliberate,
    // out-of-band operator step, the same posture P16 took for the API key —
    // nothing in a serve/web/workspace/migrate task reads either of these.
    OPPORTUNITY_ATTACHMENT_BUCKET: zod_1.z.string().min(1).optional(),
    // Key prefix inside that bucket. The rest of the key is the content hash —
    // see archiveKeyFor — so identical bytes never store twice and changed bytes
    // never overwrite.
    OPPORTUNITY_ATTACHMENT_PREFIX: zod_1.z.string().min(1).default('opportunity-attachments'),
    // GovInfo (api.data.gov) — congressional bills, committee reports, public laws.
    // Key is an api.data.gov key sourced from Secrets Manager (injected as env by CDK).
    // Endpoints fail closed (the service throws) when the key is unset.
    GOVINFO_API_KEY: zod_1.z.string().optional(),
    // S3 bucket for cached GovInfo PDFs (committee reports, public laws).
    GOVINFO_CACHE_BUCKET: zod_1.z.string().optional(),
    // Billing enforcement (onboarding v1). ALL Stripe access moved to
    // apps/onboard-api (the single Stripe writer — checkout/portal/webhooks/
    // overage; see docs/plans/onboarding-v1-plan.md). apps/api keeps only the
    // read-side billing views (summary/state) and the 402 client-slot gate,
    // switched by this explicit flag now that the old implicit
    // Boolean(STRIPE_SECRET_KEY) signal no longer exists in this service.
    // Flip to true at billing activation (after comp-existing-tenants has run).
    BILLING_ENFORCED: zod_1.z
        .string()
        .default('false')
        .transform((v) => ['1', 'true', 'yes', 'on'].includes(v.toLowerCase())),
    // ── Client-profile Tracker tab: bill-change alert delivery ────────────────
    // Master kill-switch for the alert pipeline (change detection + fan-out).
    // Set false/0/no/off to pause all Tracker alert delivery without a deploy.
    TRACKER_ALERTS_ENABLED: zod_1.z
        .string()
        .default('true')
        .transform((v) => !['false', '0', 'no', 'off'].includes(v.trim().toLowerCase())),
    // Catch-up detection: scan congress_bill_action rows newer than each tracked
    // bill's snapshot (vs. only the latest-action rollup), so a skipped run or a
    // burst of actions between runs never drops an intermediate material move.
    // Default on; set false/0/no/off to fall back to legacy latest-action-only.
    TRACKER_SCAN_ACTION_HISTORY: zod_1.z
        .string()
        .default('true')
        .transform((v) => !['false', '0', 'no', 'off'].includes(v.trim().toLowerCase())),
    // Client-context enrichment: attach a deterministic "why this matters to
    // {client}" line + matched watchlist tags to each alert. Purely additive
    // display; set false/0/no/off to send bare alerts if it ever misbehaves.
    TRACKER_ALERT_ENRICH: zod_1.z
        .string()
        .default('true')
        .transform((v) => !['false', '0', 'no', 'off'].includes(v.trim().toLowerCase())),
    // LLM "what happened" summary on each alert. Runs on the TENANT's own
    // Anthropic key when they have an active BYO credential (decrypted via the
    // shared AES-256-GCM resolver — no new crypto), else the global
    // ANTHROPIC_API_KEY; spend is metered to ai_usage_events. Fail-safe: no key /
    // error / timeout → the alert still sends, just without the summary line.
    // Default on; set false/0/no/off to disable (e.g. to cap LLM cost) w/o deploy.
    TRACKER_ALERT_SUMMARY: zod_1.z
        .string()
        .default('true')
        .transform((v) => !['false', '0', 'no', 'off'].includes(v.trim().toLowerCase())),
    // Single-sender guard for the intel-api tracker cutover (Capiro Intelligence
    // unification, plan §8/§Phase 8). When ON, the legacy detector SKIPS delivery
    // (email/SMS fan-out) for any tenant that intel-api has taken ownership of —
    // an ENABLED `intel_feature_flag` row for feature='tracker_owner_intel'. This
    // guarantees exactly one sender per tenant at cutover. DEFAULT OFF: while off,
    // the guard code never runs and legacy behavior is 100% unchanged. It skips
    // ONLY delivery, never the in-app `intelligence_change` feed (kept until the
    // Phase-7 UI repoint). NOTE: intentionally does NOT honor the internal-tenant
    // always-on hardcode — intel does not deliver for the internal tenant during
    // shadow, so legacy must keep sending there; only an explicit per-tenant flag
    // row transfers delivery ownership.
    TRACKER_SINGLE_SENDER_GUARD: zod_1.z
        .string()
        .default('false')
        .transform((v) => ['true', '1', 'yes', 'on'].includes(v.trim().toLowerCase())),
    // From-address for Tracker alert emails (must be a verified SES identity).
    TRACKER_ALERT_EMAIL_FROM: zod_1.z.string().email().default('alerts@capiro.ai'),
    // From-address for Workspace collaborator-invite emails (E-19). capiro.ai is a
    // verified SES domain identity, so any @capiro.ai sender works without new infra.
    WORKSPACE_INVITE_EMAIL_FROM: zod_1.z.string().email().default('notifications@capiro.ai'),
    // Newsletter comment emails are dormant until both newsletter migrations
    // and the verified SES sender are configured in this environment.
    NEWSLETTER_REVIEW_EMAIL_ENABLED: zod_1.z
        .enum(['true', 'false'])
        .default('false')
        .transform((v) => v === 'true'),
    NEWSLETTER_REVIEW_APP_URL: zod_1.z.string().url().default('https://app.capiro.ai'),
    NEWSLETTER_INVITATION_EMAIL_ENABLED: zod_1.z
        .enum(['true', 'false'])
        .default('false')
        .transform((v) => v === 'true'),
    // Base URL used to build deep links in alert emails/SMS back to the client
    // profile Tracker tab.
    TRACKER_APP_BASE_URL: zod_1.z.string().url().default('https://app.capiro.ai'),
    // Base URL for LegiWatch deep links (canonical Hearing Detail, and the link
    // embedded in exported calendar entries). Deliberately SEPARATE from
    // TRACKER_APP_BASE_URL: the LegiWatch vNext module is served from
    // os.capiro.ai, and an exported .ics outlives the session that produced it,
    // so its link cannot be derived from the request host either.
    LEGIWATCH_APP_BASE_URL: zod_1.z.string().url().default('https://os.capiro.ai'),
    // SMS provider. 'none' (default) keeps SMS DORMANT: the OTP-verify + alert
    // fan-out code paths run end-to-end but no message is sent (logged + recorded
    // as 'suppressed'). 'sns' uses AWS End User Messaging (SNS publish) once an
    // origination number is provisioned AND @aws-sdk/client-sns is installed.
    TRACKER_SMS_PROVIDER: zod_1.z.enum(['none', 'sns']).default('none'),
    // E.164 origination number / 10DLC / toll-free or SNS sender id used as the
    // SMS "from". Required before SMS can actually deliver (provisioning has
    // carrier lead time — see docs).
    TRACKER_SMS_ORIGINATION_NUMBER: zod_1.z.string().optional(),
    // ── Engagement API Phase 1 — runtime extraction ──────────────────────────
    //
    // CAPIRO_SERVICE_NAME identifies which process is running. The main API
    // defaults to 'api'; the engagement-api bootstrap sets 'engagement-api'.
    // This drives the runtime policy (shadow vs active mode).
    CAPIRO_SERVICE_NAME: zod_1.z.enum(['api', 'engagement-api']).default('api'),
    // Release SHA for the engagement-api health endpoint. 'UNVERIFIED' is the
    // local default; production should set a 40-character git SHA.
    RELEASE_SHA: zod_1.z
        .union([zod_1.z.literal('UNVERIFIED'), zod_1.z.string().regex(/^[0-9a-f]{40}$/i)])
        .default('UNVERIFIED'),
    // The engagement-api listens on its own port (default 4500).
    ENGAGEMENT_API_PORT: zod_1.z.coerce.number().int().positive().default(4500),
    ENGAGEMENT_API_BIND_HOST: zod_1.z.string().default('0.0.0.0'),
    // Shadow mode: the engagement-api process runs as a read-only clone.
    // Active mode: the main API process runs with full capabilities.
    ENGAGEMENT_PROCESS_MODE: zod_1.z.enum(['shadow', 'active']).default('active'),
    // Which service owns background workers. 'disabled' = no workers run.
    ENGAGEMENT_BACKGROUND_OWNER: zod_1.z.enum(['api', 'engagement-api', 'disabled']).default('api'),
    // External action mode. 'enabled' = all actions (main API default).
    // 'disabled' = none (shadow). 'test_only' = only outreach_test_send with
    // testMode=true.
    ENGAGEMENT_EXTERNAL_ACTIONS: zod_1.z.enum(['disabled', 'test_only', 'enabled']).default('enabled'),
    // OAuth callbacks and Microsoft notifications. Uses the string-allowlist
    // transform (NOT z.coerce.boolean()) so 'false'/'0'/'no'/'off' correctly
    // disable and only 'true'/'1'/'yes'/'on' enable.
    ENGAGEMENT_CALLBACKS_ENABLED: zod_1.z
        .string()
        .default('true')
        .transform((v) => ['true', '1', 'yes', 'on'].includes(v.trim().toLowerCase())),
    // X Intelligence Feed — application-only bearer token for the X API.
    // Optional at API-server boot; the feed reports an honest unavailable state
    // when it is absent. Injected ONLY into the backend runtime, never exposed
    // to the browser.
    X_API_BEARER_TOKEN: zod_1.z.string().min(1).optional(),
    X_API_BASE_URL: zod_1.z
        .string()
        .url()
        .refine((v) => new URL(v).protocol === 'https:', 'X_API_BASE_URL must use HTTPS')
        .default('https://api.x.com/2'),
    X_FEED_MAX_SOURCES: zod_1.z.coerce.number().int().positive().default(25),
    // Recall webhook processing gate. Same allowlist transform.
    ENGAGEMENT_RECALL_WEBHOOK_ENABLED: zod_1.z
        .string()
        .default('true')
        .transform((v) => ['true', '1', 'yes', 'on'].includes(v.trim().toLowerCase())),
    // Second, independent signature required before an engagement-api process
    // may run in the active posture (all five ENGAGEMENT_* controls armed). See
    // ENGAGEMENT_API_PROMOTION_ACKNOWLEDGEMENT in engagement-runtime-env.ts —
    // this field carries no default of its own because an unset value simply
    // fails the isActive check below exactly like a wrong one does.
    ENGAGEMENT_API_PROMOTION_TOKEN: zod_1.z.string().optional(),
});
/**
 * Parse + enforce the cross-field rules the plain schema cannot express.
 *
 * CLERK_JWT_ISSUER stays `.optional()` above on purpose: making it a hard
 * schema requirement would break every unit test that builds a config object,
 * and the schema is imported in contexts that never boot the app. The boot-time
 * requirement lives here instead.
 *
 * Deliberately gated on `NODE_ENV !== 'test'` and NOT on
 * `NODE_ENV === 'production'`: apps/api runs with NODE_ENV=development in the
 * LIVE capiro-dev deployment (which IS production), so a production-only gate
 * would be a silent no-op exactly where the control matters.
 *
 * Safe to ship for apps/api specifically — capiro-dev-api already sets
 * CLERK_JWT_ISSUER. Do NOT copy this guard into apps/intel-api, whose live task
 * definition does not set it; that service would crashloop.
 */
function validateConfig(raw) {
    const parsed = exports.configSchema.parse(raw);
    if (parsed.NODE_ENV !== 'test' && !parsed.CLERK_JWT_ISSUER) {
        throw new Error('CLERK_JWT_ISSUER is required outside tests — set it in the ECS task definition ' +
            '(e.g. https://clerk.app.capiro.ai). Refusing to start without issuer pinning.');
    }
    // Engagement API Phase 1 — cross-field validation for the shadow/active
    // matrix. When CAPIRO_SERVICE_NAME=engagement-api, the five posture fields
    // must ALL resolve to shadow, or ALL resolve to active plus a matching
    // ENGAGEMENT_API_PROMOTION_TOKEN — see engagement-runtime-env.ts for why a
    // partial combination and a bare active flip are both rejected. This block
    // exists in addition to, not instead of, engagement-runtime-env.ts's own
    // check: main.ts and engagement-main.ts both call
    // assertEngagementRuntimeEnvironment() before this validator ever runs, so
    // in practice that earlier check fails first — but validateConfig() is also
    // reachable directly (config.schema.spec.ts, other test suites), and this
    // codebase's own precedent (four other cross-field checks in this function)
    // is to keep the schema authoritative on its own, never relying solely on a
    // sibling module to catch a bad combination.
    if (parsed.CAPIRO_SERVICE_NAME === 'engagement-api') {
        const isShadow = parsed.ENGAGEMENT_PROCESS_MODE === 'shadow' &&
            parsed.ENGAGEMENT_BACKGROUND_OWNER === 'disabled' &&
            parsed.ENGAGEMENT_EXTERNAL_ACTIONS === 'disabled' &&
            !parsed.ENGAGEMENT_CALLBACKS_ENABLED &&
            !parsed.ENGAGEMENT_RECALL_WEBHOOK_ENABLED;
        const isActive = parsed.ENGAGEMENT_PROCESS_MODE === 'active' &&
            parsed.ENGAGEMENT_BACKGROUND_OWNER === 'engagement-api' &&
            parsed.ENGAGEMENT_EXTERNAL_ACTIONS === 'enabled' &&
            parsed.ENGAGEMENT_CALLBACKS_ENABLED &&
            parsed.ENGAGEMENT_RECALL_WEBHOOK_ENABLED;
        if (!isShadow && !isActive) {
            throw new Error('Engagement API shadow/active-mode configuration validation failed:\n  - ' +
                'ENGAGEMENT_PROCESS_MODE, ENGAGEMENT_BACKGROUND_OWNER, ENGAGEMENT_EXTERNAL_ACTIONS, ' +
                'ENGAGEMENT_CALLBACKS_ENABLED and ENGAGEMENT_RECALL_WEBHOOK_ENABLED must ALL be at their ' +
                'shadow value or ALL be at their active value ' +
                `(got processMode=${parsed.ENGAGEMENT_PROCESS_MODE}, ` +
                `backgroundOwner=${parsed.ENGAGEMENT_BACKGROUND_OWNER}, ` +
                `externalActions=${parsed.ENGAGEMENT_EXTERNAL_ACTIONS}, ` +
                `callbacksEnabled=${parsed.ENGAGEMENT_CALLBACKS_ENABLED}, ` +
                `recallWebhookEnabled=${parsed.ENGAGEMENT_RECALL_WEBHOOK_ENABLED})` +
                '\n\nThe engagement-api process must run with all five controls at the same posture.');
        }
        if (isActive &&
            parsed.ENGAGEMENT_API_PROMOTION_TOKEN !== engagement_runtime_env_js_1.ENGAGEMENT_API_PROMOTION_ACKNOWLEDGEMENT) {
            throw new Error('Engagement API is configured for the ACTIVE posture but ENGAGEMENT_API_PROMOTION_TOKEN ' +
                'does not match the required acknowledgement string. See ' +
                'ENGAGEMENT_API_PROMOTION_ACKNOWLEDGEMENT in engagement-runtime-env.ts.');
        }
    }
    return parsed;
}
//# sourceMappingURL=config.schema.js.map