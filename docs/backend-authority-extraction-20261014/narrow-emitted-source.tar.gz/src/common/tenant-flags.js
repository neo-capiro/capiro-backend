"use strict";
/**
 * Per-tenant Meri feature flags (assistant-parity cross-cutting convention).
 *
 * Flags live under tenants.settings_jsonb.clioFeatureFlags, e.g.
 *   { "clioFeatureFlags": { "runAnalysis": true } }
 * and compose with env kill-switches: a feature is active only when its env
 * switch is on AND the tenant flag resolves true (each feature picks its own
 * tenant default — pilot features default false, GA features default true).
 * Pure so it unit-tests under `src/**.spec.ts`.
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.MERI_JOB_FLAGS = exports.BIZDEV_JEV_TASK_MODE_FLAGS = exports.BUSINESS_DEVELOPMENT_WATCH_FLAG = exports.BUSINESS_DEVELOPMENT_CLAIM_VALIDATION_FLAG = exports.BUSINESS_DEVELOPMENT_MERI_PROSPECT_TOOLS_FLAG = exports.BUSINESS_DEVELOPMENT_BRIEF_FLAG = exports.BUSINESS_DEVELOPMENT_PDL_PEOPLE_FLAG = exports.BUSINESS_DEVELOPMENT_PDL_COMPANY_FLAG = exports.BUSINESS_DEVELOPMENT_LDA_FLAG = exports.BUSINESS_DEVELOPMENT_SAM_FLAG = exports.BUSINESS_DEVELOPMENT_DOSSIER_FLAG = exports.BUSINESS_DEVELOPMENT_FLAG = exports.ENGAGEMENT_VNEXT_FLAG = exports.ENGAGEMENT_AUTHOR_EXAMPLE_ANALYSIS_FLAG = exports.ENGAGEMENT_FIRM_MAIL_CONTEXT_FLAG = exports.OUTREACH_CLIENT_PROFILE_FLAG = exports.OUTREACH_ASYNC_FLAG = exports.MEETINGS_CROSS_USER_FLAG = exports.MERI_ALERT_IMPORTANT_PRIORITIES = exports.MERI_ALERTS_IMPORTANT_ONLY_FLAG = exports.STRATEGY_WATCHER_FLAG = exports.CONTEXT_STEWARD_FLAG = exports.AGENTIC_MERI_FLAG = exports.STRATEGY_PLANNER_MERI_FLAG = exports.STRATEGY_PLANNER_FLAG = exports.MERI_DOCK_UNDOCK_UI_FLAG = exports.MEETINGS_V2_FLAG = exports.NOTETAKER_FLAG = exports.MERIV2_FLAGS = exports.tenantFeatureEnabled = void 0;
exports.meriV2Enabled = meriV2Enabled;
exports.meriV2FlagEnabled = meriV2FlagEnabled;
exports.notetakerEnvEnabled = notetakerEnvEnabled;
exports.notetakerEnabled = notetakerEnabled;
exports.meetingsV2Enabled = meetingsV2Enabled;
exports.meriDockUndockUiEnabled = meriDockUndockUiEnabled;
exports.strategyPlannerEnabled = strategyPlannerEnabled;
exports.strategyPlannerMeriEnabled = strategyPlannerMeriEnabled;
exports.strategyMeriEnvEnabled = strategyMeriEnvEnabled;
exports.strategyMeriActive = strategyMeriActive;
exports.agenticMeriEnabled = agenticMeriEnabled;
exports.strategyAgentsEnvEnabled = strategyAgentsEnvEnabled;
exports.agenticMeriActive = agenticMeriActive;
exports.contextStewardEnabled = contextStewardEnabled;
exports.contextStewardActive = contextStewardActive;
exports.strategyWatcherEnabled = strategyWatcherEnabled;
exports.strategyWatcherActive = strategyWatcherActive;
exports.meriAlertsImportantOnly = meriAlertsImportantOnly;
exports.meetingsCrossUserEnabled = meetingsCrossUserEnabled;
exports.outreachAsyncFlagEnabled = outreachAsyncFlagEnabled;
exports.outreachClientProfileEnabled = outreachClientProfileEnabled;
exports.engagementFirmMailContextEnabled = engagementFirmMailContextEnabled;
exports.engagementAuthorExampleAnalysisEnabled = engagementAuthorExampleAnalysisEnabled;
exports.engagementVNextEnabled = engagementVNextEnabled;
exports.businessDevelopmentEnabled = businessDevelopmentEnabled;
exports.businessDevelopmentDossierEnabled = businessDevelopmentDossierEnabled;
exports.businessDevelopmentSamEnabled = businessDevelopmentSamEnabled;
exports.businessDevelopmentLdaEnabled = businessDevelopmentLdaEnabled;
exports.businessDevelopmentPdlCompanyEnabled = businessDevelopmentPdlCompanyEnabled;
exports.businessDevelopmentPdlPeopleEnabled = businessDevelopmentPdlPeopleEnabled;
exports.businessDevelopmentBriefEnabled = businessDevelopmentBriefEnabled;
exports.businessDevelopmentMeriProspectToolsEnabled = businessDevelopmentMeriProspectToolsEnabled;
exports.businessDevelopmentClaimValidationEnabled = businessDevelopmentClaimValidationEnabled;
exports.businessDevelopmentWatchEnabled = businessDevelopmentWatchEnabled;
exports.bizdevJevTaskModes = bizdevJevTaskModes;
exports.entitlementsForTenant = entitlementsForTenant;
exports.meriJobsEnabled = meriJobsEnabled;
exports.adminSettableMeriFlags = adminSettableMeriFlags;
const shared_1 = require("@capiro/shared");
const shared_2 = require("@capiro/shared");
var shared_3 = require("@capiro/shared");
Object.defineProperty(exports, "tenantFeatureEnabled", { enumerable: true, get: function () { return shared_3.tenantFeatureEnabled; } });
/**
 * MeriV2 surface flags (Phase 0). Govern whether an existing surface PROXIES to
 * the meriv2-orchestrator instead of running its in-process path. Both default
 * OFF and are ANDed with the global MERIV2_ENABLED env kill-switch, so MeriV2
 * stays dormant until a human flips BOTH the env switch and a per-tenant flag
 * (the < 5s rollback in SC0.4 is flipping either back off).
 */
exports.MERIV2_FLAGS = {
    inEditorAssistant: 'meriv2.inEditorAssistant',
    workspaceGen: 'meriv2.workspaceGen',
    // C4: the full Meri chat surface. When ON (and MERIV2_ENABLED), apps/api's
    // chat route proxies to the orchestrator's /meri-api/chat loop instead of
    // running the in-process MeriService path.
    fullChat: 'meriv2.fullChat',
};
/** Global env kill-switch for MeriV2. Default OFF — only the literal 'true' enables. */
function meriV2Enabled(env = process.env) {
    return env.MERIV2_ENABLED === 'true';
}
/**
 * A MeriV2 surface flag is active when the env kill-switch is on AND the
 * per-tenant flag resolves true. GA (2026-07): the tenant flag defaults ON, so
 * a tenant without an explicit flag is on MeriV2 whenever MERIV2_ENABLED is set
 * — opt out with an explicit `false`. MERIV2_ENABLED off → dormant everywhere.
 */
function meriV2FlagEnabled(settings, flag, env = process.env) {
    return meriV2Enabled(env) && (0, shared_2.tenantFeatureEnabled)(settings, flag, true);
}
/**
 * Meeting Notetaker (docs/plans/meeting-notetaker-bot-plan.md). Governs whether a
 * tenant's users can dispatch the Recall.ai bot to join/transcribe meetings.
 * Modeled on the MeriV2 surface flags: ANDed with a global env kill-switch
 * (NOTETAKER_ENABLED). Ran as an opt-in canary (capiro-internal only) through
 * 2026-07-13; promoted to GA that day (Ninja's call, made with the item-F
 * compliance gap — DPA/subprocessor listing/consent-copy legal review/trial-tier
 * upgrade — still open) so the tenant default flips true, same GA shape as
 * meriV2FlagEnabled above. A tenant can still be carved OUT by writing an
 * explicit `false` into its settings_jsonb (same SQL UPDATE path used for the
 * original canary flip) — the per-tenant flag is now an opt-out, not an opt-in.
 */
exports.NOTETAKER_FLAG = 'notetaker.enabled';
/** Global env kill-switch for the notetaker. Default OFF — only the literal 'true' enables. */
function notetakerEnvEnabled(env = process.env) {
    return env.NOTETAKER_ENABLED === 'true';
}
/**
 * The notetaker is active for a tenant when the env kill-switch is on AND the
 * per-tenant `notetaker.enabled` flag does not resolve false (tenant default
 * true — GA). Either the env switch off, or an explicit per-tenant `false`,
 * keeps it dormant.
 */
function notetakerEnabled(settings, env = process.env) {
    return notetakerEnvEnabled(env) && (0, shared_2.tenantFeatureEnabled)(settings, exports.NOTETAKER_FLAG, true);
}
/**
 * Meetings & Meri redesign (docs/plans/2026-07-10-meetings-meri-v2-redesign-plan.md).
 * Gates the rebuilt Engagement → Meetings module (Day/Month/List, private-until-
 * shared sharing, Meeting Library, Documents integration) so it can be flipped on
 * per tenant after parity verification instead of a big-bang cutover.
 *
 * UNLIKE the notetaker / MeriV2 flags, this is a PURE presentation swap — it drives
 * no external processor and carries no consent/compliance risk — so it deliberately
 * has NO env kill-switch (adding one would mean a config-schema + task-def env change,
 * which we avoid given the known CDK↔task-def drift). A per-tenant flag alone is the
 * right lever: default OFF, flipped via the capiro-admin flag surface (the same
 * settings_jsonb.clioFeatureFlags path used for every other rollout). Surfaced to
 * the web via GET /me so the client can route to the new module.
 */
exports.MEETINGS_V2_FLAG = 'meetingsV2.enabled';
/** Whether a tenant is on the redesigned Meetings module (per-tenant, default OFF). */
function meetingsV2Enabled(settings) {
    return (0, shared_2.tenantFeatureEnabled)(settings, exports.MEETINGS_V2_FLAG, false);
}
exports.MERI_DOCK_UNDOCK_UI_FLAG = 'meriDockUndockUi.enabled';
/** Whether a tenant receives the new global Meri dock/undock presentation (default OFF). */
function meriDockUndockUiEnabled(settings) {
    return (0, shared_2.tenantFeatureEnabled)(settings, exports.MERI_DOCK_UNDOCK_UI_FLAG, false);
}
/**
 * Strategy Planner (PPBE) module (docs Strategy Planner Phase 1 plan). Gates the
 * new Strategies section (library, timeline, editor) served by the standalone
 * api-strategy service at /strategy-api/*. Like meetingsV2, this is a PURE
 * presentation/feature flag with NO env kill-switch — default OFF, flipped per
 * tenant via the settings_jsonb.clioFeatureFlags path, surfaced to the web via
 * GET /me. The api-strategy service enforces the same flag server-side.
 */
exports.STRATEGY_PLANNER_FLAG = 'strategyPlanner.enabled';
/** Whether a tenant is on the Strategy Planner module (per-tenant, default OFF). */
function strategyPlannerEnabled(settings) {
    return (0, shared_2.tenantFeatureEnabled)(settings, exports.STRATEGY_PLANNER_FLAG, false);
}
/**
 * Gates Meri inside the Strategy Planner (draft-from-goal + rail assistant +
 * reference-editor assist; G5). UNLIKE the surface flag, this is ANDed with a
 * global env kill-switch STRATEGY_MERI_ENABLED (mirrors MERIV2_ENABLED /
 * meriV2Enabled) so LLM creation stays dormant until BOTH the env switch is on
 * AND the per-tenant flag resolves true — the <5s rollback is flipping either
 * back off. Per-tenant flag default OFF (pilot).
 */
exports.STRATEGY_PLANNER_MERI_FLAG = 'strategyPlannerMeri.enabled';
/** The per-tenant Meri flag alone (no env AND) — used where only the tenant opt-in matters. */
function strategyPlannerMeriEnabled(settings) {
    return (0, shared_2.tenantFeatureEnabled)(settings, exports.STRATEGY_PLANNER_MERI_FLAG, false);
}
/** Global env kill-switch for Strategy-Planner Meri. Default OFF — only the literal 'true' enables. */
function strategyMeriEnvEnabled(env = process.env) {
    return env.STRATEGY_MERI_ENABLED === 'true';
}
/**
 * Strategy-Planner Meri is active for a tenant only when the env kill-switch is
 * on AND the per-tenant flag resolves true (both default OFF). This is the
 * value surfaced to the web (GET /me) and mirrored server-side by api-strategy.
 */
function strategyMeriActive(settings, env = process.env) {
    return strategyMeriEnvEnabled(env) && strategyPlannerMeriEnabled(settings);
}
/**
 * Gates agentic Meri inside the Strategy Planner (Phase 2 agentic phases).
 * Mirrors the strategyPlannerMeri quartet: ANDed with a global env kill-switch
 * STRATEGY_AGENTS_ENABLED so the agentic surface stays dormant until BOTH the
 * env switch is on AND the per-tenant flag resolves true — the <5s rollback is
 * flipping either back off. Per-tenant flag default OFF (pilot). The
 * api-strategy service enforces the same pair server-side
 * (StrategyFlagsService.isAgenticFlagEnabled / AgenticGuard).
 */
exports.AGENTIC_MERI_FLAG = 'agenticMeri.enabled';
/** The per-tenant agentic-Meri flag alone (no env AND) — used where only the tenant opt-in matters. */
function agenticMeriEnabled(settings) {
    return (0, shared_2.tenantFeatureEnabled)(settings, exports.AGENTIC_MERI_FLAG, false);
}
/** Global env kill-switch for Strategy-Planner agentic Meri. Default OFF — only the literal 'true' enables. */
function strategyAgentsEnvEnabled(env = process.env) {
    return env.STRATEGY_AGENTS_ENABLED === 'true';
}
/**
 * Agentic Meri is active for a tenant only when the env kill-switch is on AND
 * the per-tenant flag resolves true (both default OFF). This is the value
 * surfaced to the web (GET /me) and mirrored server-side by api-strategy.
 */
function agenticMeriActive(settings, env = process.env) {
    return strategyAgentsEnvEnabled(env) && agenticMeriEnabled(settings);
}
/**
 * Context Steward fact extraction (Stage E) — the LLM-spend extract route is
 * gated server-side by api-strategy's ContextStewardGuard on
 * (STRATEGY_AGENTS_ENABLED env AND per-tenant contextSteward.enabled), ON TOP
 * of the agenticMeri umbrella. This mirrors that pair so GET /me can surface a
 * `contextSteward` feature bit the web uses to gate the "Extract facts" button
 * (without it, agenticMeri-only tenants see a button that 403s on every click).
 */
exports.CONTEXT_STEWARD_FLAG = 'contextSteward.enabled';
/** The per-tenant Context Steward flag alone (no env AND) — default OFF. */
function contextStewardEnabled(settings) {
    return (0, shared_2.tenantFeatureEnabled)(settings, exports.CONTEXT_STEWARD_FLAG, false);
}
/**
 * The Context Steward is active for a tenant only when the agentic env
 * kill-switch is on AND the per-tenant flag resolves true (both default OFF).
 * Surfaced to the web (GET /me); api-strategy enforces the same pair
 * server-side (ContextStewardGuard via isAgenticFlagEnabled).
 */
function contextStewardActive(settings, env = process.env) {
    return strategyAgentsEnvEnabled(env) && contextStewardEnabled(settings);
}
/**
 * Strategy Watcher (Stage F) — the Watch-mode surface is gated server-side by
 * api-strategy on (STRATEGY_AGENTS_ENABLED env AND per-tenant
 * strategyWatcher.enabled), ON TOP of the agenticMeri umbrella:
 * StrategyWatcherGuard on the run-check route and a per-occurrence flag check
 * in the F2 scheduler. This mirrors that pair so GET /me can surface a
 * `strategyWatcher` feature bit the web uses to gate the Watch rail — without
 * it, agenticMeri-only tenants get a Watch toggle whose scheduled checks skip
 * quietly forever and a "Run check now" button that 403s on every click (the
 * exact lying-UI pattern the Stage E contextSteward bit exists to prevent).
 */
exports.STRATEGY_WATCHER_FLAG = 'strategyWatcher.enabled';
/** The per-tenant Strategy Watcher flag alone (no env AND) — default OFF. */
function strategyWatcherEnabled(settings) {
    return (0, shared_2.tenantFeatureEnabled)(settings, exports.STRATEGY_WATCHER_FLAG, false);
}
/**
 * The Strategy Watcher is active for a tenant only when the agentic env
 * kill-switch is on AND the per-tenant flag resolves true (both default OFF).
 * Surfaced to the web (GET /me); api-strategy enforces the same pair
 * server-side (StrategyWatcherGuard + the scheduler's per-occurrence check).
 */
function strategyWatcherActive(settings, env = process.env) {
    return strategyAgentsEnvEnabled(env) && strategyWatcherEnabled(settings);
}
/**
 * Meri proactive-alert importance floor (2026-07-12). The Meri chat bell + the
 * "🔔 Scheduled briefings" banner are both fed by MeriService.listAlerts, which
 * historically returned EVERY pending clio_proactive_alert with no importance
 * floor — so routine "client quiet 30+ days" notices (priority 'normal') sat
 * next to time-sensitive "meeting in <48h, no prep" items (priority 'high'),
 * which read as noise. When this flag is ON (the DEFAULT), listAlerts surfaces
 * only the high-importance priority band — the exact set MeriInboxBanner's
 * priorityClass already renders as the red "critical" style, so nothing that
 * showed red disappears and nothing that showed 'notable'/'info' survives.
 * Reversible per tenant to `false` for the old verbose behavior. This is a pure
 * READ filter: no env kill-switch, no emitter change — the alerts are still
 * written, just not shown, so flipping the flag off restores them instantly.
 */
exports.MERI_ALERTS_IMPORTANT_ONLY_FLAG = 'meriAlertsImportantOnly';
/**
 * The priorities that count as "important" for the Meri alert inbox. Kept in
 * one place and mirrors MeriInboxBanner.priorityClass's red "critical" band
 * (high | critical | urgent) so the API floor and the UI styling never drift.
 */
exports.MERI_ALERT_IMPORTANT_PRIORITIES = ['high', 'critical', 'urgent'];
/** Whether a tenant's Meri alert inbox is filtered to important priorities (default ON). */
function meriAlertsImportantOnly(settings) {
    return (0, shared_2.tenantFeatureEnabled)(settings, exports.MERI_ALERTS_IMPORTANT_ONLY_FLAG, true);
}
/**
 * Meetings v2 Phase 2 — cross-user collision model (docs/plans/2026-07-11-…).
 * When ON, the client "Shared from meetings" feed groups per-mailbox rows that
 * share a Graph `iCalUId` into ONE record (canonical notes, one row per meeting,
 * a contributor expander for colleagues with their own prep/debrief — spec §7)
 * and merges multi-user notetakers (§4.4). Purely a response-layer grouping;
 * default OFF, flipped per tenant AFTER the meetingsV2 UI is verified. Separate
 * flag from meetingsV2 so it rolls out independently, and rollback = flip off
 * (Option B is non-destructive — nothing to un-merge).
 */
exports.MEETINGS_CROSS_USER_FLAG = 'meetingsCrossUser.enabled';
/** Whether a tenant is on the Phase 2 cross-user collision grouping (default OFF). */
function meetingsCrossUserEnabled(settings) {
    return (0, shared_2.tenantFeatureEnabled)(settings, exports.MEETINGS_CROSS_USER_FLAG, false);
}
/**
 * Async outreach pipeline UI rollout (plan W4.4). The async job pipeline itself is
 * gated by GLOBAL env kill-switches (OUTREACH_ASYNC_GEN / OUTREACH_ASYNC_SEND); this
 * per-tenant flag is the CANARY lever on top — the wizard uses the job-mode UI for a
 * tenant only when BOTH the env switch is on AND this flag resolves true. Default OFF
 * so flipping the env var alone never changes any tenant's UX until it is explicitly
 * canaried, mirroring the notetaker (env AND per-tenant) belt-and-suspenders. Flipped
 * per tenant via settings_jsonb.clioFeatureFlags (the standard rollout path). Surfaced
 * to the web (ANDed with the env switch) via GET /me `features.outreachAsyncGen/Send`.
 */
exports.OUTREACH_ASYNC_FLAG = 'outreachAsync.enabled';
/** Per-tenant async-outreach opt-in (default OFF). ANDed with the env kill-switch by
 *  the caller (GET /me) — this alone does not enable anything. */
function outreachAsyncFlagEnabled(settings) {
    return (0, shared_2.tenantFeatureEnabled)(settings, exports.OUTREACH_ASYNC_FLAG, false);
}
/**
 * Rich client-profile outreach context (2026-07-11). When ON, campaign drafts get
 * extra recipient-INVARIANT profile blocks in the cached v2 prefix — the "people
 * this client works with" roster (client_people), the coordinated target-office
 * map (ClientTarget ∪ OfficeRecommendation), and canonical status for the client's
 * OWN tracked bills. Like meetingsV2 this is a PURE context/presentation change
 * (no external processor, no compliance risk, additive SUPPORTING INTELLIGENCE),
 * so it deliberately has NO env kill-switch (avoids a config-schema + task-def env
 * change and the known CDK↔task-def drift). Per-tenant flag alone, default OFF,
 * flipped via settings_jsonb.clioFeatureFlags (the standard rollout path).
 */
exports.OUTREACH_CLIENT_PROFILE_FLAG = 'outreachClientProfile.enabled';
/** Whether a tenant gets the rich client-profile context blocks (default OFF). */
function outreachClientProfileEnabled(settings) {
    return (0, shared_2.tenantFeatureEnabled)(settings, exports.OUTREACH_CLIENT_PROFILE_FLAG, false);
}
/**
 * Engagement Phase 1 §3.d2 — firm-shared mailbox context.
 *
 * Allows a colleague's EXPLICITLY client-linked mail thread to inform a draft.
 * ANDed with ENGAGEMENT_EMAIL_CONTEXT_SCOPE=firm_shared and an ethical-wall pass:
 * all three must hold, so neither an env change nor a tenant flag alone can widen
 * a user's mailbox reach. Default OFF, and Phase 1 §6.3 requires confirming the
 * organization's mailbox-sharing model before enabling any tenant.
 */
exports.ENGAGEMENT_FIRM_MAIL_CONTEXT_FLAG = 'engagementFirmMailContext';
function engagementFirmMailContextEnabled(settings) {
    return (0, shared_2.tenantFeatureEnabled)(settings, exports.ENGAGEMENT_FIRM_MAIL_CONTEXT_FLAG, false);
}
/**
 * Engagement Phase 1 §3.e1 — consent to analyze the author's own sent outreach
 * for a STRUCTURED style profile.
 *
 * Note what this flag does and does not permit. Even when ON, raw example text
 * never reaches the drafting prompt: it is read only to extract a structured
 * profile (sentence length, greeting/closing pattern, tone tags), and only from
 * examples for the SAME client. Default OFF because analyzing a user's sent mail
 * — even their own — is a consent decision, not a default.
 */
exports.ENGAGEMENT_AUTHOR_EXAMPLE_ANALYSIS_FLAG = 'engagementAuthorExampleAnalysis';
function engagementAuthorExampleAnalysisEnabled(settings) {
    return (0, shared_2.tenantFeatureEnabled)(settings, exports.ENGAGEMENT_AUTHOR_EXAMPLE_ANALYSIS_FLAG, false);
}
/**
 * Engagement vNext reskin (Meetings/Library/Outreach/Reports on
 * os.capiro.ai) — TENANT ACCESS gate. The reskin shipped with all four
 * destinations claimed unconditionally by VNextRouter as soon as
 * ENGAGEMENT_DESTINATION_READY marked them ready (engagement-route-state.ts),
 * with no per-tenant access control at all — every os.capiro.ai user on every
 * tenant saw it. THIS flag is the separate, orthogonal concern: which tenants
 * may see ANY of the four destinations, regardless of how many of them have a
 * vNext body. Dogfooding canary: capiro-internal only for now (see
 * CAPIRO_INTERNAL_SLUG in auth/clerk-role.util.ts and the meriV3/notetaker
 * canary precedent in meriv3-flags.ts); widening later is just flipping this
 * flag for more tenants via set-tenant-flag.ts — no code change required.
 *
 * Like meetingsV2 / strategyPlanner this is a PURE presentation swap — no
 * external processor, no compliance risk — so it deliberately has NO env
 * kill-switch. Per-tenant flag alone, default OFF (fails closed exactly like
 * the others), flipped via settings_jsonb.clioFeatureFlags. Surfaced to the
 * web via GET /me so VNextRouter can gate the actual component it renders —
 * NOT the nav-visibility-only `meFeature` mechanism in routeManifest.ts,
 * which hides a rail link but does not stop the route from resolving.
 */
exports.ENGAGEMENT_VNEXT_FLAG = 'engagementVNext.enabled';
/** Whether a tenant is on the Engagement vNext reskin (per-tenant, default OFF). */
function engagementVNextEnabled(settings) {
    return (0, shared_2.tenantFeatureEnabled)(settings, exports.ENGAGEMENT_VNEXT_FLAG, false);
}
/**
 * Business Development Phase 1 (Portfolio → Business Development). Gates the
 * new firm-pipeline module behind a per-tenant flag. It has no external
 * processor or provider dependency, defaults OFF, and is enforced by the API
 * guard as well as hidden in the web application.
 */
exports.BUSINESS_DEVELOPMENT_FLAG = 'businessDevelopment.enabled';
function businessDevelopmentEnabled(settings) {
    return (0, shared_2.tenantFeatureEnabled)(settings, exports.BUSINESS_DEVELOPMENT_FLAG, false);
}
/**
 * Business Development Phase 2 — dossier/candidate-search surface. Gates the
 * three GET dossier routes (candidate search, canonical company dossier,
 * prospect dossier) behind an additional per-tenant flag, default OFF, so the
 * Phase 2 read surface can be canaried independently of the Phase 1 pipeline.
 */
exports.BUSINESS_DEVELOPMENT_DOSSIER_FLAG = 'businessDevelopment.dossier.enabled';
function businessDevelopmentDossierEnabled(settings) {
    return (0, shared_2.tenantFeatureEnabled)(settings, exports.BUSINESS_DEVELOPMENT_DOSSIER_FLAG, false);
}
/**
 * Phase 2 live-provider gates. Each defaults OFF. They gate ONLY live adapter
 * calls (SAM entity lookup in the identity section; LDA remains an
 * already-ingested projection so this flag controls live fetch behavior, not
 * the readability of ingested rows); already-ingested FederalAward /
 * FederalAssistanceAward / SamOpportunity / LdaFiling projections stay
 * readable regardless. PDL has no client in the repo — its flags render a
 * deferred section and never issue a call.
 */
exports.BUSINESS_DEVELOPMENT_SAM_FLAG = 'businessDevelopment.provider.sam.enabled';
exports.BUSINESS_DEVELOPMENT_LDA_FLAG = 'businessDevelopment.provider.lda.enabled';
exports.BUSINESS_DEVELOPMENT_PDL_COMPANY_FLAG = 'businessDevelopment.provider.pdlCompany.enabled';
exports.BUSINESS_DEVELOPMENT_PDL_PEOPLE_FLAG = 'businessDevelopment.provider.pdlPeople.enabled';
function businessDevelopmentSamEnabled(settings) {
    return (0, shared_2.tenantFeatureEnabled)(settings, exports.BUSINESS_DEVELOPMENT_SAM_FLAG, false);
}
function businessDevelopmentLdaEnabled(settings) {
    return (0, shared_2.tenantFeatureEnabled)(settings, exports.BUSINESS_DEVELOPMENT_LDA_FLAG, false);
}
function businessDevelopmentPdlCompanyEnabled(settings) {
    return (0, shared_2.tenantFeatureEnabled)(settings, exports.BUSINESS_DEVELOPMENT_PDL_COMPANY_FLAG, false);
}
function businessDevelopmentPdlPeopleEnabled(settings) {
    return (0, shared_2.tenantFeatureEnabled)(settings, exports.BUSINESS_DEVELOPMENT_PDL_PEOPLE_FLAG, false);
}
// ── Business Development Phase 4 — brief surface + Meri tool flags ──────────
/**
 * Phase 4 — the brief UI/API surface. Gates every brief route (an additional
 * guard on top of Phase 1/2 flags, exactly like the dossier flag). Default
 * OFF; fail-closed 404 when off.
 */
exports.BUSINESS_DEVELOPMENT_BRIEF_FLAG = 'businessDevelopment.brief.enabled';
function businessDevelopmentBriefEnabled(settings) {
    return (0, shared_2.tenantFeatureEnabled)(settings, exports.BUSINESS_DEVELOPMENT_BRIEF_FLAG, false);
}
/**
 * Phase 4 — Meri prospect tools (brief generation/editing through Meri).
 * Independent of the brief UI flag so the API surface can be canaried
 * separately from assistant-driven use. Default OFF.
 */
exports.BUSINESS_DEVELOPMENT_MERI_PROSPECT_TOOLS_FLAG = 'businessDevelopment.meriProspectTools.enabled';
function businessDevelopmentMeriProspectToolsEnabled(settings) {
    return (0, shared_2.tenantFeatureEnabled)(settings, exports.BUSINESS_DEVELOPMENT_MERI_PROSPECT_TOOLS_FLAG, false);
}
/**
 * Phase 4 — assisted deterministic claim validation inside briefs (identity /
 * citation / exact amount / date / stage checks). BD-CLAIM Jev semantic
 * validation stays DARK regardless; this flag only exposes the deterministic
 * checker endpoints. Default OFF.
 */
exports.BUSINESS_DEVELOPMENT_CLAIM_VALIDATION_FLAG = 'businessDevelopment.claimValidation.enabled';
function businessDevelopmentClaimValidationEnabled(settings) {
    return (0, shared_2.tenantFeatureEnabled)(settings, exports.BUSINESS_DEVELOPMENT_CLAIM_VALIDATION_FLAG, false);
}
// ── Business Development Phase 5 — prospect watch & alerts ──────────────────
/**
 * Phase 5 — the watch/alert surface. Additional per-tenant flag (default OFF)
 * on TOP of the Phase 1 base flag: a tenant sees watch/alert routes only when
 * BOTH flags are on, and the global env kill-switch BIZDEV_WATCH_ENABLED must
 * also be true. Enforced by BusinessDevelopmentWatchFlagGuard (404 fail
 * closed, exactly like the Phase 1/2/4 guards) and surfaced via GET /me
 * `features.businessDevelopmentWatch`.
 */
exports.BUSINESS_DEVELOPMENT_WATCH_FLAG = 'businessDevelopment.watch.enabled';
function businessDevelopmentWatchEnabled(settings) {
    return (0, shared_2.tenantFeatureEnabled)(settings, exports.BUSINESS_DEVELOPMENT_WATCH_FLAG, false);
}
// ── Business Development Phase 3 — Jev task-mode enrollment flags ──────────
/**
 * Per-tenant enrollment booleans for each BD Jev task AND each mode. Each
 * defaults OFF; a tenant must be explicitly enrolled in BOTH a task and a
 * mode before any BD Jev evaluation runs for it (see bizdev-jev-mode.ts for
 * how these combine with env modes and the shared registry ceiling).
 */
exports.BIZDEV_JEV_TASK_MODE_FLAGS = {
    bd_entity: {
        shadow: 'businessDevelopment.jev.task.bdEntity.shadow.enabled',
        internal_canary: 'businessDevelopment.jev.task.bdEntity.internalCanary.enabled',
    },
    bd_signal: {
        shadow: 'businessDevelopment.jev.task.bdSignal.shadow.enabled',
        internal_canary: 'businessDevelopment.jev.task.bdSignal.internalCanary.enabled',
    },
};
/** The highest mode the tenant explicitly enrolled for a task (least permissive wins upstream). */
function bizdevJevTaskModes(settings) {
    const flag = (name) => (0, shared_2.tenantFeatureEnabled)(settings, name, false);
    const forTask = (task) => {
        const flags = exports.BIZDEV_JEV_TASK_MODE_FLAGS[task];
        if (flag(flags.internal_canary))
            return 'internal_canary';
        if (flag(flags.shadow))
            return 'shadow';
        return 'off';
    };
    return { bd_entity: forTask('bd_entity'), bd_signal: forTask('bd_signal') };
}
/**
 * Effective feature entitlements for a tenant (Phase 5, §5.1). The tier map
 * (resolveEntitlements) sets the baseline; a per-tenant boolean override at
 * settings_jsonb.clioFeatureFlags['entitlement.<feature>'] can flip a single
 * feature on/off — reusing the SAME boolean reader as every rollout flag
 * (SC 5.1.3, no parallel mechanism). Default per feature = the tier grant, so
 * with today's all-granting tiers this returns every feature true (no-op).
 */
function entitlementsForTenant(settings, planTier) {
    const base = (0, shared_1.resolveEntitlements)(planTier);
    const out = {};
    for (const f of shared_1.ENTITLEMENT_FEATURES) {
        // ALWAYS_ENTITLED features (core memory governance, SC 5.1.4) are never
        // gated — a per-tenant override cannot revoke them, mirroring how
        // resolveEntitlements re-unions them after the tier lookup.
        out[f] = shared_1.ALWAYS_ENTITLED.includes(f)
            ? true
            : (0, shared_2.tenantFeatureEnabled)(settings, `entitlement.${f}`, base.has(f));
    }
    return out;
}
/**
 * Meri jobs (program plan §5.1). `meri.jobs` lets a tenant create the Stage 2
 * job kinds (deliverable, audit, scheduled). Default OFF; research sessions
 * are unaffected. Set through the capiro-admin flag endpoint.
 */
exports.MERI_JOB_FLAGS = {
    jobs: 'meri.jobs',
};
/** Whether the tenant may create Stage 2 job kinds (`meri.jobs`, default OFF). */
function meriJobsEnabled(settings) {
    return (0, shared_2.tenantFeatureEnabled)(settings, exports.MERI_JOB_FLAGS.jobs, false);
}
/** Flags the capiro-admin flag endpoint may set. */
function adminSettableMeriFlags() {
    return [...Object.values(exports.MERIV2_FLAGS), ...Object.values(exports.MERI_JOB_FLAGS)];
}
//# sourceMappingURL=tenant-flags.js.map