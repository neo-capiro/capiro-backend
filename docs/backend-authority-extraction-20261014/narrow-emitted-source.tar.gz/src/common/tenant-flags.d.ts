/**
 * Per-tenant Meri feature flags (assistant-parity cross-cutting convention).
 *
 * Flags live under tenants.settings_jsonb.clioFeatureFlags, e.g.
 *   { "clioFeatureFlags": { "runAnalysis": true } }
 * and compose with env kill-switches: a feature is active only when its env
 * switch is on AND the tenant flag resolves true (each feature picks its own
 * tenant default — pilot features default false, GA features default true).
 * Pure so it unit-tests under `src/**.spec.ts`.
 */
import { type EntitlementFeature } from '@capiro/shared';
export { tenantFeatureEnabled } from '@capiro/shared';
/**
 * MeriV2 surface flags (Phase 0). Govern whether an existing surface PROXIES to
 * the meriv2-orchestrator instead of running its in-process path. Both default
 * OFF and are ANDed with the global MERIV2_ENABLED env kill-switch, so MeriV2
 * stays dormant until a human flips BOTH the env switch and a per-tenant flag
 * (the < 5s rollback in SC0.4 is flipping either back off).
 */
export declare const MERIV2_FLAGS: {
    readonly inEditorAssistant: "meriv2.inEditorAssistant";
    readonly workspaceGen: "meriv2.workspaceGen";
    readonly fullChat: "meriv2.fullChat";
};
export type MeriV2FlagKey = (typeof MERIV2_FLAGS)[keyof typeof MERIV2_FLAGS];
/** Global env kill-switch for MeriV2. Default OFF — only the literal 'true' enables. */
export declare function meriV2Enabled(env?: NodeJS.ProcessEnv): boolean;
/**
 * A MeriV2 surface flag is active when the env kill-switch is on AND the
 * per-tenant flag resolves true. GA (2026-07): the tenant flag defaults ON, so
 * a tenant without an explicit flag is on MeriV2 whenever MERIV2_ENABLED is set
 * — opt out with an explicit `false`. MERIV2_ENABLED off → dormant everywhere.
 */
export declare function meriV2FlagEnabled(settings: unknown, flag: MeriV2FlagKey, env?: NodeJS.ProcessEnv): boolean;
/**
 * Meeting Notetaker (docs/plans/meeting-notetaker-bot-plan.md). Governs whether a
 * tenant's users can dispatch the Recall.ai bot to join/transcribe meetings.
 * Modeled on the MeriV2 surface flags: ANDed with a global env kill-switch
 * (NOTETAKER_ENABLED). Ran as an opt-in canary (capiro-internal only) through
 * 2026-07-13; promoted to GA that day (Ninja's call, made with the item-F
 * compliance gap — DPA/subprocessor listing/consent-copy legal review/trial-tier
 * upgrade — still open) so the tenant default flips true, same GA shape as
 * meriV2FlagEnabled above. A tenant can still be carved OUT by writing an
 * explicit `false` into its settings_jsonb (same SQL UPDATE path used for the
 * original canary flip) — the per-tenant flag is now an opt-out, not an opt-in.
 */
export declare const NOTETAKER_FLAG: "notetaker.enabled";
/** Global env kill-switch for the notetaker. Default OFF — only the literal 'true' enables. */
export declare function notetakerEnvEnabled(env?: NodeJS.ProcessEnv): boolean;
/**
 * The notetaker is active for a tenant when the env kill-switch is on AND the
 * per-tenant `notetaker.enabled` flag does not resolve false (tenant default
 * true — GA). Either the env switch off, or an explicit per-tenant `false`,
 * keeps it dormant.
 */
export declare function notetakerEnabled(settings: unknown, env?: NodeJS.ProcessEnv): boolean;
/**
 * Meetings & Meri redesign (docs/plans/2026-07-10-meetings-meri-v2-redesign-plan.md).
 * Gates the rebuilt Engagement → Meetings module (Day/Month/List, private-until-
 * shared sharing, Meeting Library, Documents integration) so it can be flipped on
 * per tenant after parity verification instead of a big-bang cutover.
 *
 * UNLIKE the notetaker / MeriV2 flags, this is a PURE presentation swap — it drives
 * no external processor and carries no consent/compliance risk — so it deliberately
 * has NO env kill-switch (adding one would mean a config-schema + task-def env change,
 * which we avoid given the known CDK↔task-def drift). A per-tenant flag alone is the
 * right lever: default OFF, flipped via the capiro-admin flag surface (the same
 * settings_jsonb.clioFeatureFlags path used for every other rollout). Surfaced to
 * the web via GET /me so the client can route to the new module.
 */
export declare const MEETINGS_V2_FLAG: "meetingsV2.enabled";
/** Whether a tenant is on the redesigned Meetings module (per-tenant, default OFF). */
export declare function meetingsV2Enabled(settings: unknown): boolean;
export declare const MERI_DOCK_UNDOCK_UI_FLAG: "meriDockUndockUi.enabled";
/** Whether a tenant receives the new global Meri dock/undock presentation (default OFF). */
export declare function meriDockUndockUiEnabled(settings: unknown): boolean;
/**
 * Strategy Planner (PPBE) module (docs Strategy Planner Phase 1 plan). Gates the
 * new Strategies section (library, timeline, editor) served by the standalone
 * api-strategy service at /strategy-api/*. Like meetingsV2, this is a PURE
 * presentation/feature flag with NO env kill-switch — default OFF, flipped per
 * tenant via the settings_jsonb.clioFeatureFlags path, surfaced to the web via
 * GET /me. The api-strategy service enforces the same flag server-side.
 */
export declare const STRATEGY_PLANNER_FLAG: "strategyPlanner.enabled";
/** Whether a tenant is on the Strategy Planner module (per-tenant, default OFF). */
export declare function strategyPlannerEnabled(settings: unknown): boolean;
/**
 * Gates Meri inside the Strategy Planner (draft-from-goal + rail assistant +
 * reference-editor assist; G5). UNLIKE the surface flag, this is ANDed with a
 * global env kill-switch STRATEGY_MERI_ENABLED (mirrors MERIV2_ENABLED /
 * meriV2Enabled) so LLM creation stays dormant until BOTH the env switch is on
 * AND the per-tenant flag resolves true — the <5s rollback is flipping either
 * back off. Per-tenant flag default OFF (pilot).
 */
export declare const STRATEGY_PLANNER_MERI_FLAG: "strategyPlannerMeri.enabled";
/** The per-tenant Meri flag alone (no env AND) — used where only the tenant opt-in matters. */
export declare function strategyPlannerMeriEnabled(settings: unknown): boolean;
/** Global env kill-switch for Strategy-Planner Meri. Default OFF — only the literal 'true' enables. */
export declare function strategyMeriEnvEnabled(env?: NodeJS.ProcessEnv): boolean;
/**
 * Strategy-Planner Meri is active for a tenant only when the env kill-switch is
 * on AND the per-tenant flag resolves true (both default OFF). This is the
 * value surfaced to the web (GET /me) and mirrored server-side by api-strategy.
 */
export declare function strategyMeriActive(settings: unknown, env?: NodeJS.ProcessEnv): boolean;
/**
 * Gates agentic Meri inside the Strategy Planner (Phase 2 agentic phases).
 * Mirrors the strategyPlannerMeri quartet: ANDed with a global env kill-switch
 * STRATEGY_AGENTS_ENABLED so the agentic surface stays dormant until BOTH the
 * env switch is on AND the per-tenant flag resolves true — the <5s rollback is
 * flipping either back off. Per-tenant flag default OFF (pilot). The
 * api-strategy service enforces the same pair server-side
 * (StrategyFlagsService.isAgenticFlagEnabled / AgenticGuard).
 */
export declare const AGENTIC_MERI_FLAG: "agenticMeri.enabled";
/** The per-tenant agentic-Meri flag alone (no env AND) — used where only the tenant opt-in matters. */
export declare function agenticMeriEnabled(settings: unknown): boolean;
/** Global env kill-switch for Strategy-Planner agentic Meri. Default OFF — only the literal 'true' enables. */
export declare function strategyAgentsEnvEnabled(env?: NodeJS.ProcessEnv): boolean;
/**
 * Agentic Meri is active for a tenant only when the env kill-switch is on AND
 * the per-tenant flag resolves true (both default OFF). This is the value
 * surfaced to the web (GET /me) and mirrored server-side by api-strategy.
 */
export declare function agenticMeriActive(settings: unknown, env?: NodeJS.ProcessEnv): boolean;
/**
 * Context Steward fact extraction (Stage E) — the LLM-spend extract route is
 * gated server-side by api-strategy's ContextStewardGuard on
 * (STRATEGY_AGENTS_ENABLED env AND per-tenant contextSteward.enabled), ON TOP
 * of the agenticMeri umbrella. This mirrors that pair so GET /me can surface a
 * `contextSteward` feature bit the web uses to gate the "Extract facts" button
 * (without it, agenticMeri-only tenants see a button that 403s on every click).
 */
export declare const CONTEXT_STEWARD_FLAG: "contextSteward.enabled";
/** The per-tenant Context Steward flag alone (no env AND) — default OFF. */
export declare function contextStewardEnabled(settings: unknown): boolean;
/**
 * The Context Steward is active for a tenant only when the agentic env
 * kill-switch is on AND the per-tenant flag resolves true (both default OFF).
 * Surfaced to the web (GET /me); api-strategy enforces the same pair
 * server-side (ContextStewardGuard via isAgenticFlagEnabled).
 */
export declare function contextStewardActive(settings: unknown, env?: NodeJS.ProcessEnv): boolean;
/**
 * Strategy Watcher (Stage F) — the Watch-mode surface is gated server-side by
 * api-strategy on (STRATEGY_AGENTS_ENABLED env AND per-tenant
 * strategyWatcher.enabled), ON TOP of the agenticMeri umbrella:
 * StrategyWatcherGuard on the run-check route and a per-occurrence flag check
 * in the F2 scheduler. This mirrors that pair so GET /me can surface a
 * `strategyWatcher` feature bit the web uses to gate the Watch rail — without
 * it, agenticMeri-only tenants get a Watch toggle whose scheduled checks skip
 * quietly forever and a "Run check now" button that 403s on every click (the
 * exact lying-UI pattern the Stage E contextSteward bit exists to prevent).
 */
export declare const STRATEGY_WATCHER_FLAG: "strategyWatcher.enabled";
/** The per-tenant Strategy Watcher flag alone (no env AND) — default OFF. */
export declare function strategyWatcherEnabled(settings: unknown): boolean;
/**
 * The Strategy Watcher is active for a tenant only when the agentic env
 * kill-switch is on AND the per-tenant flag resolves true (both default OFF).
 * Surfaced to the web (GET /me); api-strategy enforces the same pair
 * server-side (StrategyWatcherGuard + the scheduler's per-occurrence check).
 */
export declare function strategyWatcherActive(settings: unknown, env?: NodeJS.ProcessEnv): boolean;
/**
 * Meri proactive-alert importance floor (2026-07-12). The Meri chat bell + the
 * "🔔 Scheduled briefings" banner are both fed by MeriService.listAlerts, which
 * historically returned EVERY pending clio_proactive_alert with no importance
 * floor — so routine "client quiet 30+ days" notices (priority 'normal') sat
 * next to time-sensitive "meeting in <48h, no prep" items (priority 'high'),
 * which read as noise. When this flag is ON (the DEFAULT), listAlerts surfaces
 * only the high-importance priority band — the exact set MeriInboxBanner's
 * priorityClass already renders as the red "critical" style, so nothing that
 * showed red disappears and nothing that showed 'notable'/'info' survives.
 * Reversible per tenant to `false` for the old verbose behavior. This is a pure
 * READ filter: no env kill-switch, no emitter change — the alerts are still
 * written, just not shown, so flipping the flag off restores them instantly.
 */
export declare const MERI_ALERTS_IMPORTANT_ONLY_FLAG: "meriAlertsImportantOnly";
/**
 * The priorities that count as "important" for the Meri alert inbox. Kept in
 * one place and mirrors MeriInboxBanner.priorityClass's red "critical" band
 * (high | critical | urgent) so the API floor and the UI styling never drift.
 */
export declare const MERI_ALERT_IMPORTANT_PRIORITIES: readonly ["high", "critical", "urgent"];
/** Whether a tenant's Meri alert inbox is filtered to important priorities (default ON). */
export declare function meriAlertsImportantOnly(settings: unknown): boolean;
/**
 * Meetings v2 Phase 2 — cross-user collision model (docs/plans/2026-07-11-…).
 * When ON, the client "Shared from meetings" feed groups per-mailbox rows that
 * share a Graph `iCalUId` into ONE record (canonical notes, one row per meeting,
 * a contributor expander for colleagues with their own prep/debrief — spec §7)
 * and merges multi-user notetakers (§4.4). Purely a response-layer grouping;
 * default OFF, flipped per tenant AFTER the meetingsV2 UI is verified. Separate
 * flag from meetingsV2 so it rolls out independently, and rollback = flip off
 * (Option B is non-destructive — nothing to un-merge).
 */
export declare const MEETINGS_CROSS_USER_FLAG: "meetingsCrossUser.enabled";
/** Whether a tenant is on the Phase 2 cross-user collision grouping (default OFF). */
export declare function meetingsCrossUserEnabled(settings: unknown): boolean;
/**
 * Async outreach pipeline UI rollout (plan W4.4). The async job pipeline itself is
 * gated by GLOBAL env kill-switches (OUTREACH_ASYNC_GEN / OUTREACH_ASYNC_SEND); this
 * per-tenant flag is the CANARY lever on top — the wizard uses the job-mode UI for a
 * tenant only when BOTH the env switch is on AND this flag resolves true. Default OFF
 * so flipping the env var alone never changes any tenant's UX until it is explicitly
 * canaried, mirroring the notetaker (env AND per-tenant) belt-and-suspenders. Flipped
 * per tenant via settings_jsonb.clioFeatureFlags (the standard rollout path). Surfaced
 * to the web (ANDed with the env switch) via GET /me `features.outreachAsyncGen/Send`.
 */
export declare const OUTREACH_ASYNC_FLAG: "outreachAsync.enabled";
/** Per-tenant async-outreach opt-in (default OFF). ANDed with the env kill-switch by
 *  the caller (GET /me) — this alone does not enable anything. */
export declare function outreachAsyncFlagEnabled(settings: unknown): boolean;
/**
 * Rich client-profile outreach context (2026-07-11). When ON, campaign drafts get
 * extra recipient-INVARIANT profile blocks in the cached v2 prefix — the "people
 * this client works with" roster (client_people), the coordinated target-office
 * map (ClientTarget ∪ OfficeRecommendation), and canonical status for the client's
 * OWN tracked bills. Like meetingsV2 this is a PURE context/presentation change
 * (no external processor, no compliance risk, additive SUPPORTING INTELLIGENCE),
 * so it deliberately has NO env kill-switch (avoids a config-schema + task-def env
 * change and the known CDK↔task-def drift). Per-tenant flag alone, default OFF,
 * flipped via settings_jsonb.clioFeatureFlags (the standard rollout path).
 */
export declare const OUTREACH_CLIENT_PROFILE_FLAG: "outreachClientProfile.enabled";
/** Whether a tenant gets the rich client-profile context blocks (default OFF). */
export declare function outreachClientProfileEnabled(settings: unknown): boolean;
/**
 * Engagement Phase 1 §3.d2 — firm-shared mailbox context.
 *
 * Allows a colleague's EXPLICITLY client-linked mail thread to inform a draft.
 * ANDed with ENGAGEMENT_EMAIL_CONTEXT_SCOPE=firm_shared and an ethical-wall pass:
 * all three must hold, so neither an env change nor a tenant flag alone can widen
 * a user's mailbox reach. Default OFF, and Phase 1 §6.3 requires confirming the
 * organization's mailbox-sharing model before enabling any tenant.
 */
export declare const ENGAGEMENT_FIRM_MAIL_CONTEXT_FLAG: "engagementFirmMailContext";
export declare function engagementFirmMailContextEnabled(settings: unknown): boolean;
/**
 * Engagement Phase 1 §3.e1 — consent to analyze the author's own sent outreach
 * for a STRUCTURED style profile.
 *
 * Note what this flag does and does not permit. Even when ON, raw example text
 * never reaches the drafting prompt: it is read only to extract a structured
 * profile (sentence length, greeting/closing pattern, tone tags), and only from
 * examples for the SAME client. Default OFF because analyzing a user's sent mail
 * — even their own — is a consent decision, not a default.
 */
export declare const ENGAGEMENT_AUTHOR_EXAMPLE_ANALYSIS_FLAG: "engagementAuthorExampleAnalysis";
export declare function engagementAuthorExampleAnalysisEnabled(settings: unknown): boolean;
/**
 * Engagement vNext reskin (Meetings/Library/Outreach/Reports on
 * os.capiro.ai) — TENANT ACCESS gate. The reskin shipped with all four
 * destinations claimed unconditionally by VNextRouter as soon as
 * ENGAGEMENT_DESTINATION_READY marked them ready (engagement-route-state.ts),
 * with no per-tenant access control at all — every os.capiro.ai user on every
 * tenant saw it. THIS flag is the separate, orthogonal concern: which tenants
 * may see ANY of the four destinations, regardless of how many of them have a
 * vNext body. Dogfooding canary: capiro-internal only for now (see
 * CAPIRO_INTERNAL_SLUG in auth/clerk-role.util.ts and the meriV3/notetaker
 * canary precedent in meriv3-flags.ts); widening later is just flipping this
 * flag for more tenants via set-tenant-flag.ts — no code change required.
 *
 * Like meetingsV2 / strategyPlanner this is a PURE presentation swap — no
 * external processor, no compliance risk — so it deliberately has NO env
 * kill-switch. Per-tenant flag alone, default OFF (fails closed exactly like
 * the others), flipped via settings_jsonb.clioFeatureFlags. Surfaced to the
 * web via GET /me so VNextRouter can gate the actual component it renders —
 * NOT the nav-visibility-only `meFeature` mechanism in routeManifest.ts,
 * which hides a rail link but does not stop the route from resolving.
 */
export declare const ENGAGEMENT_VNEXT_FLAG: "engagementVNext.enabled";
/** Whether a tenant is on the Engagement vNext reskin (per-tenant, default OFF). */
export declare function engagementVNextEnabled(settings: unknown): boolean;
/**
 * Business Development Phase 1 (Portfolio → Business Development). Gates the
 * new firm-pipeline module behind a per-tenant flag. It has no external
 * processor or provider dependency, defaults OFF, and is enforced by the API
 * guard as well as hidden in the web application.
 */
export declare const BUSINESS_DEVELOPMENT_FLAG: "businessDevelopment.enabled";
export declare function businessDevelopmentEnabled(settings: unknown): boolean;
/**
 * Business Development Phase 2 — dossier/candidate-search surface. Gates the
 * three GET dossier routes (candidate search, canonical company dossier,
 * prospect dossier) behind an additional per-tenant flag, default OFF, so the
 * Phase 2 read surface can be canaried independently of the Phase 1 pipeline.
 */
export declare const BUSINESS_DEVELOPMENT_DOSSIER_FLAG: "businessDevelopment.dossier.enabled";
export declare function businessDevelopmentDossierEnabled(settings: unknown): boolean;
/**
 * Phase 2 live-provider gates. Each defaults OFF. They gate ONLY live adapter
 * calls (SAM entity lookup in the identity section; LDA remains an
 * already-ingested projection so this flag controls live fetch behavior, not
 * the readability of ingested rows); already-ingested FederalAward /
 * FederalAssistanceAward / SamOpportunity / LdaFiling projections stay
 * readable regardless. PDL has no client in the repo — its flags render a
 * deferred section and never issue a call.
 */
export declare const BUSINESS_DEVELOPMENT_SAM_FLAG: "businessDevelopment.provider.sam.enabled";
export declare const BUSINESS_DEVELOPMENT_LDA_FLAG: "businessDevelopment.provider.lda.enabled";
export declare const BUSINESS_DEVELOPMENT_PDL_COMPANY_FLAG: "businessDevelopment.provider.pdlCompany.enabled";
export declare const BUSINESS_DEVELOPMENT_PDL_PEOPLE_FLAG: "businessDevelopment.provider.pdlPeople.enabled";
export declare function businessDevelopmentSamEnabled(settings: unknown): boolean;
export declare function businessDevelopmentLdaEnabled(settings: unknown): boolean;
export declare function businessDevelopmentPdlCompanyEnabled(settings: unknown): boolean;
export declare function businessDevelopmentPdlPeopleEnabled(settings: unknown): boolean;
/**
 * Phase 4 — the brief UI/API surface. Gates every brief route (an additional
 * guard on top of Phase 1/2 flags, exactly like the dossier flag). Default
 * OFF; fail-closed 404 when off.
 */
export declare const BUSINESS_DEVELOPMENT_BRIEF_FLAG: "businessDevelopment.brief.enabled";
export declare function businessDevelopmentBriefEnabled(settings: unknown): boolean;
/**
 * Phase 4 — Meri prospect tools (brief generation/editing through Meri).
 * Independent of the brief UI flag so the API surface can be canaried
 * separately from assistant-driven use. Default OFF.
 */
export declare const BUSINESS_DEVELOPMENT_MERI_PROSPECT_TOOLS_FLAG: "businessDevelopment.meriProspectTools.enabled";
export declare function businessDevelopmentMeriProspectToolsEnabled(settings: unknown): boolean;
/**
 * Phase 4 — assisted deterministic claim validation inside briefs (identity /
 * citation / exact amount / date / stage checks). BD-CLAIM Jev semantic
 * validation stays DARK regardless; this flag only exposes the deterministic
 * checker endpoints. Default OFF.
 */
export declare const BUSINESS_DEVELOPMENT_CLAIM_VALIDATION_FLAG: "businessDevelopment.claimValidation.enabled";
export declare function businessDevelopmentClaimValidationEnabled(settings: unknown): boolean;
/**
 * Phase 5 — the watch/alert surface. Additional per-tenant flag (default OFF)
 * on TOP of the Phase 1 base flag: a tenant sees watch/alert routes only when
 * BOTH flags are on, and the global env kill-switch BIZDEV_WATCH_ENABLED must
 * also be true. Enforced by BusinessDevelopmentWatchFlagGuard (404 fail
 * closed, exactly like the Phase 1/2/4 guards) and surfaced via GET /me
 * `features.businessDevelopmentWatch`.
 */
export declare const BUSINESS_DEVELOPMENT_WATCH_FLAG: "businessDevelopment.watch.enabled";
export declare function businessDevelopmentWatchEnabled(settings: unknown): boolean;
/**
 * Per-tenant enrollment booleans for each BD Jev task AND each mode. Each
 * defaults OFF; a tenant must be explicitly enrolled in BOTH a task and a
 * mode before any BD Jev evaluation runs for it (see bizdev-jev-mode.ts for
 * how these combine with env modes and the shared registry ceiling).
 */
export declare const BIZDEV_JEV_TASK_MODE_FLAGS: Readonly<Record<'bd_entity' | 'bd_signal', Record<'shadow' | 'internal_canary', string>>>;
export type BizDevJevTenantMode = 'off' | 'shadow' | 'internal_canary';
export type BizDevJevTenantModes = Readonly<Record<'bd_entity' | 'bd_signal', BizDevJevTenantMode>>;
/** The highest mode the tenant explicitly enrolled for a task (least permissive wins upstream). */
export declare function bizdevJevTaskModes(settings: unknown): BizDevJevTenantModes;
/**
 * Effective feature entitlements for a tenant (Phase 5, §5.1). The tier map
 * (resolveEntitlements) sets the baseline; a per-tenant boolean override at
 * settings_jsonb.clioFeatureFlags['entitlement.<feature>'] can flip a single
 * feature on/off — reusing the SAME boolean reader as every rollout flag
 * (SC 5.1.3, no parallel mechanism). Default per feature = the tier grant, so
 * with today's all-granting tiers this returns every feature true (no-op).
 */
export declare function entitlementsForTenant(settings: unknown, planTier: string | null | undefined): Record<EntitlementFeature, boolean>;
/**
 * Meri jobs (program plan §5.1). `meri.jobs` lets a tenant create the Stage 2
 * job kinds (deliverable, audit, scheduled). Default OFF; research sessions
 * are unaffected. Set through the capiro-admin flag endpoint.
 */
export declare const MERI_JOB_FLAGS: {
    readonly jobs: "meri.jobs";
};
export type MeriJobFlagKey = (typeof MERI_JOB_FLAGS)[keyof typeof MERI_JOB_FLAGS];
/** Whether the tenant may create Stage 2 job kinds (`meri.jobs`, default OFF). */
export declare function meriJobsEnabled(settings: unknown): boolean;
/** Flags the capiro-admin flag endpoint may set. */
export declare function adminSettableMeriFlags(): string[];
//# sourceMappingURL=tenant-flags.d.ts.map