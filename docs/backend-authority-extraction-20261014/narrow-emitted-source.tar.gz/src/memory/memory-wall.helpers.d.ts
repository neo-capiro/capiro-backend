/**
 * Ethical-wall decision helpers (master plan Phase 1 — client memory as an
 * ACCESS boundary, upgrading G2's relevance-only client scope).
 *
 * Model: Client.memory_wall (default false) + client_memory_access grants.
 * A walled client's memory (clio_memory scope='client', client-linked
 * memory_items, and their context_embeddings rows) is visible only to granted
 * users. Fail-closed: an unknown/absent user is denied every walled client,
 * and a walled client with zero grants is invisible to everyone — admins
 * included (an ethical screen binds seniors too).
 *
 * These are plain functions that run inside the CALLER'S existing
 * withTenant/withTenantUser transaction rather than an injected service, for
 * the same reason memory-recall-source.helpers.ts is pure: every memory read
 * path (MeriService, MeriToolsService, MemoryStoreService, controllers) can
 * apply the wall without new constructor dependencies, and the decision logic
 * unit-tests in isolation. They are the PRIMARY enforcement today: the
 * wall-aware RLS policies (migration 20260719221000) are forward-ready but
 * inert for the live app role until the capiro_app role hardening lands (see
 * that migration's runtime caveat).
 */
import type { Prisma } from '@prisma/client';
/** The transactional client every helper runs on (withTenant/withTenantUser). */
type Tx = Prisma.TransactionClient;
/**
 * Render a validated Postgres uuid[] literal for inlining into raw SQL.
 * Every id must be a canonical UUID (they come from our own primary keys);
 * anything else throws rather than risking an injectable fragment.
 */
export declare function toUuidArrayLiteral(ids: readonly string[]): string;
/**
 * SQL fragment excluding rows attributed to any denied client, for appending
 * to a memory read's WHERE clause. Empty denied set → empty string (the
 * common, unwalled case pays nothing). The explicit IS NULL arm matters:
 * `col = ANY(...)` on a NULL column is NULL, and NOT NULL is still NULL —
 * without the arm every client-less row would vanish.
 */
export declare function wallExclusionSql(deniedClientIds: readonly string[], column: string): string;
/**
 * Client ids in this tenant whose memory the given user may NOT see: walled
 * clients where the user holds no client_memory_access grant. `userId = null`
 * (a path that never identified its user) denies every walled client —
 * fail-closed by construction. Runs on the caller's transaction so it
 * composes with the read it guards.
 *
 * GRANT LIFECYCLE — read this before "fixing" the predicate.
 * `client_memory_access` (Prisma `ClientMemoryAccess`, the `Client
 * .memoryAccessGrants` relation) has exactly six columns: id, tenant_id,
 * client_id, user_id, granted_by, created_at — see migration
 * 20260719220000_client_memory_walls. It has NO status, expires_at or
 * revoked_at. Revocation is a hard DELETE, performed by
 * `ClientsService.setMemoryAccess()`'s replace-set write, so a revoked grant
 * stops matching this NOT EXISTS the moment that transaction commits. There
 * is no soft-deleted, expired or dead row for this query to miss, and adding
 * a `status`/`expires_at`/`revoked_at` filter here is not a hardening — it
 * does not compile and the columns do not exist.
 *
 * The lifecycle-bearing model with `status` / `expires_at` / `revoked_at` is
 * the DIFFERENT `memory_access_grant` table (Prisma `MemoryAccessGrant`, the
 * `Client.governedMemoryGrants` relation). It grants governed-memory
 * PERMISSIONS (read/propose/approve), not ethical-wall membership, and is
 * read with its own liveness predicate in `MemoryAuthorizationService
 * .evaluateInTx()`. The two are deliberately separate layers: that service
 * calls `clientMemoryAllowed()` below for the wall AND queries
 * memory_access_grant for permissions. Closeout finding A2 attributed
 * memory_access_grant's columns to client_memory_access; they are not the
 * same table.
 */
export declare function fetchDeniedClientIds(tx: Tx, tenantId: string, userId: string | null): Promise<string[]>;
/**
 * May this user recall this client's memory? true = not walled, or walled
 * with a grant. A client id that does not resolve in this tenant is DENIED
 * (fail-closed — the caller is asking about something it cannot name).
 */
export { clientMemoryAllowed } from '@capiro/shared';
/**
 * Current client scope for a Clerk actor: visible, active client revisions for
 * an actor with active tenant membership. Resolve membership and ethical-wall
 * grants in the same read, and keep Clerk actor resolution inside the tenant
 * query: it is not a database user UUID. Callers recheck this scope after
 * async work before returning cached or provider-derived client content.
 * Revision hashes intentionally retain the dashboard cache contract.
 */
export declare function fetchAccessibleClientRevisionsForClerkActor(tx: Tx, tenantId: string, actorId: string): Promise<Array<{
    id: string;
    revision: string;
}>>;
/**
 * Embed the wall decision in an atomic write predicate. All parameters are SQL
 * identifiers supplied by code, never values; reject anything outside that grammar.
 * The caller still owns tenant/client/archive predicates and bound actor values.
 */
export declare function clientMemoryAllowedForRowOwnerSql(clientAlias: string, ownerAlias: string, ownerColumn: string): string;
//# sourceMappingURL=memory-wall.helpers.d.ts.map