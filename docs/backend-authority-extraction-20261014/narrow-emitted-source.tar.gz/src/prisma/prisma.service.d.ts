import { OnModuleDestroy, OnModuleInit } from '@nestjs/common';
import { Prisma, PrismaClient } from '@prisma/client';
/**
 * The tenant scope baked into a per-call query-extended client so its query
 * hook can inject the tenant predicate. `bypass` marks a `withSystem`
 * (cross-tenant) scope. (A closure — not AsyncLocalStorage — because Prisma
 * executes the extension hook off the caller's async context, so an ALS store
 * set around the call is not visible inside the hook.)
 */
type TenantScope = {
    tenantId: string;
    bypass?: false;
} | {
    bypass: true;
};
/**
 * Pure decision function for the tenant-scope query hook (exported for tests).
 * Returns the args to run: unchanged for bypass scopes, non-tenant-scoped
 * models, or non-where operations; otherwise a shallow clone with
 * `where.tenantId` forced to the scope's tenant. A sibling `tenantId` ANDs with
 * any existing where and, on unique-where ops, applies as an extended-where
 * filter (GA since Prisma 5).
 */
export declare function applyTenantScope(scope: TenantScope, model: string, operation: string, args: unknown, scopedModels: ReadonlySet<string>): unknown;
/**
 * RLS-aware Prisma client.
 *
 * ⚠️ Direct use of `this.prisma.<tenantModel>.findMany()` (without a tenant
 * scope) is NOT fail-closed and MUST be avoided. The runtime DB role
 * (capiro_app) is a member of the table-owner role and BYPASSES Postgres RLS,
 * so a bare query on a tenant-scoped model returns EVERY tenant's rows
 * (cross-tenant leak — the 2026-07-16 incident). Tenant isolation is enforced
 * ONLY by routing through the scoped helpers below, which inject
 * `where.tenantId` in-query. The `tenant-scope-guard.spec.ts` test fails the
 * build on any new bare tenant-scoped access. Bare access to GLOBAL (no
 * tenantId) reference tables is fine.
 *
 * Per-request tenant-scoped queries go through `withTenant(tenantId, fn)`.
 * That opens a transaction, sets the GUC with `SET LOCAL`, and hands the
 * caller a transactional client. When the transaction commits, the GUC is
 * automatically discarded, no leakage between requests.
 *
 * `withSystem(fn)` is the same pattern but with the bypass flag set, used
 * for cross-tenant admin work and webhook ingestion. Use sparingly and
 * always log via the audit_logs table.
 */
export declare class PrismaService extends PrismaClient implements OnModuleInit, OnModuleDestroy {
    private readonly logger;
    private readonly tenantScopedModels;
    onModuleInit(): Promise<void>;
    /**
     * A query-extended client with the given tenant scope baked in. IMPORTANT:
     * the runtime DB role (capiro_app) is a member of the table-owner role and
     * BYPASSES Postgres row-level security, so the RLS policies never fire for
     * the app connection. Tenant isolation is therefore enforced HERE, in-query:
     * for any where-bearing operation on a tenant-scoped model, we force
     * `where.tenantId = <scope tenant>`. A `bypass` scope (withSystem) injects
     * nothing, preserving intentional cross-tenant reach. Built per call — a
     * Prisma client extension is a lightweight proxy over the same connection
     * pool (no new connection), and baking the scope in a closure sidesteps the
     * ALS-context-loss that makes an AsyncLocalStorage approach silently no-op.
     */
    private scopedClient;
    onModuleDestroy(): Promise<void>;
    /**
     * Run `fn` with `app.current_tenant` set to the given UUID inside a
     * transaction. The transactional client passed to `fn` MUST be used for
     * any query that should respect the tenant scope.
     */
    withTenant<T>(tenantId: string, fn: (tx: Prisma.TransactionClient) => Promise<T>, opts?: {
        timeoutMs?: number;
    }): Promise<T>;
    /**
     * Like {@link withTenant}, but ALSO sets `app.current_user` in the same
     * transaction (Phase 1, 1C). Required for any query against a table whose
     * RLS policy references `current_user_id()` — today that's memory_items
     * and the memory_item-sourced rows of context_embeddings. Every other
     * table's RLS is unaffected by this GUC (their policies don't reference
     * it), so this is purely additive: existing `withTenant` callers on other
     * tables need no change. A caller that reads/writes memory_items via plain
     * `withTenant` instead of this method will silently see zero private-item
     * rows (visibility='tenant' rows are unaffected) — see the 1C migration's
     * header comment for the caller-conversion sweep this depends on.
     */
    withTenantUser<T>(tenantId: string, userId: string, fn: (tx: Prisma.TransactionClient) => Promise<T>, opts?: {
        timeoutMs?: number;
    }): Promise<T>;
    /**
     * Like {@link withTenant} but retries the whole transaction when Postgres
     * aborts it with a deadlock (SQLSTATE 40P01) or serialization failure
     * (40001) — both transient. Concurrent writers that touch the same rows are
     * expected to lose this race occasionally; the loser is safe to replay as
     * long as `fn` is idempotent (upsert / updateMany / deleteMany+create).
     *
     * Used by the Microsoft Graph sync, where a burst of webhook notifications
     * for a freshly connected mailbox runs several syncs at once and they all
     * upsert the same brand-new engagement_contacts rows.
     */
    withTenantRetry<T>(tenantId: string, fn: (tx: Prisma.TransactionClient) => Promise<T>, opts?: {
        timeoutMs?: number;
        retries?: number;
    }): Promise<T>;
    /**
     * Run `fn` with the RLS bypass flag enabled. Use only for trusted server
     * paths (cross-tenant admin tooling, webhook ingestion, migrations).
     */
    withSystem<T>(fn: (tx: Prisma.TransactionClient) => Promise<T>, opts?: {
        timeoutMs?: number;
    }): Promise<T>;
}
/**
 * True when a Postgres error is a transient transaction conflict worth
 * retrying: a deadlock (40P01) or a serialization failure (40001). Prisma
 * maps these to P2034, but when the failure surfaces from a raw query it can
 * arrive as a generic error whose message carries the SQLSTATE, so we sniff
 * both.
 */
export declare function isRetryableTransactionError(err: unknown): boolean;
export {};
//# sourceMappingURL=prisma.service.d.ts.map