import { CanActivate, ExecutionContext } from '@nestjs/common';
import { Reflector } from '@nestjs/core';
/**
 * Enforces a minimum role for the route. The required roles come from the
 * @Roles() decorator on the handler or controller. Access is granted if the
 * caller's role rank >= the lowest-ranked required role.
 *
 * The TenantContext is set by TenantContextMiddleware. If it's missing the
 * route was reached without auth, fail closed.
 */
export declare class RolesGuard implements CanActivate {
    private readonly reflector;
    constructor(reflector: Reflector);
    canActivate(context: ExecutionContext): boolean;
}
//# sourceMappingURL=roles.guard.d.ts.map