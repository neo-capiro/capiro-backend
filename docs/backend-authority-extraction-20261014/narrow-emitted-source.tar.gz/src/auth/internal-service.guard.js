"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.InternalServiceGuard = void 0;
const common_1 = require("@nestjs/common");
const config_1 = require("@nestjs/config");
/**
 * Gates a route to trusted BACKEND-SERVICE callers only (currently: intel-api
 * resolving a tenant's AI credential for the live-hearing path, BYOK3) — never
 * a browser-held Clerk JWT. Checks the `x-internal-service-secret` header
 * against `INTERNAL_SERVICE_SECRET` (a static secret shared only between
 * backend services' ECS task defs, never sent to a browser).
 *
 * Deliberately NOT `RolesGuard`: a route returning a raw decrypted provider
 * API key must not be reachable by any ordinary user JWT (a standard_user's
 * own browser could otherwise self-serve their tenant's raw key, which no
 * existing route allows — every AI-key admin endpoint is write-only, never
 * re-displaying the plaintext). Fail-closed: if the secret is unset, the
 * route is unconditionally denied, not left open.
 */
let InternalServiceGuard = class InternalServiceGuard {
    constructor(config) {
        this.config = config;
    }
    canActivate(context) {
        const expected = this.config.get('INTERNAL_SERVICE_SECRET', { infer: true });
        if (!expected) {
            throw new common_1.ForbiddenException('Internal service route is disabled (no shared secret configured)');
        }
        const req = context.switchToHttp().getRequest();
        const provided = req.headers['x-internal-service-secret'];
        if (typeof provided !== 'string' || provided !== expected) {
            throw new common_1.ForbiddenException('Invalid or missing internal service secret');
        }
        return true;
    }
};
exports.InternalServiceGuard = InternalServiceGuard;
exports.InternalServiceGuard = InternalServiceGuard = __decorate([
    (0, common_1.Injectable)(),
    __metadata("design:paramtypes", [config_1.ConfigService])
], InternalServiceGuard);
//# sourceMappingURL=internal-service.guard.js.map