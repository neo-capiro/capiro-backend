"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.AuthModule = void 0;
const common_1 = require("@nestjs/common");
const clerk_service_js_1 = require("./clerk.service.js");
const clerk_provisioning_service_js_1 = require("./clerk-provisioning.service.js");
const identity_outbox_service_js_1 = require("./identity-outbox.service.js");
const internal_service_guard_js_1 = require("./internal-service.guard.js");
const roles_guard_js_1 = require("./roles.guard.js");
/**
 * Global authentication/authorization services. InternalServiceGuard is
 * exported so backend-only controllers in Context Plane, Workspace, Intel and
 * other feature modules resolve the same fail-closed shared-secret guard rather
 * than relying on implicit class construction.
 */
let AuthModule = class AuthModule {
};
exports.AuthModule = AuthModule;
exports.AuthModule = AuthModule = __decorate([
    (0, common_1.Global)(),
    (0, common_1.Module)({
        providers: [
            clerk_service_js_1.ClerkService,
            clerk_provisioning_service_js_1.ClerkProvisioningService,
            identity_outbox_service_js_1.IdentityOutboxService,
            internal_service_guard_js_1.InternalServiceGuard,
            roles_guard_js_1.RolesGuard,
        ],
        exports: [
            clerk_service_js_1.ClerkService,
            clerk_provisioning_service_js_1.ClerkProvisioningService,
            identity_outbox_service_js_1.IdentityOutboxService,
            internal_service_guard_js_1.InternalServiceGuard,
            roles_guard_js_1.RolesGuard,
        ],
    })
], AuthModule);
//# sourceMappingURL=auth.module.js.map