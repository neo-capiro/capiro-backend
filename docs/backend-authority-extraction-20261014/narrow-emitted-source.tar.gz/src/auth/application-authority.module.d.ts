export declare class ApplicationAuthorityModule {
}
//# sourceMappingURL=application-authority.module.d.ts.map