"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.assertApplicationAuthorityIdentityBody = assertApplicationAuthorityIdentityBody;
exports.parseApplicationAuthorityContextBody = parseApplicationAuthorityContextBody;
exports.applicationAuthorityRevision = applicationAuthorityRevision;
exports.applicationAuthorityIdentityReceipt = applicationAuthorityIdentityReceipt;
exports.readApplicationAuthorityContext = readApplicationAuthorityContext;
const node_crypto_1 = require("node:crypto");
const node_util_1 = require("node:util");
const common_1 = require("@nestjs/common");
// Wire syntax, not resource authority: nil and UUID versions 7/8 are allowed.
const UUID = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/;
const HASH = /^[0-9a-f]{64}$/;
function assertApplicationAuthorityIdentityBody(body) {
    closedBody(body, []);
}
function parseApplicationAuthorityContextBody(body) {
    const record = closedBody(body, ['identitySha256', 'conversationId', 'clientId']);
    const { identitySha256, conversationId, clientId } = record;
    if (typeof identitySha256 !== 'string' || !HASH.test(identitySha256) ||
        typeof conversationId !== 'string' || !UUID.test(conversationId) ||
        typeof clientId !== 'string' || !UUID.test(clientId)) {
        throw new common_1.BadRequestException('Invalid application authority request');
    }
    return { identitySha256, conversationId, clientId };
}
function closedBody(body, keys) {
    if (!body || typeof body !== 'object' || node_util_1.types.isProxy(body) || Array.isArray(body) ||
        (Object.getPrototypeOf(body) !== Object.prototype && Object.getPrototypeOf(body) !== null)) {
        throw new common_1.BadRequestException('Invalid application authority request');
    }
    const own = Reflect.ownKeys(body);
    if (own.length !== keys.length || own.some((key) => typeof key !== 'string' || !keys.includes(key))) {
        throw new common_1.BadRequestException('Invalid application authority request');
    }
    const result = Object.create(null);
    for (const key of keys) {
        const descriptor = Object.getOwnPropertyDescriptor(body, key);
        if (!descriptor || !('value' in descriptor) || !descriptor.enumerable) {
            throw new common_1.BadRequestException('Invalid application authority request');
        }
        result[key] = descriptor.value;
    }
    return result;
}
/** Deterministic digest of explicit server-owned facts, never an authority grant. */
function applicationAuthorityRevision(kind, facts) {
    return (0, node_crypto_1.createHash)('sha256').update(`capiro-application-authority-${kind}-v1\n${stableFacts(facts)}`).digest('hex');
}
function stableFacts(value, depth = 0) {
    if (depth > 12)
        throw new common_1.ForbiddenException('Application authority unavailable');
    if (value && typeof value === 'object' && node_util_1.types.isProxy(value)) {
        throw new common_1.ForbiddenException('Application authority unavailable');
    }
    if (value === null || typeof value === 'boolean' || typeof value === 'string') {
        if (typeof value === 'string' && value.length > 4096)
            throw new common_1.ForbiddenException('Application authority unavailable');
        return JSON.stringify(value);
    }
    if (typeof value === 'number' && Number.isFinite(value))
        return JSON.stringify(value);
    if (Array.isArray(value)) {
        if (value.length > 128)
            throw new common_1.ForbiddenException('Application authority unavailable');
        return `[${value.map((child) => stableFacts(child, depth + 1)).join(',')}]`;
    }
    if (value && typeof value === 'object' &&
        (Object.getPrototypeOf(value) === Object.prototype || Object.getPrototypeOf(value) === null)) {
        const keys = Reflect.ownKeys(value);
        if (keys.length > 128 || keys.some((key) => typeof key !== 'string')) {
            throw new common_1.ForbiddenException('Application authority unavailable');
        }
        return `{${keys.sort().map((key) => {
            const descriptor = Object.getOwnPropertyDescriptor(value, key);
            if (!descriptor || !('value' in descriptor))
                throw new common_1.ForbiddenException('Application authority unavailable');
            return `${JSON.stringify(key)}:${stableFacts(descriptor.value, depth + 1)}`;
        }).join(',')}}`;
    }
    throw new common_1.ForbiddenException('Application authority unavailable');
}
function applicationAuthorityIdentityReceipt(evidence, checkedAtMs = Date.now()) {
    if (!Number.isSafeInteger(checkedAtMs) || checkedAtMs < 0 ||
        !Number.isSafeInteger(evidence.expiresAtMs) || evidence.expiresAtMs <= checkedAtMs ||
        !HASH.test(evidence.identityRevision) ||
        ![evidence.principal.tenantId, evidence.principal.actorId].every((id) => typeof id === 'string' && id.length > 0 && id.length <= 256))
        throw new common_1.ForbiddenException('Application authority unavailable');
    return {
        principal: { tenantId: evidence.principal.tenantId, actorId: evidence.principal.actorId },
        identityRevision: evidence.identityRevision,
        checkedAtMs,
        expiresAtMs: evidence.expiresAtMs,
    };
}
/** Ports are existing application owners; selectors and the echoed hash grant nothing. */
async function readApplicationAuthorityContext(input, ports) {
    const initial = await ports.identity();
    const conversation = await ports.conversation(input.conversationId);
    assertCurrentConversation(conversation, input, initial.principal);
    await ports.conversationScope(conversation);
    await ports.clientVisible(input.clientId);
    await ports.clientAuthority(input.clientId);
    // Re-read session and local identity after the asynchronous context owner reads.
    const current = await ports.identity();
    if (current.principal.tenantId !== initial.principal.tenantId ||
        current.principal.actorId !== initial.principal.actorId ||
        current.identityRevision !== initial.identityRevision) {
        throw new common_1.ForbiddenException('Application authority unavailable');
    }
    // The online session await must not preserve an older conversation binding
    // or wall receipt. Re-read existing context owners on its other side.
    const latestConversation = await ports.conversation(input.conversationId);
    assertCurrentConversation(latestConversation, input, current.principal);
    const scope = await ports.conversationScope(latestConversation);
    await ports.clientVisible(input.clientId);
    const client = await ports.clientAuthority(input.clientId);
    // Close local membership/impersonation changes during the context reads.
    // This uses the just-read session's original bounds, never a cached receipt.
    const finalIdentity = await current.recheckCurrent();
    if (finalIdentity.identityRevision !== current.identityRevision ||
        finalIdentity.principal.tenantId !== current.principal.tenantId ||
        finalIdentity.principal.actorId !== current.principal.actorId) {
        throw new common_1.ForbiddenException('Application authority unavailable');
    }
    const identity = applicationAuthorityIdentityReceipt({
        ...finalIdentity, expiresAtMs: Math.min(initial.expiresAtMs, current.expiresAtMs, finalIdentity.expiresAtMs),
    });
    return {
        ...identity,
        identitySha256: input.identitySha256,
        conversationId: latestConversation.id,
        selectedClientId: input.clientId,
        contextRevision: applicationAuthorityRevision('context', [
            current.identityRevision,
            [latestConversation.id, latestConversation.tenantId, latestConversation.userId, latestConversation.clientId,
                latestConversation.status, latestConversation.archivedAt],
            scope, client,
        ]),
    };
}
function assertCurrentConversation(conversation, input, principal) {
    if (conversation.id !== input.conversationId ||
        conversation.tenantId !== principal.tenantId || conversation.userId !== principal.actorId ||
        conversation.clientId !== input.clientId || conversation.archivedAt !== null ||
        conversation.status !== 'active')
        throw new common_1.ForbiddenException('Application authority unavailable');
}
//# sourceMappingURL=application-authority.js.map