"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var ClerkService_1;
Object.defineProperty(exports, "__esModule", { value: true });
exports.ClerkService = void 0;
// ============================================================================
// ⛔ CHANGE-CONTROL: AUTHENTICATION / EMAIL INTEGRATION — APPROVAL REQUIRED
// ----------------------------------------------------------------------------
// Do NOT modify this file (or anything touching Clerk auth, the tenant-context
// middleware, JWT/session handling, Microsoft Graph OAuth, the Clerk webhook,
// or integration connection/token persistence) without EXPLICIT prior approval
// from Neo. These paths gate every authenticated request and the email/Outlook
// integration; a subtle change here has repeatedly caused tenant-wide 403/500
// outages (see git history 2026-06-07 + skill: capiro-tenant-onboarding-flow).
// Investigate read-only and PROPOSE first; wait for go-ahead before editing,
// merging, or deploying.
// ============================================================================
const common_1 = require("@nestjs/common");
const config_1 = require("@nestjs/config");
const backend_1 = require("@clerk/backend");
/**
 * Thin wrapper around @clerk/backend. Centralizes JWT verification and
 * Backend API access so the rest of the codebase never imports Clerk
 * directly.
 */
let ClerkService = ClerkService_1 = class ClerkService {
    constructor(config) {
        this.logger = new common_1.Logger(ClerkService_1.name);
        this.secretKey = config.get('CLERK_SECRET_KEY', { infer: true });
        this.issuer = config.get('CLERK_JWT_ISSUER', { infer: true });
        this.client = (0, backend_1.createClerkClient)({ secretKey: this.secretKey });
    }
    get backend() {
        return this.client;
    }
    /**
     * Verify a Clerk session JWT. Returns the claims if valid, throws otherwise.
     * Uses Clerk's JWKS (cached by the SDK).
     */
    async verifySessionToken(token) {
        const raw = await (0, backend_1.verifyToken)(token, {
            secretKey: this.secretKey,
        });
        // Issuer pinning must be done HERE, not by passing `issuer` to
        // verifyToken. `issuer` is NOT a VerifyJwtOptions field in
        // @clerk/backend@1.34.0 — the option type is
        // { audience, authorizedParties, clockSkewInMs, key } and the runtime
        // destructures exactly those four, so the value we used to spread in was
        // silently DISCARDED and pinned nothing. Enforce it explicitly.
        //
        // Defence in depth: the JWKS is fetched with our own CLERK_SECRET_KEY, so a
        // foreign-instance token already fails signature verification above.
        this.assertIssuer(raw);
        return normalizeClaims(raw);
    }
    /** Read-only online session check for application receipts. Never mints tokens.
     * The SDK has no per-getSession AbortSignal. This deadline bounds caller
     * refusal; late SDK settlement is consumed and cannot produce a receipt. */
    async assertActiveApplicationAuthoritySession(claims) {
        const denied = () => new common_1.UnauthorizedException('Application authority unavailable');
        if (typeof claims.sid !== 'string' || !/^[A-Za-z0-9_-]{1,256}$/.test(claims.sid) ||
            typeof claims.sub !== 'string' || !/^[A-Za-z0-9_-]{1,256}$/.test(claims.sub) ||
            !Number.isSafeInteger(claims.exp) || !Number.isSafeInteger((claims.exp ?? 0) * 1000) ||
            (claims.exp ?? 0) * 1000 <= Date.now())
            throw denied();
        const sessionId = claims.sid;
        const userId = claims.sub;
        const jwtExpiresAtMs = claims.exp * 1000;
        const deadlineMs = Date.now() + 2000;
        let timer;
        try {
            const session = await Promise.race([
                Promise.resolve().then(() => this.client.sessions.getSession(sessionId)),
                new Promise((_resolve, reject) => {
                    timer = setTimeout(() => reject(denied()), 2000);
                }),
            ]);
            const now = Date.now();
            if (now >= deadlineMs || !session || session.id !== sessionId || session.userId !== userId ||
                session.status !== 'active' ||
                ![session.createdAt, session.expireAt, session.abandonAt].every((value) => Number.isSafeInteger(value) && value >= 0) || session.createdAt > now)
                throw denied();
            const expiresAtMs = Math.min(jwtExpiresAtMs, session.expireAt, session.abandonAt);
            if (expiresAtMs <= now)
                throw denied();
            return {
                id: session.id, userId: session.userId, status: 'active',
                createdAt: session.createdAt, expireAt: session.expireAt, abandonAt: session.abandonAt,
                actor: session.actor, expiresAtMs,
            };
        }
        catch {
            throw denied();
        }
        finally {
            if (timer !== undefined)
                clearTimeout(timer);
        }
    }
    assertIssuer(raw) {
        if (!this.issuer)
            return;
        if (raw.iss !== this.issuer) {
            throw new Error(`Token issuer mismatch: expected ${this.issuer}, got ${String(raw.iss)}`);
        }
    }
};
exports.ClerkService = ClerkService;
exports.ClerkService = ClerkService = ClerkService_1 = __decorate([
    (0, common_1.Injectable)(),
    __metadata("design:paramtypes", [config_1.ConfigService])
], ClerkService);
/**
 * Normalize Clerk session-token claims into our flat ClerkSessionClaims
 * contract. Clerk's v2 default session token nests the active-org claims under
 * a compact `o` object ({ id, slg, rol }) instead of the v1 flat
 * `org_id`/`org_slug`/`org_role`. Without this, the tenant-context middleware
 * (which reads `org_id`) sees `undefined` for every request and 403s every
 * authenticated user. We map v2 -> flat, preferring any explicit flat claim
 * (e.g. from a custom JWT template) when present.
 */
function normalizeClaims(raw) {
    const o = (raw.o ?? undefined);
    const orgId = raw.org_id ?? o?.id;
    const orgSlug = raw.org_slug ?? o?.slg;
    const orgRole = raw.org_role ?? normalizeOrgRole(o?.rol);
    return {
        ...raw,
        org_id: orgId,
        org_slug: orgSlug,
        org_role: orgRole,
    };
}
/**
 * v2 `o.rol` is the short role ("admin"/"member"); v1 `org_role` is the
 * prefixed form ("org:admin"/"org:member"). mapClerkRoleToCapiro accepts both,
 * but normalize to the prefixed form for consistency with the webhook path.
 */
function normalizeOrgRole(rol) {
    if (!rol)
        return undefined;
    return rol.startsWith('org:') ? rol : `org:${rol}`;
}
//# sourceMappingURL=clerk.service.js.map