export interface ApplicationAuthorityPrincipal {
    tenantId: string;
    actorId: string;
}
export interface ApplicationAuthorityIdentityEvidence {
    principal: ApplicationAuthorityPrincipal;
    identityRevision: string;
    expiresAtMs: number;
}
export interface ApplicationAuthorityIdentityReceipt extends ApplicationAuthorityIdentityEvidence {
    checkedAtMs: number;
}
/** Internal, request-local proof. Its callback is never included in a receipt. */
export interface ApplicationAuthorityIdentityProof extends ApplicationAuthorityIdentityEvidence {
    recheckCurrent(): Promise<ApplicationAuthorityIdentityEvidence>;
}
export interface ApplicationAuthorityContextRequest {
    identitySha256: string;
    conversationId: string;
    clientId: string;
}
export interface ApplicationAuthorityContextReceipt extends ApplicationAuthorityIdentityReceipt {
    identitySha256: string;
    conversationId: string;
    selectedClientId: string;
    contextRevision: string;
}
export declare function assertApplicationAuthorityIdentityBody(body: unknown): void;
export declare function parseApplicationAuthorityContextBody(body: unknown): ApplicationAuthorityContextRequest;
/** Deterministic digest of explicit server-owned facts, never an authority grant. */
export declare function applicationAuthorityRevision(kind: 'identity' | 'context', facts: unknown): string;
export declare function applicationAuthorityIdentityReceipt(evidence: ApplicationAuthorityIdentityEvidence, checkedAtMs?: number): ApplicationAuthorityIdentityReceipt;
export interface ApplicationAuthorityConversation {
    id: string;
    tenantId: string;
    userId: string;
    clientId: string | null;
    status: string;
    archivedAt: Date | null;
}
/** Ports are existing application owners; selectors and the echoed hash grant nothing. */
export declare function readApplicationAuthorityContext(input: ApplicationAuthorityContextRequest, ports: {
    identity(): Promise<ApplicationAuthorityIdentityProof>;
    conversation(id: string): Promise<ApplicationAuthorityConversation>;
    conversationScope(conversation: ApplicationAuthorityConversation): Promise<unknown>;
    clientVisible(id: string): Promise<unknown>;
    clientAuthority(id: string): Promise<unknown>;
}): Promise<ApplicationAuthorityContextReceipt>;
//# sourceMappingURL=application-authority.d.ts.map