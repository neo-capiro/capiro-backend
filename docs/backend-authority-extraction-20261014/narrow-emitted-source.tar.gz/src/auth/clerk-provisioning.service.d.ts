import type { TenantRole } from '@capiro/shared';
import { ClerkService } from './clerk.service.js';
import { PrismaService } from '../prisma/prisma.service.js';
type ProvisionableRole = Extract<TenantRole, 'capiro_admin' | 'user_admin' | 'standard_user'>;
interface ProvisionOrganizationMemberInput {
    tenantId: string;
    organizationId: string;
    email: string;
    role: ProvisionableRole;
    actorUserId?: string;
    actorClerkUserId?: string;
}
export interface ProvisionOrganizationMemberResult {
    clerkUserId: string;
    localUserId: string;
    membershipId: string;
    userCreated: boolean;
    membershipCreated: boolean;
    membershipRoleUpdated: boolean;
}
/**
 * Provisions identity in Clerk first, then mirrors the successful Clerk state
 * into Capiro. The admin UI should never create local-only placeholder users.
 */
export declare class ClerkProvisioningService {
    private readonly clerk;
    private readonly prisma;
    private readonly logger;
    constructor(clerk: ClerkService, prisma: PrismaService);
    provisionOrganizationMember(input: ProvisionOrganizationMemberInput): Promise<ProvisionOrganizationMemberResult>;
    private ensureClerkUser;
    private findClerkUserByEmail;
    private ensureOrganizationMembership;
    private findOrganizationMembership;
    private revokeStalePendingInvitation;
    private syncLocalMembership;
    private mergeUserIdentity;
}
export {};
//# sourceMappingURL=clerk-provisioning.service.d.ts.map