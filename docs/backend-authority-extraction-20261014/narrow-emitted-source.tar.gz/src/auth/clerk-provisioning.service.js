"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var ClerkProvisioningService_1;
Object.defineProperty(exports, "__esModule", { value: true });
exports.ClerkProvisioningService = void 0;
const common_1 = require("@nestjs/common");
const clerk_service_js_1 = require("./clerk.service.js");
const prisma_service_js_1 = require("../prisma/prisma.service.js");
/**
 * Provisions identity in Clerk first, then mirrors the successful Clerk state
 * into Capiro. The admin UI should never create local-only placeholder users.
 */
let ClerkProvisioningService = ClerkProvisioningService_1 = class ClerkProvisioningService {
    constructor(clerk, prisma) {
        this.clerk = clerk;
        this.prisma = prisma;
        this.logger = new common_1.Logger(ClerkProvisioningService_1.name);
    }
    async provisionOrganizationMember(input) {
        const email = normalizeEmail(input.email);
        const clerkRole = toClerkOrganizationRole(input.role);
        const userResult = await this.ensureClerkUser(email);
        const membershipResult = await this.ensureOrganizationMembership(input.organizationId, userResult.user.id, clerkRole);
        await this.revokeStalePendingInvitation(input.organizationId, email, input.actorClerkUserId);
        const synced = await this.syncLocalMembership({
            tenantId: input.tenantId,
            user: userResult.user,
            role: input.role,
            actorUserId: input.actorUserId,
        });
        return {
            clerkUserId: userResult.user.id,
            localUserId: synced.userId,
            membershipId: synced.membershipId,
            userCreated: userResult.created,
            membershipCreated: membershipResult.created,
            membershipRoleUpdated: membershipResult.roleUpdated,
        };
    }
    async ensureClerkUser(email) {
        const existing = await this.findClerkUserByEmail(email);
        if (existing)
            return { user: existing, created: false };
        try {
            const created = await this.clerk.backend.users.createUser({
                emailAddress: [email],
                skipPasswordRequirement: true,
                publicMetadata: { capiro_provisioned: true },
            });
            return { user: created, created: true };
        }
        catch (err) {
            // Covers a concurrent admin action that created the Clerk user after our
            // first lookup. Other Clerk validation errors are allowed to surface.
            const raced = await this.findClerkUserByEmail(email);
            if (raced)
                return { user: raced, created: false };
            throw err;
        }
    }
    async findClerkUserByEmail(email) {
        const users = await this.clerk.backend.users.getUserList({
            emailAddress: [email],
            limit: 10,
        });
        return users.data.find((user) => userEmail(user).toLowerCase() === email);
    }
    async ensureOrganizationMembership(organizationId, userId, role) {
        const existing = await this.findOrganizationMembership(organizationId, userId);
        if (existing) {
            if (existing.role !== role) {
                await this.clerk.backend.organizations.updateOrganizationMembership({
                    organizationId,
                    userId,
                    role,
                });
                return { created: false, roleUpdated: true };
            }
            return { created: false, roleUpdated: false };
        }
        try {
            await this.clerk.backend.organizations.createOrganizationMembership({
                organizationId,
                userId,
                role,
            });
            return { created: true, roleUpdated: false };
        }
        catch (err) {
            // Same race guard as user creation: if Clerk now has the membership,
            // converge it to the requested role and keep the operation idempotent.
            const raced = await this.findOrganizationMembership(organizationId, userId);
            if (!raced)
                throw err;
            if (raced.role !== role) {
                await this.clerk.backend.organizations.updateOrganizationMembership({
                    organizationId,
                    userId,
                    role,
                });
                return { created: false, roleUpdated: true };
            }
            return { created: false, roleUpdated: false };
        }
    }
    async findOrganizationMembership(organizationId, userId) {
        const memberships = await this.clerk.backend.organizations.getOrganizationMembershipList({
            organizationId,
            userId: [userId],
            limit: 10,
        });
        return (memberships.data.find((membership) => membership.publicUserData?.userId === userId) ??
            memberships.data[0]);
    }
    async revokeStalePendingInvitation(organizationId, email, requestingUserId) {
        const pending = await this.clerk.backend.organizations.getOrganizationInvitationList({
            organizationId,
            status: ['pending'],
            limit: 100,
        });
        const stale = pending.data.find((inv) => inv.emailAddress.toLowerCase() === email);
        if (!stale)
            return;
        await this.clerk.backend.organizations
            .revokeOrganizationInvitation({
            organizationId,
            invitationId: stale.id,
            requestingUserId,
        })
            .catch((err) => {
            this.logger.warn(`Unable to revoke stale Clerk invitation ${stale.id}: ${errorMessage(err)}`);
        });
    }
    async syncLocalMembership(input) {
        const email = userEmail(input.user);
        if (!email) {
            throw new common_1.BadRequestException(`Clerk user ${input.user.id} has no email address`);
        }
        return this.prisma.withSystem(async (tx) => {
            const userData = {
                clerkUserId: input.user.id,
                email,
                firstName: input.user.firstName,
                lastName: input.user.lastName,
            };
            const existingByClerkId = await tx.user.findUnique({
                where: { clerkUserId: input.user.id },
            });
            const existingByEmail = await tx.user.findUnique({ where: { email } });
            if (existingByClerkId && existingByEmail && existingByClerkId.id !== existingByEmail.id) {
                // IDENTITY MERGE — same shape as the webhook path. Recorded, not
                // blocked; see UserIdentityConflict in schema.prisma.
                const membershipCount = await tx.tenantMembership.count({
                    where: { userId: existingByEmail.id },
                });
                await tx.userIdentityConflict.create({
                    data: {
                        kind: 'merge',
                        source: 'clerk_provisioning',
                        email,
                        incomingClerkUserId: input.user.id,
                        existingUserId: existingByEmail.id,
                        previousClerkUserId: existingByEmail.clerkUserId,
                        membershipCount,
                    },
                });
                this.logger.warn(JSON.stringify({
                    security_event: 'identity.merge',
                    source: 'clerk_provisioning',
                    email,
                    incoming_clerk_user_id: input.user.id,
                    previous_clerk_user_id: existingByEmail.clerkUserId,
                    membership_count: membershipCount,
                    count: 1,
                }));
                await this.mergeUserIdentity(tx, existingByClerkId.id, existingByEmail.id);
            }
            const existingUser = existingByEmail ?? existingByClerkId;
            const user = existingUser
                ? await tx.user.update({ where: { id: existingUser.id }, data: userData })
                : await tx.user.create({ data: userData });
            const existingMembership = await tx.tenantMembership.findUnique({
                where: { tenantId_userId: { tenantId: input.tenantId, userId: user.id } },
            });
            const joinedAt = existingMembership?.joinedAt ?? new Date();
            const membership = existingMembership
                ? await tx.tenantMembership.update({
                    where: { id: existingMembership.id },
                    data: {
                        role: input.role,
                        status: 'active',
                        joinedAt,
                        invitedBy: input.actorUserId ?? existingMembership.invitedBy,
                    },
                })
                : await tx.tenantMembership.create({
                    data: {
                        tenantId: input.tenantId,
                        userId: user.id,
                        role: input.role,
                        status: 'active',
                        joinedAt,
                        invitedBy: input.actorUserId,
                    },
                });
            return { userId: user.id, membershipId: membership.id };
        });
    }
    async mergeUserIdentity(tx, sourceUserId, targetUserId) {
        const sourceMemberships = await tx.tenantMembership.findMany({
            where: { userId: sourceUserId },
        });
        for (const source of sourceMemberships) {
            const target = await tx.tenantMembership.findUnique({
                where: { tenantId_userId: { tenantId: source.tenantId, userId: targetUserId } },
            });
            if (!target) {
                await tx.tenantMembership.update({
                    where: { id: source.id },
                    data: { userId: targetUserId },
                });
                continue;
            }
            if (source.status === 'active' && target.status !== 'active') {
                await tx.tenantMembership.update({
                    where: { id: target.id },
                    data: {
                        role: source.role,
                        status: 'active',
                        joinedAt: source.joinedAt ?? target.joinedAt ?? new Date(),
                        invitedBy: source.invitedBy ?? target.invitedBy,
                    },
                });
            }
            await tx.tenantMembership.update({
                where: { id: source.id },
                data: { status: 'removed' },
            });
        }
        await tx.user.update({
            where: { id: sourceUserId },
            data: {
                clerkUserId: `duplicate:${sourceUserId}:${Date.now()}`,
                email: `duplicate+${sourceUserId}@deleted.capiro.local`,
            },
        });
    }
};
exports.ClerkProvisioningService = ClerkProvisioningService;
exports.ClerkProvisioningService = ClerkProvisioningService = ClerkProvisioningService_1 = __decorate([
    (0, common_1.Injectable)(),
    __metadata("design:paramtypes", [clerk_service_js_1.ClerkService,
        prisma_service_js_1.PrismaService])
], ClerkProvisioningService);
function normalizeEmail(email) {
    const normalized = email.trim().toLowerCase();
    if (!normalized) {
        throw new common_1.BadRequestException('Email is required');
    }
    return normalized;
}
function toClerkOrganizationRole(role) {
    return (role === 'standard_user' ? 'org:member' : 'org:admin');
}
function userEmail(user) {
    return user.primaryEmailAddress?.emailAddress ?? user.emailAddresses[0]?.emailAddress ?? '';
}
function errorMessage(err) {
    return err instanceof Error ? err.message : String(err);
}
//# sourceMappingURL=clerk-provisioning.service.js.map