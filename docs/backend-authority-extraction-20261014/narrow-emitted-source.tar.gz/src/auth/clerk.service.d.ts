import { ConfigService } from '@nestjs/config';
import { type ClerkClient } from '@clerk/backend';
import type { AppConfig } from '../config/config.schema.js';
export interface ClerkSessionClaims {
    sub: string;
    iss: string;
    sid?: string;
    exp?: number;
    email?: string;
    org_id?: string;
    org_slug?: string;
    org_role?: string;
    capiro_tenant_id?: string;
    capiro_tenant_slug?: string;
    capiro_org_role?: string;
}
export interface ActiveApplicationAuthoritySession {
    id: string;
    userId: string;
    status: 'active';
    createdAt: number;
    expireAt: number;
    abandonAt: number;
    actor: Record<string, unknown> | null;
    expiresAtMs: number;
}
/**
 * Thin wrapper around @clerk/backend. Centralizes JWT verification and
 * Backend API access so the rest of the codebase never imports Clerk
 * directly.
 */
export declare class ClerkService {
    private readonly logger;
    private readonly client;
    private readonly secretKey;
    private readonly issuer;
    constructor(config: ConfigService<AppConfig, true>);
    get backend(): ClerkClient;
    /**
     * Verify a Clerk session JWT. Returns the claims if valid, throws otherwise.
     * Uses Clerk's JWKS (cached by the SDK).
     */
    verifySessionToken(token: string): Promise<ClerkSessionClaims>;
    /** Read-only online session check for application receipts. Never mints tokens.
     * The SDK has no per-getSession AbortSignal. This deadline bounds caller
     * refusal; late SDK settlement is consumed and cannot produce a receipt. */
    assertActiveApplicationAuthoritySession(claims: ClerkSessionClaims): Promise<ActiveApplicationAuthoritySession>;
    private assertIssuer;
}
//# sourceMappingURL=clerk.service.d.ts.map