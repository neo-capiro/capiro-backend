import type { Request } from 'express';
import type { TenantContext } from '@capiro/shared';
import { PrismaService } from '../prisma/prisma.service.js';
import { TenantContextMiddleware } from '../tenant/tenant-context.middleware.js';
import { ContextSecurityScopeService } from '../context/context-security-scope.service.js';
import { BizDevMeriScopeService } from '../business-development/bizdev-meri-scope.service.js';
/** Native authority adapter for rebuilt Meri; no model/runtime/store owner. */
export declare class ApplicationAuthorityController {
    private readonly prisma;
    private readonly tenant;
    private readonly securityScope;
    private readonly bizdevScope;
    constructor(prisma: PrismaService, tenant: TenantContextMiddleware, securityScope: ContextSecurityScopeService, bizdevScope: BizDevMeriScopeService);
    applicationAuthorityIdentity(ctx: TenantContext, req: Request, body: unknown): Promise<import("./application-authority.js").ApplicationAuthorityIdentityReceipt>;
    applicationAuthorityContext(ctx: TenantContext, req: Request, body: unknown): Promise<import("./application-authority.js").ApplicationAuthorityContextReceipt>;
}
//# sourceMappingURL=application-authority.controller.d.ts.map