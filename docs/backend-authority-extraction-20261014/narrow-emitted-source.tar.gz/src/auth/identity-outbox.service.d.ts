import type { Prisma } from '@prisma/client';
import { ClerkService } from './clerk.service.js';
import { PrismaService } from '../prisma/prisma.service.js';
export declare const CLERK_MEMBERSHIP_DELETE = "clerk.membership.delete";
interface ClerkMembershipDeletePayload {
    clerkOrgId: string;
    clerkUserId: string;
    membershipId: string;
}
/**
 * Durable de-provisioning.
 *
 * Previously removeMember flipped the local membership to 'removed' and called
 * Clerk's deleteOrganizationMembership INSIDE the same Prisma interactive
 * transaction, swallowing failures. Two distinct bugs:
 *
 *   1. A fast Clerk error was swallowed -> HTTP 200 {ok:true} while the user
 *      remained in the Clerk org, still receiving org-bearing tokens. Nothing
 *      recorded that the mirror had diverged.
 *   2. A SLOW Clerk call (>5s, the interactive-transaction default) blew the
 *      transaction budget: the .catch swallowed the SDK error but $transaction
 *      still aborted with P2028, so the status='removed' write AND the audit row
 *      rolled back and the caller got a 500 having removed nothing. It also held
 *      a Prisma pool connection open across an external HTTPS call — the same
 *      shape as the 2026-07-21 graph-sync pool-starvation incident.
 *
 * Now: enqueue() runs inside the caller's transaction (atomic with the local
 * state change), and every Clerk call happens strictly OUTSIDE any transaction.
 */
export declare class IdentityOutboxService {
    private readonly prisma;
    private readonly clerk;
    private readonly logger;
    constructor(prisma: PrismaService, clerk: ClerkService);
    /**
     * Enqueue a Clerk membership deletion. MUST be called with the caller's
     * transaction client so the job commits atomically with the local removal.
     *
     * Idempotent: a partial unique index on (type, payload->>'membershipId')
     * WHERE consumed_at IS NULL means a retried removeMember cannot create a
     * second pending job for the same membership. Returns the job id, or null
     * when one was already pending.
     */
    enqueueClerkMembershipDelete(tx: Prisma.TransactionClient, input: {
        tenantId: string;
    } & ClerkMembershipDeletePayload): Promise<string | null>;
    /**
     * Best-effort immediate attempt, for the common case where Clerk is healthy.
     *
     * Call AFTER the enclosing transaction has committed. Never throws: a failure
     * simply leaves the job pending for the drain. This keeps removal
     * user-visibly instant without putting the network call back inside a
     * transaction.
     */
    attemptNow(jobId: string): Promise<boolean>;
    /**
     * Drain pending jobs. Invoked out-of-band (entrypoint verb
     * `drain-identity-outbox`), NOT from an in-process scheduler — apps/api has
     * no scheduler, and running one in a multi-task service would have every task
     * draining the same rows.
     */
    drainPending(limit?: number): Promise<{
        processed: number;
        succeeded: number;
    }>;
    /**
     * Claim one job, perform its Clerk call, and record the outcome.
     *
     * The claim is an atomic conditional UPDATE, so two concurrent drains cannot
     * both process the same row. The Clerk call itself runs OUTSIDE any
     * transaction — that is the whole point of this class.
     */
    private processJob;
    private markConsumed;
    private markFailed;
}
export {};
//# sourceMappingURL=identity-outbox.service.d.ts.map