"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.RolesGuard = void 0;
const common_1 = require("@nestjs/common");
const core_1 = require("@nestjs/core");
const shared_1 = require("@capiro/shared");
const roles_decorator_js_1 = require("./roles.decorator.js");
/**
 * Enforces a minimum role for the route. The required roles come from the
 * @Roles() decorator on the handler or controller. Access is granted if the
 * caller's role rank >= the lowest-ranked required role.
 *
 * The TenantContext is set by TenantContextMiddleware. If it's missing the
 * route was reached without auth, fail closed.
 */
let RolesGuard = class RolesGuard {
    constructor(reflector) {
        this.reflector = reflector;
    }
    canActivate(context) {
        const required = this.reflector.getAllAndOverride(roles_decorator_js_1.ROLES_KEY, [
            context.getHandler(),
            context.getClass(),
        ]);
        if (!required || required.length === 0) {
            return true;
        }
        const req = context.switchToHttp().getRequest();
        const ctx = req.tenantContext;
        if (!ctx) {
            throw new common_1.ForbiddenException('No tenant context, auth middleware did not run');
        }
        // Fail CLOSED on a role that is not in the rank table.
        //
        // `ctx.role` is typed TenantRole but arrives from the database via an
        // `as TenantRole` cast in TenantContextMiddleware, so the type is a promise
        // the runtime does not keep: a row holding a legacy or hand-edited value
        // yields `ROLE_RANK[ctx.role] === undefined`, and because
        // `undefined < anyNumber` is FALSE, the comparison below silently GRANTED
        // access to every @Roles()-gated route. Reject explicitly instead.
        const callerRank = shared_1.ROLE_RANK[ctx.role];
        if (typeof callerRank !== 'number') {
            throw new common_1.ForbiddenException(`Unrecognized role ${String(ctx.role)}`);
        }
        // Same hazard on the required side: an unmapped entry would make
        // Math.min(...) return NaN, and every comparison against NaN is false.
        const requiredRanks = required.map((r) => shared_1.ROLE_RANK[r]);
        if (requiredRanks.some((rank) => typeof rank !== 'number')) {
            throw new common_1.ForbiddenException(`Route declares an unrecognized required role (${required.join(' | ')})`);
        }
        const minRequiredRank = Math.min(...requiredRanks);
        if (callerRank < minRequiredRank) {
            throw new common_1.ForbiddenException(`Role ${ctx.role} is below the required minimum (${required.join(' | ')})`);
        }
        return true;
    }
};
exports.RolesGuard = RolesGuard;
exports.RolesGuard = RolesGuard = __decorate([
    (0, common_1.Injectable)(),
    __metadata("design:paramtypes", [core_1.Reflector])
], RolesGuard);
//# sourceMappingURL=roles.guard.js.map