"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.Roles = exports.ROLES_KEY = void 0;
const common_1 = require("@nestjs/common");
/**
 * Marks a controller / handler with the minimum role required to access it.
 * Read by RolesGuard. Order in the array doesn't imply rank, it's a
 * whitelist; RolesGuard checks role-rank against the lowest-ranked entry.
 */
exports.ROLES_KEY = 'capiro:roles';
const Roles = (...roles) => (0, common_1.SetMetadata)(exports.ROLES_KEY, roles);
exports.Roles = Roles;
//# sourceMappingURL=roles.decorator.js.map