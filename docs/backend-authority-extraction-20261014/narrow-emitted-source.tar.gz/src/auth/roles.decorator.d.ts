import type { TenantRole } from '@capiro/shared';
/**
 * Marks a controller / handler with the minimum role required to access it.
 * Read by RolesGuard. Order in the array doesn't imply rank, it's a
 * whitelist; RolesGuard checks role-rank against the lowest-ranked entry.
 */
export declare const ROLES_KEY = "capiro:roles";
export declare const Roles: (...roles: TenantRole[]) => import("@nestjs/common").CustomDecorator<string>;
//# sourceMappingURL=roles.decorator.d.ts.map