/**
 * Global authentication/authorization services. InternalServiceGuard is
 * exported so backend-only controllers in Context Plane, Workspace, Intel and
 * other feature modules resolve the same fail-closed shared-secret guard rather
 * than relying on implicit class construction.
 */
export declare class AuthModule {
}
//# sourceMappingURL=auth.module.d.ts.map