"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.ApplicationAuthorityModule = void 0;
const common_1 = require("@nestjs/common");
const prisma_module_js_1 = require("../prisma/prisma.module.js");
const tenant_module_js_1 = require("../tenant/tenant.module.js");
const context_security_scope_module_js_1 = require("../context/context-security-scope.module.js");
const bizdev_meri_scope_module_js_1 = require("../business-development/bizdev-meri-scope.module.js");
const auth_module_js_1 = require("./auth.module.js");
const application_authority_controller_js_1 = require("./application-authority.controller.js");
let ApplicationAuthorityModule = class ApplicationAuthorityModule {
};
exports.ApplicationAuthorityModule = ApplicationAuthorityModule;
exports.ApplicationAuthorityModule = ApplicationAuthorityModule = __decorate([
    (0, common_1.Module)({
        imports: [auth_module_js_1.AuthModule, tenant_module_js_1.TenantModule, prisma_module_js_1.PrismaModule, context_security_scope_module_js_1.ContextSecurityScopeModule, bizdev_meri_scope_module_js_1.BizDevMeriScopeModule],
        controllers: [application_authority_controller_js_1.ApplicationAuthorityController],
    })
], ApplicationAuthorityModule);
//# sourceMappingURL=application-authority.module.js.map