"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.KNOWLEDGE_CONFLICT_STATUSES = exports.KNOWLEDGE_ASSERTION_STATUSES = exports.KNOWLEDGE_AUTHORITIES = exports.KNOWLEDGE_ASSERTION_CLASSES = exports.KNOWLEDGE_EVENT_STATUSES = exports.DISALLOWED_KNOWLEDGE_FACTUAL_SOURCE_TYPES = void 0;
exports.DISALLOWED_KNOWLEDGE_FACTUAL_SOURCE_TYPES = [
    'assistant_answer',
    'llm_output',
    'meri_answer',
    'model_answer',
    'model_output',
];
exports.KNOWLEDGE_EVENT_STATUSES = ['active', 'withdrawn'];
exports.KNOWLEDGE_ASSERTION_CLASSES = [
    'fact',
    'preference',
    'decision',
    'commitment',
    'position',
    'goal',
    'constraint',
    'relationship',
    'expertise',
    'influence',
    'risk',
    'strategy',
];
exports.KNOWLEDGE_AUTHORITIES = [
    'model_inferred',
    'source_reported',
    'human_confirmed',
    'system_canonical',
];
exports.KNOWLEDGE_ASSERTION_STATUSES = ['active', 'withdrawn'];
exports.KNOWLEDGE_CONFLICT_STATUSES = [
    'none',
    'potential',
    'confirmed',
    'resolved',
];
//# sourceMappingURL=knowledge.types.js.map