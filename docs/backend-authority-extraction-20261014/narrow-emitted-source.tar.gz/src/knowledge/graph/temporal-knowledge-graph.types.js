"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
//# sourceMappingURL=temporal-knowledge-graph.types.js.map