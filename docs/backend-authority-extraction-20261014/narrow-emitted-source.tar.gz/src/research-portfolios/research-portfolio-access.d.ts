import type { ResearchPortfolioGrantRole, TenantContext } from '@capiro/shared';
type Tx = any;
type RequiredRole = ResearchPortfolioGrantRole;
export declare function loadAuthorizedResearchPortfolio(tx: Tx, ctx: TenantContext, portfolioId: string, requiredRole?: RequiredRole): Promise<any>;
/**
 * Recheck the client memory wall when an operation targets client-private
 * material. Public portfolio projections stay usable when an unrelated linked
 * client is later revoked; filing to a client remains fail closed.
 */
export declare function assertResearchPortfolioClientAccess(tx: Tx, ctx: TenantContext, clientIds: readonly string[]): Promise<void>;
export {};
//# sourceMappingURL=research-portfolio-access.d.ts.map