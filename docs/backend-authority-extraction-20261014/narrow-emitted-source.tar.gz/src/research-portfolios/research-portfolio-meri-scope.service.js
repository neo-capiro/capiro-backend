"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.ResearchPortfolioMeriScopeService = exports.MERI_RESEARCH_PORTFOLIO_SCOPE_METADATA_KEY = void 0;
exports.readMeriResearchPortfolioScope = readMeriResearchPortfolioScope;
exports.authorizeMeriResearchPortfolioScope = authorizeMeriResearchPortfolioScope;
exports.researchPortfolioScopeDirective = researchPortfolioScopeDirective;
exports.researchPortfolioTurnScopeReceipt = researchPortfolioTurnScopeReceipt;
const node_crypto_1 = require("node:crypto");
const common_1 = require("@nestjs/common");
const prisma_service_js_1 = require("../prisma/prisma.service.js");
const research_portfolio_access_js_1 = require("./research-portfolio-access.js");
exports.MERI_RESEARCH_PORTFOLIO_SCOPE_METADATA_KEY = 'researchPortfolioScope';
const object = (value) => value && typeof value === 'object' && !Array.isArray(value)
    ? value
    : null;
function readMeriResearchPortfolioScope(value) {
    const row = object(value);
    if (row?.kind !== 'research_portfolio' ||
        typeof row.researchPortfolioId !== 'string' ||
        !row.researchPortfolioId ||
        typeof row.researchPortfolioName !== 'string' ||
        !row.researchPortfolioName.trim() ||
        !Number.isInteger(row.researchPortfolioRevision) ||
        row.researchPortfolioRevision < 0 ||
        typeof row.scopeVersion !== 'string' ||
        !/^[0-9a-f]{64}$/.test(row.scopeVersion))
        return null;
    return {
        kind: 'research_portfolio',
        researchPortfolioId: row.researchPortfolioId,
        researchPortfolioName: row.researchPortfolioName.trim(),
        researchPortfolioRevision: row.researchPortfolioRevision,
        scopeVersion: row.scopeVersion,
        currentResearchPortfolioName: typeof row.currentResearchPortfolioName === 'string' &&
            row.currentResearchPortfolioName.trim()
            ? row.currentResearchPortfolioName.trim()
            : row.researchPortfolioName.trim(),
        currentResearchPortfolioRevision: Number.isInteger(row.currentResearchPortfolioRevision) &&
            row.currentResearchPortfolioRevision >= 0
            ? row.currentResearchPortfolioRevision
            : row.researchPortfolioRevision,
        stale: row.stale === true,
    };
}
let ResearchPortfolioMeriScopeService = class ResearchPortfolioMeriScopeService {
    constructor(prisma) {
        this.prisma = prisma;
    }
    async resolve(ctx, portfolioId) {
        return this.prisma.withTenant(ctx.tenantId, async (tx) => {
            const row = await (0, research_portfolio_access_js_1.loadAuthorizedResearchPortfolio)(tx, ctx, portfolioId, 'viewer');
            const bounded = {
                kind: 'research_portfolio',
                researchPortfolioId: row.id,
                researchPortfolioName: row.name,
                researchPortfolioRevision: row.revision,
            };
            return {
                ...bounded,
                scopeVersion: (0, node_crypto_1.createHash)('sha256').update(JSON.stringify(bounded)).digest('hex'),
                currentResearchPortfolioName: row.name,
                currentResearchPortfolioRevision: row.revision,
                stale: false,
            };
        });
    }
    async authorize(ctx, stored) {
        const current = await this.resolve(ctx, stored.researchPortfolioId);
        // The immutable receipt identifies what the user launched. Current access
        // is rechecked above; later portfolio revisions do not silently rewrite the
        // receipt attached to earlier turns.
        const expected = (0, node_crypto_1.createHash)('sha256')
            .update(JSON.stringify({
            kind: stored.kind,
            researchPortfolioId: stored.researchPortfolioId,
            researchPortfolioName: stored.researchPortfolioName,
            researchPortfolioRevision: stored.researchPortfolioRevision,
        }))
            .digest('hex');
        if (stored.scopeVersion !== expected) {
            throw new common_1.ForbiddenException('Research Portfolio scope receipt is invalid');
        }
        return {
            ...stored,
            currentResearchPortfolioName: current.researchPortfolioName,
            currentResearchPortfolioRevision: current.researchPortfolioRevision,
            stale: current.researchPortfolioRevision !== stored.researchPortfolioRevision ||
                current.researchPortfolioName !== stored.researchPortfolioName,
        };
    }
};
exports.ResearchPortfolioMeriScopeService = ResearchPortfolioMeriScopeService;
exports.ResearchPortfolioMeriScopeService = ResearchPortfolioMeriScopeService = __decorate([
    (0, common_1.Injectable)(),
    __metadata("design:paramtypes", [prisma_service_js_1.PrismaService])
], ResearchPortfolioMeriScopeService);
async function authorizeMeriResearchPortfolioScope(service, ctx, metadata) {
    const meta = object(metadata);
    if (!meta || !Object.hasOwn(meta, exports.MERI_RESEARCH_PORTFOLIO_SCOPE_METADATA_KEY))
        return null;
    const stored = readMeriResearchPortfolioScope(meta[exports.MERI_RESEARCH_PORTFOLIO_SCOPE_METADATA_KEY]);
    if (!stored || !service)
        throw new common_1.ForbiddenException('Research Portfolio scope is unavailable');
    return service.authorize(ctx, stored);
}
function researchPortfolioScopeDirective(scope) {
    return [
        'The active scope is one Defense Intelligence Research Portfolio.',
        `Research Portfolio ID: ${scope.researchPortfolioId}`,
        `Name: ${scope.researchPortfolioName}`,
        `Captured revision: ${scope.researchPortfolioRevision}`,
        `Current revision: ${scope.currentResearchPortfolioRevision}`,
        `Context freshness: ${scope.stale ? 'stale — use current reads before relying on captured values' : 'current'}`,
        `Scope receipt: ${scope.scopeVersion}`,
        'Research Portfolio tools are server-bound to this conversation receipt. Never switch portfolio authority from model input, and do not reinterpret ordinary portfolio scope (all firm clients) as this research portfolio.',
    ].join('\n');
}
function researchPortfolioTurnScopeReceipt(scope) {
    return {
        kind: 'research_portfolio',
        clientId: null,
        clientName: null,
        targetHint: null,
        researchPortfolioId: scope.researchPortfolioId,
        researchPortfolioName: scope.researchPortfolioName,
        researchPortfolioRevision: scope.researchPortfolioRevision,
        currentResearchPortfolioRevision: scope.currentResearchPortfolioRevision,
        stale: scope.stale,
        scopeVersion: scope.scopeVersion,
    };
}
//# sourceMappingURL=research-portfolio-meri-scope.service.js.map