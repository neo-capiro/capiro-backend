import type { TenantContext } from '@capiro/shared';
export declare const RESEARCH_PORTFOLIO_ARTIFACT_KINDS: readonly ["research_portfolio_brief", "research_portfolio_meeting"];
export declare function isResearchPortfolioArtifact(kind: string): boolean;
/** Ordinary conversations retain existing behavior. RP conversations recheck
 * current active membership and current grant even for archived transcript reads. */
export declare function authorizeResearchPortfolioConversation(tx: any, ctx: TenantContext, conversation: any): Promise<import("./research-portfolio-meri-scope.service.js").MeriResearchPortfolioScope | null>;
/** Immutable original and current conversation receipts are independently valid.
 * A later receipt for the same RP permits editing the original captured draft;
 * switching the conversation to another RP never transfers that authority. */
export declare function authorizeResearchPortfolioArtifact(tx: any, ctx: TenantContext, artifact: any): Promise<{
    scope: import("./research-portfolio-meri-scope.service.js").MeriResearchPortfolioScope;
    metadata: any;
}>;
//# sourceMappingURL=research-portfolio-artifact-authority.d.ts.map