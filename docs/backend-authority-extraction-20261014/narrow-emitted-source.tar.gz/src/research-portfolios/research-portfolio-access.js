"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.loadAuthorizedResearchPortfolio = loadAuthorizedResearchPortfolio;
exports.assertResearchPortfolioClientAccess = assertResearchPortfolioClientAccess;
const common_1 = require("@nestjs/common");
const memory_wall_helpers_js_1 = require("../memory/memory-wall.helpers.js");
const ROLE_LEVEL = {
    viewer: 1,
    editor: 2,
    owner: 3,
};
async function loadAuthorizedResearchPortfolio(tx, ctx, portfolioId, requiredRole = 'viewer') {
    const row = await tx.researchPortfolio.findFirst({
        where: {
            id: portfolioId,
            tenantId: ctx.tenantId,
            grants: { some: { principalUserId: ctx.userId } },
        },
        include: {
            grants: { where: { principalUserId: ctx.userId }, select: { role: true }, take: 1 },
            clientLinks: { select: { clientId: true } },
        },
    });
    if (!row || !row.grants[0])
        throw new common_1.NotFoundException('Research portfolio not found');
    const role = row.grants[0].role;
    if (ROLE_LEVEL[role] < ROLE_LEVEL[requiredRole]) {
        throw new common_1.ForbiddenException(`Research portfolio ${requiredRole} access required`);
    }
    return { ...row, myRole: role };
}
/**
 * Recheck the client memory wall when an operation targets client-private
 * material. Public portfolio projections stay usable when an unrelated linked
 * client is later revoked; filing to a client remains fail closed.
 */
async function assertResearchPortfolioClientAccess(tx, ctx, clientIds) {
    for (const clientId of clientIds) {
        if (!(await (0, memory_wall_helpers_js_1.clientMemoryAllowed)(tx, ctx.tenantId, ctx.userId, clientId))) {
            throw new common_1.NotFoundException('Research portfolio output is no longer available');
        }
    }
}
//# sourceMappingURL=research-portfolio-access.js.map