import type { Prisma } from '@prisma/client';
import type { TenantContext } from '@capiro/shared';
import { PrismaService } from '../prisma/prisma.service.js';
export declare const MERI_RESEARCH_PORTFOLIO_SCOPE_METADATA_KEY = "researchPortfolioScope";
export interface MeriResearchPortfolioScope {
    kind: 'research_portfolio';
    researchPortfolioId: string;
    researchPortfolioName: string;
    researchPortfolioRevision: number;
    scopeVersion: string;
    currentResearchPortfolioName: string;
    currentResearchPortfolioRevision: number;
    stale: boolean;
}
export declare function readMeriResearchPortfolioScope(value: unknown): MeriResearchPortfolioScope | null;
export declare class ResearchPortfolioMeriScopeService {
    private readonly prisma;
    constructor(prisma: PrismaService);
    resolve(ctx: TenantContext, portfolioId: string): Promise<MeriResearchPortfolioScope>;
    authorize(ctx: TenantContext, stored: MeriResearchPortfolioScope): Promise<MeriResearchPortfolioScope>;
}
export declare function authorizeMeriResearchPortfolioScope(service: ResearchPortfolioMeriScopeService | undefined, ctx: TenantContext, metadata: Prisma.JsonValue | null | undefined): Promise<MeriResearchPortfolioScope | null>;
export declare function researchPortfolioScopeDirective(scope: MeriResearchPortfolioScope): string;
export declare function researchPortfolioTurnScopeReceipt(scope: MeriResearchPortfolioScope): {
    kind: "research_portfolio";
    clientId: null;
    clientName: null;
    targetHint: null;
    researchPortfolioId: string;
    researchPortfolioName: string;
    researchPortfolioRevision: number;
    currentResearchPortfolioRevision: number;
    stale: boolean;
    scopeVersion: string;
};
//# sourceMappingURL=research-portfolio-meri-scope.service.d.ts.map