"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.loadOwnedActiveClioConversation = loadOwnedActiveClioConversation;
exports.assertCurrentClientVisible = assertCurrentClientVisible;
const common_1 = require("@nestjs/common");
const research_portfolio_artifact_authority_js_1 = require("../research-portfolios/research-portfolio-artifact-authority.js");
/** Shared current resource reads; ordinary legacy callers retain their 404s. */
async function loadOwnedActiveClioConversation(prisma, ctx, conversationId) {
    const conversation = await prisma.withTenant(ctx.tenantId, async (tx) => {
        const row = await tx.clioConversation.findFirst({
            where: {
                id: conversationId,
                tenantId: ctx.tenantId,
                userId: ctx.userId,
                archivedAt: null,
            },
            include: { client: { select: { id: true, name: true } } },
        });
        if (row)
            await (0, research_portfolio_artifact_authority_js_1.authorizeResearchPortfolioConversation)(tx, ctx, row);
        return row;
    });
    if (!conversation)
        throw new common_1.NotFoundException('Meri conversation not found');
    return conversation;
}
async function assertCurrentClientVisible(prisma, ctx, clientId) {
    const client = await prisma.withTenant(ctx.tenantId, (tx) => tx.client.findFirst({
        where: { id: clientId, tenantId: ctx.tenantId, status: { not: 'archived' } },
        select: { id: true },
    }));
    if (!client)
        throw new common_1.NotFoundException('Client not found');
}
//# sourceMappingURL=application-authority-resource.helpers.js.map