"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.ContextSecurityScopeModule = void 0;
const common_1 = require("@nestjs/common");
const prisma_module_js_1 = require("../prisma/prisma.module.js");
const context_security_scope_service_js_1 = require("./context-security-scope.service.js");
/** Current client/wall authority without context compilation or retrieval. */
let ContextSecurityScopeModule = class ContextSecurityScopeModule {
};
exports.ContextSecurityScopeModule = ContextSecurityScopeModule;
exports.ContextSecurityScopeModule = ContextSecurityScopeModule = __decorate([
    (0, common_1.Module)({
        imports: [prisma_module_js_1.PrismaModule],
        providers: [context_security_scope_service_js_1.ContextSecurityScopeService],
        exports: [context_security_scope_service_js_1.ContextSecurityScopeService],
    })
], ContextSecurityScopeModule);
//# sourceMappingURL=context-security-scope.module.js.map