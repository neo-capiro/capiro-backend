"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.ContextSecurityScopeService = void 0;
const common_1 = require("@nestjs/common");
const prisma_service_js_1 = require("../prisma/prisma.service.js");
const context_types_js_1 = require("./context.types.js");
const MAILBOX_PROVIDERS = ['microsoft_365', 'google_workspace', 'imap_caldav'];
/**
 * Establishes what the actor is allowed to see before subject interpretation or
 * retrieval. Caller lists are optional upper bounds, never authorization grants.
 * Client ethical walls and mailbox ownership are rechecked in the tenant DB.
 */
let ContextSecurityScopeService = class ContextSecurityScopeService {
    constructor(prisma) {
        this.prisma = prisma;
    }
    /** Minimal current client/wall facts for a selected-client application receipt.
     * Uses this owner's existing client resolver; requested IDs never grant access.
     * Facts are hashed by the caller, not returned as a roster or profile. */
    async resolveApplicationAuthorityClient(tenantId, actorUserId, clientId) {
        return this.prisma.withTenant(tenantId, async (tx) => {
            await this.resolveClients(tx, tenantId, actorUserId, [clientId], true);
            const client = await tx.client.findFirst({
                where: { id: clientId, tenantId, status: { not: 'archived' } },
                select: {
                    id: true, tenantId: true, status: true, memoryWall: true,
                    memoryAccessGrants: {
                        where: { tenantId, clientId, userId: actorUserId },
                        select: { id: true, tenantId: true, clientId: true, userId: true, createdAt: true },
                        orderBy: { id: 'asc' },
                    },
                },
            });
            if (!client || client.id !== clientId || client.tenantId !== tenantId || client.status === 'archived') {
                throw new common_1.ForbiddenException('Application authority unavailable');
            }
            // Recheck through the canonical predicate after the fact read as well.
            await this.resolveClients(tx, tenantId, actorUserId, [clientId], true);
            return [client.id, client.tenantId, client.status, client.memoryWall,
                client.memoryAccessGrants.map((grant) => [grant.id, grant.tenantId, grant.clientId, grant.userId, grant.createdAt.getTime()])];
        });
    }
    async resolve(input) {
        const tenantId = requiredId(input.tenantId, 'tenantId');
        const actorUserId = requiredId(input.actorUserId, 'actorUserId');
        const requestedClientIds = normalizeIds(input.securityScope.authorizedClientIds);
        const requestedMailboxIds = normalizeIds(input.securityScope.authorizedMailboxConnectionIds);
        const clientConstraintProvided = input.securityScope.authorizedClientIds !== undefined;
        const mailboxConstraintProvided = input.securityScope.authorizedMailboxConnectionIds !== undefined;
        return this.prisma.withTenant(tenantId, async (tx) => {
            const authorizedClientIds = await this.resolveClients(tx, tenantId, actorUserId, requestedClientIds, clientConstraintProvided);
            const authorizedMailboxConnectionIds = await this.resolveMailboxes(tx, actorUserId, requestedMailboxIds, mailboxConstraintProvided);
            const allowGlobalPublic = input.securityScope.allowGlobalPublic === true;
            return {
                tenantId,
                actorUserId,
                authorizedClientIds,
                authorizedMailboxConnectionIds,
                graphPartitions: dedupeGraphPartitions(input.securityScope.graphPartitions ?? []),
                allowGlobalPublic,
                allowExternalResearch: allowGlobalPublic && input.securityScope.allowExternalResearch === true,
            };
        });
    }
    async resolveClients(tx, tenantId, actorUserId, requestedIds, constraintProvided) {
        if (constraintProvided && requestedIds.length === 0)
            return [];
        const rows = await tx.client.findMany({
            where: {
                tenantId,
                ...(constraintProvided ? { id: { in: requestedIds } } : {}),
                OR: [{ memoryWall: false }, { memoryAccessGrants: { some: { tenantId, userId: actorUserId } } }],
            },
            select: { id: true },
            orderBy: { id: 'asc' },
        });
        const resolved = rows.map((row) => row.id);
        if (constraintProvided && resolved.length !== requestedIds.length) {
            throw new context_types_js_1.ContextResolutionError('requested_client_scope_not_fully_authorized', 'Requested client security scope is not fully authorized.', { requestedCount: requestedIds.length, authorizedCount: resolved.length });
        }
        return resolved;
    }
    async resolveMailboxes(tx, actorUserId, requestedIds, constraintProvided) {
        if (constraintProvided && requestedIds.length === 0)
            return [];
        const rows = await tx.integrationConnection.findMany({
            where: {
                createdByUserId: actorUserId,
                provider: { in: [...MAILBOX_PROVIDERS] },
                ...(constraintProvided ? { id: { in: requestedIds } } : {}),
            },
            select: { id: true },
            orderBy: { id: 'asc' },
        });
        const resolved = rows.map((row) => row.id);
        if (constraintProvided && resolved.length !== requestedIds.length) {
            throw new context_types_js_1.ContextResolutionError('requested_mailbox_scope_not_fully_authorized', 'Requested mailbox security scope is not fully authorized.', { requestedCount: requestedIds.length, authorizedCount: resolved.length });
        }
        return resolved;
    }
};
exports.ContextSecurityScopeService = ContextSecurityScopeService;
exports.ContextSecurityScopeService = ContextSecurityScopeService = __decorate([
    (0, common_1.Injectable)(),
    __metadata("design:paramtypes", [prisma_service_js_1.PrismaService])
], ContextSecurityScopeService);
function requiredId(value, field) {
    const normalized = value.trim();
    if (!normalized) {
        throw new context_types_js_1.ContextResolutionError('invalid_context_request', `${field} is required.`, { field });
    }
    return normalized;
}
function normalizeIds(values) {
    if (!values)
        return [];
    return [...new Set(values.map((value) => value.trim()).filter(Boolean))].sort();
}
function dedupeGraphPartitions(values) {
    const seen = new Set();
    const out = [];
    for (const value of values) {
        const key = stableJson(value);
        if (seen.has(key))
            continue;
        seen.add(key);
        out.push(value);
    }
    return out;
}
function stableJson(value) {
    if (value === null || typeof value !== 'object')
        return JSON.stringify(value);
    if (Array.isArray(value))
        return `[${value.map(stableJson).join(',')}]`;
    return `{${Object.entries(value)
        .sort(([a], [b]) => a.localeCompare(b))
        .map(([key, child]) => `${JSON.stringify(key)}:${stableJson(child)}`)
        .join(',')}}`;
}
//# sourceMappingURL=context-security-scope.service.js.map