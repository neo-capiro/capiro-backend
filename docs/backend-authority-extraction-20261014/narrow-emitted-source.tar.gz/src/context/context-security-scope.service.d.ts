import { PrismaService } from '../prisma/prisma.service.js';
import { type ContextSecurityScopeInput, type ResolvedContextSecurityScope } from './context.types.js';
export interface ResolveContextSecurityScopeInput {
    tenantId: string;
    actorUserId: string;
    securityScope: ContextSecurityScopeInput;
}
/**
 * Establishes what the actor is allowed to see before subject interpretation or
 * retrieval. Caller lists are optional upper bounds, never authorization grants.
 * Client ethical walls and mailbox ownership are rechecked in the tenant DB.
 */
export declare class ContextSecurityScopeService {
    private readonly prisma;
    constructor(prisma: PrismaService);
    /** Minimal current client/wall facts for a selected-client application receipt.
     * Uses this owner's existing client resolver; requested IDs never grant access.
     * Facts are hashed by the caller, not returned as a roster or profile. */
    resolveApplicationAuthorityClient(tenantId: string, actorUserId: string, clientId: string): Promise<(string | boolean | (string | number)[][])[]>;
    resolve(input: ResolveContextSecurityScopeInput): Promise<ResolvedContextSecurityScope>;
    private resolveClients;
    private resolveMailboxes;
}
//# sourceMappingURL=context-security-scope.service.d.ts.map