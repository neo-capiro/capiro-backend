"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.ContextResolutionError = exports.CONTEXT_SUBJECT_SCOPES = exports.CONTEXT_SURFACES = void 0;
exports.CONTEXT_SURFACES = [
    'meri',
    'workspace',
    'client_profile',
    'portfolio',
    'outreach',
    'legiwatch',
    'program_elements',
    'intelligence',
    'meeting',
    'mailbox',
    'unknown',
];
exports.CONTEXT_SUBJECT_SCOPES = [
    'client',
    'portfolio',
    'external_entity',
    'person',
    'program_element',
    'bill',
    'federal_market_topic',
    'general',
];
class ContextResolutionError extends Error {
    constructor(code, message, details = {}) {
        super(message);
        this.code = code;
        this.details = details;
        this.name = 'ContextResolutionError';
    }
}
exports.ContextResolutionError = ContextResolutionError;
//# sourceMappingURL=context.types.js.map