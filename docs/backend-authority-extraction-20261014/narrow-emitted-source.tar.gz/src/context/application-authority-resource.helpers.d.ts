import type { TenantContext } from '@capiro/shared';
import type { PrismaService } from '../prisma/prisma.service.js';
/** Shared current resource reads; ordinary legacy callers retain their 404s. */
export declare function loadOwnedActiveClioConversation(prisma: PrismaService, ctx: TenantContext, conversationId: string): Promise<{
    client: {
        name: string;
        id: string;
    } | null;
} & {
    tenantId: string;
    id: string;
    status: string;
    createdAt: Date;
    updatedAt: Date;
    metadata: import("@prisma/client/runtime/library").JsonValue;
    title: string;
    userId: string;
    archivedAt: Date | null;
    clientId: string | null;
    summary: string | null;
    workspaceId: string | null;
    workspaceKey: string;
    nanoclawPlatformId: string | null;
    nanoclawAgentGroupId: string | null;
    summaryUpToMessageId: string | null;
    summaryTokens: number | null;
}>;
export declare function assertCurrentClientVisible(prisma: PrismaService, ctx: TenantContext, clientId: string): Promise<void>;
//# sourceMappingURL=application-authority-resource.helpers.d.ts.map