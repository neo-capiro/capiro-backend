/** Current client/wall authority without context compilation or retrieval. */
export declare class ContextSecurityScopeModule {
}
//# sourceMappingURL=context-security-scope.module.d.ts.map