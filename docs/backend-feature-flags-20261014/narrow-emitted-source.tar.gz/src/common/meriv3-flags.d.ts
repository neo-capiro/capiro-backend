export declare const MERIV3_CHAT_FLAG: "meriv3.fullChat";
/** Global kill switch. Unset means on; only an explicit off value disables V3. */
export declare function meriV3EnvironmentEnabled(env?: NodeJS.ProcessEnv): boolean;
/** Per-tenant off switch. Missing or malformed settings mean on. */
export declare function meriV3TenantFlagEnabled(settings: unknown): boolean;
/** Two keys: the global kill switch and the tenant off switch. */
export declare function meriV3ChatActive(settings: unknown, env?: NodeJS.ProcessEnv): boolean;
/** Classified refusal when either key is closed. */
export declare const MERI_UNAVAILABLE_CODE: "meri_unavailable";
export declare const MERI_UNAVAILABLE_MESSAGE = "Meri is unavailable right now.";
//# sourceMappingURL=meriv3-flags.d.ts.map