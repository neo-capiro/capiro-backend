/** One existing tenant-flag cache per Nest application, without agent runtime DI. */
export declare class MeriFeatureFlagsModule {
}
//# sourceMappingURL=meri-feature-flags.module.d.ts.map