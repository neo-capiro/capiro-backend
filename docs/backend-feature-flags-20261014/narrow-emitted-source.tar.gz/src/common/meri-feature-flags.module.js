"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.MeriFeatureFlagsModule = void 0;
const common_1 = require("@nestjs/common");
const prisma_module_js_1 = require("../prisma/prisma.module.js");
const meri_feature_flags_service_js_1 = require("../meri/meri-feature-flags.service.js");
/** One existing tenant-flag cache per Nest application, without agent runtime DI. */
let MeriFeatureFlagsModule = class MeriFeatureFlagsModule {
};
exports.MeriFeatureFlagsModule = MeriFeatureFlagsModule;
exports.MeriFeatureFlagsModule = MeriFeatureFlagsModule = __decorate([
    (0, common_1.Module)({
        imports: [prisma_module_js_1.PrismaModule],
        providers: [meri_feature_flags_service_js_1.MeriFeatureFlagsService],
        exports: [meri_feature_flags_service_js_1.MeriFeatureFlagsService],
    })
], MeriFeatureFlagsModule);
//# sourceMappingURL=meri-feature-flags.module.js.map