/**
 * Native Meri API rollout controls.
 *
 * Mobile is default-closed behind a fleet switch, a canonical tenant-id
 * allowlist, and an explicit tenant flag. Individual capabilities have their
 * own fleet and tenant switches so each surface can be rolled back independently.
 */
export declare const MERI_MOBILE_API_FLAG: "meri.mobileApi";
export declare const MERI_MOBILE_CAPABILITY_FLAGS: {
    readonly runs: "meri.mobile.runs";
    readonly meetings: "meri.mobile.meetings";
    readonly files: "meri.mobile.files";
    readonly deviceTokens: "meri.mobile.deviceTokens";
};
export type MeriMobileCapability = keyof typeof MERI_MOBILE_CAPABILITY_FLAGS;
export declare function meriMobileEnvironmentEnabled(env?: NodeJS.ProcessEnv): boolean;
export declare function meriMobilePilotTenantIds(env?: NodeJS.ProcessEnv): Set<string>;
export declare function meriMobileTenantAllowed(tenantId: string | null | undefined, env?: NodeJS.ProcessEnv): boolean;
export declare function meriMobileCapabilityEnvironmentEnabled(capability: MeriMobileCapability, env?: NodeJS.ProcessEnv): boolean;
//# sourceMappingURL=meri-mobile-flags.d.ts.map