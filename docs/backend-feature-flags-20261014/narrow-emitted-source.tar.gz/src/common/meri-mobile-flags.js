"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.MERI_MOBILE_CAPABILITY_FLAGS = exports.MERI_MOBILE_API_FLAG = void 0;
exports.meriMobileEnvironmentEnabled = meriMobileEnvironmentEnabled;
exports.meriMobilePilotTenantIds = meriMobilePilotTenantIds;
exports.meriMobileTenantAllowed = meriMobileTenantAllowed;
exports.meriMobileCapabilityEnvironmentEnabled = meriMobileCapabilityEnvironmentEnabled;
/**
 * Native Meri API rollout controls.
 *
 * Mobile is default-closed behind a fleet switch, a canonical tenant-id
 * allowlist, and an explicit tenant flag. Individual capabilities have their
 * own fleet and tenant switches so each surface can be rolled back independently.
 */
exports.MERI_MOBILE_API_FLAG = 'meri.mobileApi';
exports.MERI_MOBILE_CAPABILITY_FLAGS = {
    runs: 'meri.mobile.runs',
    meetings: 'meri.mobile.meetings',
    files: 'meri.mobile.files',
    deviceTokens: 'meri.mobile.deviceTokens',
};
const UUID_RE = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;
function meriMobileEnvironmentEnabled(env = process.env) {
    return env.MERI_MOBILE_ENABLED === 'true';
}
function meriMobilePilotTenantIds(env = process.env) {
    return new Set((env.MERI_MOBILE_PILOT_TENANT_IDS ?? '')
        .split(',')
        .map((id) => id.trim().toLowerCase())
        .filter((id) => UUID_RE.test(id)));
}
function meriMobileTenantAllowed(tenantId, env = process.env) {
    if (!meriMobileEnvironmentEnabled(env))
        return false;
    const id = tenantId?.trim().toLowerCase();
    return Boolean(id && UUID_RE.test(id) && meriMobilePilotTenantIds(env).has(id));
}
function meriMobileCapabilityEnvironmentEnabled(capability, env = process.env) {
    const names = {
        runs: 'MERI_MOBILE_RUNS_ENABLED',
        meetings: 'MERI_MOBILE_MEETINGS_ENABLED',
        files: 'MERI_MOBILE_FILES_ENABLED',
        deviceTokens: 'MERI_MOBILE_DEVICE_TOKENS_ENABLED',
    };
    return env[names[capability]] === 'true';
}
//# sourceMappingURL=meri-mobile-flags.js.map