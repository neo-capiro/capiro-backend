"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.MeriFeatureFlagsService = exports.MERI_QUICK_ACTION_SKILLS_FLAG = void 0;
exports.meriQuickActionSkillsEnvironmentEnabled = meriQuickActionSkillsEnvironmentEnabled;
exports.meriQuickActionSkillsTenantSlugs = meriQuickActionSkillsTenantSlugs;
exports.meriQuickActionSkillsTenantEnabled = meriQuickActionSkillsTenantEnabled;
const common_1 = require("@nestjs/common");
const prisma_service_js_1 = require("../prisma/prisma.service.js");
const tenant_flags_js_1 = require("../common/tenant-flags.js");
const meriv3_flags_js_1 = require("../common/meriv3-flags.js");
const meri_mobile_flags_js_1 = require("../common/meri-mobile-flags.js");
const CACHE_TTL_MS = 60_000;
exports.MERI_QUICK_ACTION_SKILLS_FLAG = 'meriv3.quickActionSkills';
function meriQuickActionSkillsEnvironmentEnabled(env = process.env) {
    return env.MERI_QUICK_ACTION_SKILLS_ENABLED === 'true';
}
function meriQuickActionSkillsTenantSlugs(env = process.env) {
    const raw = env.MERI_QUICK_ACTION_SKILLS_TENANTS?.trim() || '*';
    return new Set(raw
        .split(',')
        .map((slug) => slug.trim().toLowerCase())
        .filter(Boolean));
}
function meriQuickActionSkillsTenantEnabled(tenantSlug, cohort) {
    const slug = tenantSlug.trim().toLowerCase();
    return Boolean(slug) && (cohort.has('*') || cohort.has(slug));
}
/**
 * Per-tenant Meri feature flags (settings_jsonb.clioFeatureFlags) with a
 * 60-second cache so flag flips land within a minute and the chat hot path
 * stays cheap. Env kill-switches compose on top of this in each feature's
 * own gate.
 */
let MeriFeatureFlagsService = class MeriFeatureFlagsService {
    constructor(prisma) {
        this.prisma = prisma;
        this.cache = new Map();
    }
    invalidate(tenantId) {
        this.cache.delete(tenantId);
    }
    async isEnabled(tenantId, flag, defaultValue) {
        const cached = this.cache.get(tenantId);
        if (cached && Date.now() - cached.fetchedAt < CACHE_TTL_MS) {
            return (0, tenant_flags_js_1.tenantFeatureEnabled)(cached.settings, flag, defaultValue);
        }
        try {
            const tenant = (await this.prisma.withTenant(tenantId, (tx) => tx.tenant.findFirst({ where: { id: tenantId }, select: { settings: true } })));
            this.cache.set(tenantId, { settings: tenant?.settings ?? {}, fetchedAt: Date.now() });
            return (0, tenant_flags_js_1.tenantFeatureEnabled)(tenant?.settings, flag, defaultValue);
        }
        catch {
            return defaultValue;
        }
    }
    /**
     * MeriV2 surface gate. MeriV2 is fleet-default whenever its env switch is on;
     * an explicit tenant false remains the rollback carve-out.
     */
    async isMeriV2SurfaceEnabled(tenantId, flag) {
        if (!(0, tenant_flags_js_1.meriV2Enabled)())
            return false;
        return this.isEnabled(tenantId, flag, true);
    }
    /**
     * MeriV3 is the only chat runtime. Two keys, both default on: the global
     * MERIV3_ENABLED kill switch and the tenant's meriv3.fullChat off switch.
     * When this returns false the turn is refused as "Meri is unavailable"; it
     * never falls back to another runtime. The browser cannot open this gate.
     */
    async isMeriV3ChatEnabled(tenantId) {
        if (!(0, meriv3_flags_js_1.meriV3EnvironmentEnabled)())
            return false;
        return this.isEnabled(tenantId, meriv3_flags_js_1.MERIV3_CHAT_FLAG, true);
    }
    /** Strict, server-resolved gate for every /mobile/v1 route. */
    async isMeriMobileApiEnabled(tenantId) {
        if (!(0, meri_mobile_flags_js_1.meriMobileTenantAllowed)(tenantId))
            return false;
        return this.isEnabled(tenantId, meri_mobile_flags_js_1.MERI_MOBILE_API_FLAG, false);
    }
    /** Independent mobile capability switch; never grants authorization itself. */
    async isMeriMobileCapabilityEnabled(tenantId, capability) {
        if (!(await this.isMeriMobileApiEnabled(tenantId)))
            return false;
        if (!(0, meri_mobile_flags_js_1.meriMobileCapabilityEnvironmentEnabled)(capability))
            return false;
        return this.isEnabled(tenantId, meri_mobile_flags_js_1.MERI_MOBILE_CAPABILITY_FLAGS[capability], false);
    }
    /**
     * User-facing Quick Actions are independently reversible from the MeriV3
     * runtime. The global environment switch is the emergency off, the cohort
     * defaults fleet-wide, and an explicit allowlist or tenant false remains a
     * rollback carve-out without a deploy.
     */
    async isMeriQuickActionSkillsEnabled(tenantId, tenantSlug) {
        if (!meriQuickActionSkillsEnvironmentEnabled())
            return false;
        if (!meriQuickActionSkillsTenantEnabled(tenantSlug, meriQuickActionSkillsTenantSlugs())) {
            return false;
        }
        const cached = this.cache.get(tenantId);
        if (cached && Date.now() - cached.fetchedAt < CACHE_TTL_MS) {
            return (0, tenant_flags_js_1.tenantFeatureEnabled)(cached.settings, exports.MERI_QUICK_ACTION_SKILLS_FLAG, true);
        }
        try {
            const tenant = (await this.prisma.withTenant(tenantId, (tx) => tx.tenant.findFirst({ where: { id: tenantId }, select: { settings: true } })));
            if (!tenant)
                return false;
            this.cache.set(tenantId, { settings: tenant.settings ?? {}, fetchedAt: Date.now() });
            return (0, tenant_flags_js_1.tenantFeatureEnabled)(tenant.settings, exports.MERI_QUICK_ACTION_SKILLS_FLAG, true);
        }
        catch {
            return false;
        }
    }
};
exports.MeriFeatureFlagsService = MeriFeatureFlagsService;
exports.MeriFeatureFlagsService = MeriFeatureFlagsService = __decorate([
    (0, common_1.Injectable)(),
    __metadata("design:paramtypes", [prisma_service_js_1.PrismaService])
], MeriFeatureFlagsService);
//# sourceMappingURL=meri-feature-flags.service.js.map