import { PrismaService } from '../prisma/prisma.service.js';
import { type MeriV2FlagKey } from '../common/tenant-flags.js';
import { type MeriMobileCapability } from '../common/meri-mobile-flags.js';
export declare const MERI_QUICK_ACTION_SKILLS_FLAG: "meriv3.quickActionSkills";
export declare function meriQuickActionSkillsEnvironmentEnabled(env?: NodeJS.ProcessEnv): boolean;
export declare function meriQuickActionSkillsTenantSlugs(env?: NodeJS.ProcessEnv): Set<string>;
export declare function meriQuickActionSkillsTenantEnabled(tenantSlug: string, cohort: ReadonlySet<string>): boolean;
/**
 * Per-tenant Meri feature flags (settings_jsonb.clioFeatureFlags) with a
 * 60-second cache so flag flips land within a minute and the chat hot path
 * stays cheap. Env kill-switches compose on top of this in each feature's
 * own gate.
 */
export declare class MeriFeatureFlagsService {
    private readonly prisma;
    private readonly cache;
    constructor(prisma: PrismaService);
    invalidate(tenantId: string): void;
    isEnabled(tenantId: string, flag: string, defaultValue: boolean): Promise<boolean>;
    /**
     * MeriV2 surface gate. MeriV2 is fleet-default whenever its env switch is on;
     * an explicit tenant false remains the rollback carve-out.
     */
    isMeriV2SurfaceEnabled(tenantId: string, flag: MeriV2FlagKey): Promise<boolean>;
    /**
     * MeriV3 is the only chat runtime. Two keys, both default on: the global
     * MERIV3_ENABLED kill switch and the tenant's meriv3.fullChat off switch.
     * When this returns false the turn is refused as "Meri is unavailable"; it
     * never falls back to another runtime. The browser cannot open this gate.
     */
    isMeriV3ChatEnabled(tenantId: string): Promise<boolean>;
    /** Strict, server-resolved gate for every /mobile/v1 route. */
    isMeriMobileApiEnabled(tenantId: string): Promise<boolean>;
    /** Independent mobile capability switch; never grants authorization itself. */
    isMeriMobileCapabilityEnabled(tenantId: string, capability: MeriMobileCapability): Promise<boolean>;
    /**
     * User-facing Quick Actions are independently reversible from the MeriV3
     * runtime. The global environment switch is the emergency off, the cohort
     * defaults fleet-wide, and an explicit allowlist or tenant false remains a
     * rollback carve-out without a deploy.
     */
    isMeriQuickActionSkillsEnabled(tenantId: string, tenantSlug: string): Promise<boolean>;
}
//# sourceMappingURL=meri-feature-flags.service.d.ts.map