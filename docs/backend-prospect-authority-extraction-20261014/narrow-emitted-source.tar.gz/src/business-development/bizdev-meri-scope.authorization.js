"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.authorizeMeriProspectScope = authorizeMeriProspectScope;
const bizdev_meri_scope_service_js_1 = require("./bizdev-meri-scope.service.js");
/**
 * Authorization re-check for prospect-scoped conversations. Returns null for
 * ordinary unscoped conversations (caller proceeds unchanged). For a
 * conversation whose metadata carries a prospect scope, re-resolves it through
 * `BizDevMeriScopeService.assertCurrent` and fails closed — typed conflict /
 * safe 404 — on missing/malformed/stale scope or an unavailable scope service,
 * BEFORE the caller persists a user message or dispatches a model/runtime.
 */
async function authorizeMeriProspectScope(bizdevScope, ctx, conversationMetadata) {
    const metadata = conversationMetadata &&
        typeof conversationMetadata === 'object' &&
        !Array.isArray(conversationMetadata)
        ? conversationMetadata
        : null;
    const hasPersistedScope = Boolean(metadata && Object.prototype.hasOwnProperty.call(metadata, 'bizdevProspectScope'));
    const persisted = (0, bizdev_meri_scope_service_js_1.parsePersistedMeriProspectScope)(conversationMetadata);
    if (!hasPersistedScope)
        return null;
    if (!persisted)
        throw new bizdev_meri_scope_service_js_1.MeriProspectScopeConflictError('not_found');
    if (!bizdevScope)
        throw new bizdev_meri_scope_service_js_1.MeriProspectScopeConflictError('not_found');
    return bizdevScope.assertCurrent(ctx, conversationMetadata);
}
//# sourceMappingURL=bizdev-meri-scope.authorization.js.map