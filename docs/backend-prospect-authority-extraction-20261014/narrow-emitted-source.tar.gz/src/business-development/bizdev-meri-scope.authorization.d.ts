/** Existing prospect authorization owned by Business Development. */
import type { TenantContext } from '@capiro/shared';
import { type BizDevMeriScopeService, type MeriProspectScope } from './bizdev-meri-scope.service.js';
/**
 * Authorization re-check for prospect-scoped conversations. Returns null for
 * ordinary unscoped conversations (caller proceeds unchanged). For a
 * conversation whose metadata carries a prospect scope, re-resolves it through
 * `BizDevMeriScopeService.assertCurrent` and fails closed — typed conflict /
 * safe 404 — on missing/malformed/stale scope or an unavailable scope service,
 * BEFORE the caller persists a user message or dispatches a model/runtime.
 */
export declare function authorizeMeriProspectScope(bizdevScope: BizDevMeriScopeService | undefined, ctx: TenantContext, conversationMetadata: unknown): Promise<MeriProspectScope | null>;
//# sourceMappingURL=bizdev-meri-scope.authorization.d.ts.map