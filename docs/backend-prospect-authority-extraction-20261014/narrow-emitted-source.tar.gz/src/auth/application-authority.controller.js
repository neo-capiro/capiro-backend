"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.ApplicationAuthorityController = void 0;
const common_1 = require("@nestjs/common");
const prisma_service_js_1 = require("../prisma/prisma.service.js");
const current_tenant_decorator_js_1 = require("../tenant/current-tenant.decorator.js");
const tenant_context_middleware_js_1 = require("../tenant/tenant-context.middleware.js");
const context_security_scope_service_js_1 = require("../context/context-security-scope.service.js");
const application_authority_resource_helpers_js_1 = require("../context/application-authority-resource.helpers.js");
const bizdev_meri_scope_service_js_1 = require("../business-development/bizdev-meri-scope.service.js");
const bizdev_meri_scope_authorization_js_1 = require("../business-development/bizdev-meri-scope.authorization.js");
const roles_decorator_js_1 = require("./roles.decorator.js");
const roles_guard_js_1 = require("./roles.guard.js");
const application_authority_js_1 = require("./application-authority.js");
/** Native authority adapter for rebuilt Meri; no model/runtime/store owner. */
let ApplicationAuthorityController = class ApplicationAuthorityController {
    constructor(prisma, tenant, securityScope, bizdevScope) {
        this.prisma = prisma;
        this.tenant = tenant;
        this.securityScope = securityScope;
        this.bizdevScope = bizdevScope;
    }
    async applicationAuthorityIdentity(ctx, req, body) {
        (0, application_authority_js_1.assertApplicationAuthorityIdentityBody)(body);
        if (!this.tenant)
            throw new common_1.ForbiddenException('Application authority unavailable');
        return (0, application_authority_js_1.applicationAuthorityIdentityReceipt)(await this.tenant.readApplicationAuthority(req, ctx));
    }
    async applicationAuthorityContext(ctx, req, body) {
        const input = (0, application_authority_js_1.parseApplicationAuthorityContextBody)(body);
        const tenant = this.tenant;
        const securityScope = this.securityScope;
        if (!tenant || !securityScope)
            throw new common_1.ForbiddenException('Application authority unavailable');
        try {
            return await (0, application_authority_js_1.readApplicationAuthorityContext)(input, {
                identity: () => tenant.readApplicationAuthority(req, ctx),
                conversation: (id) => (0, application_authority_resource_helpers_js_1.loadOwnedActiveClioConversation)(this.prisma, ctx, id),
                conversationScope: async (conversation) => {
                    const prospect = await (0, bizdev_meri_scope_authorization_js_1.authorizeMeriProspectScope)(this.bizdevScope, ctx, conversation.metadata);
                    if (prospect && prospect.linkedClientId !== input.clientId)
                        throw new common_1.ForbiddenException('Application authority unavailable');
                    return prospect ? [prospect.prospectId, prospect.canonicalOrganizationId, prospect.linkedClientId, prospect.scopeVersion] : null;
                },
                clientVisible: (id) => (0, application_authority_resource_helpers_js_1.assertCurrentClientVisible)(this.prisma, ctx, id),
                clientAuthority: (id) => securityScope.resolveApplicationAuthorityClient(ctx.tenantId, ctx.userId, id),
            });
        }
        catch {
            throw new common_1.ForbiddenException('Application authority unavailable');
        }
    }
};
exports.ApplicationAuthorityController = ApplicationAuthorityController;
__decorate([
    (0, common_1.Post)('identity'),
    (0, common_1.HttpCode)(200),
    (0, common_1.Header)('Cache-Control', 'no-store'),
    (0, common_1.Header)('Content-Type', 'application/json; charset=utf-8'),
    __param(0, (0, current_tenant_decorator_js_1.CurrentTenant)()),
    __param(1, (0, common_1.Req)()),
    __param(2, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, Object, Object]),
    __metadata("design:returntype", Promise)
], ApplicationAuthorityController.prototype, "applicationAuthorityIdentity", null);
__decorate([
    (0, common_1.Post)('context'),
    (0, common_1.HttpCode)(200),
    (0, common_1.Header)('Cache-Control', 'no-store'),
    (0, common_1.Header)('Content-Type', 'application/json; charset=utf-8'),
    __param(0, (0, current_tenant_decorator_js_1.CurrentTenant)()),
    __param(1, (0, common_1.Req)()),
    __param(2, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, Object, Object]),
    __metadata("design:returntype", Promise)
], ApplicationAuthorityController.prototype, "applicationAuthorityContext", null);
exports.ApplicationAuthorityController = ApplicationAuthorityController = __decorate([
    (0, common_1.Controller)('clio/application-authority'),
    (0, common_1.UseGuards)(roles_guard_js_1.RolesGuard),
    (0, roles_decorator_js_1.Roles)('standard_user'),
    __metadata("design:paramtypes", [prisma_service_js_1.PrismaService,
        tenant_context_middleware_js_1.TenantContextMiddleware,
        context_security_scope_service_js_1.ContextSecurityScopeService,
        bizdev_meri_scope_service_js_1.BizDevMeriScopeService])
], ApplicationAuthorityController);
//# sourceMappingURL=application-authority.controller.js.map